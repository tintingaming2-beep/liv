export interface Order {
  id: string;
  clientAddress: string;
  city: string;
  pickupTime: string;
  amount: number;
  clientPhone?: string;
  status: 'pending' | 'ready' | 'accepted' | 'delivered' | 'cancelled';
  createdAt: Date;
  deliveredAt?: Date;
  driverId?: string;
}

export interface Driver {
  id: string;
  name: string;
  balance: number;
  position?: {
    lat: number;
    lng: number;
    timestamp: Date;
  };
}

export interface User {
  uid: string;
  role: 'pizzeria' | 'driver';
  name: string;
}

export interface BalanceRequest {
  id: string;
  driverId: string;
  amount: number;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: Date;
}