import { startPolling, answerCallbackQuery, sendTelegramMessage } from '../utils/telegram';
import { editMessageReplyMarkup } from '../utils/telegram';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase/config';

// Lock mechanism to prevent multiple tabs from polling simultaneously
const POLLING_LOCK_KEY = 'telegram_polling_lock';
const LOCK_TIMEOUT = 30000; // 30 seconds

export class TelegramPollingService {
  private static instance: TelegramPollingService;
  private isRunning = false;
  private startPromise: Promise<void> | null = null;
  private lockUpdateInterval: NodeJS.Timeout | null = null;

  static getInstance(): TelegramPollingService {
    if (!TelegramPollingService.instance) {
      TelegramPollingService.instance = new TelegramPollingService();
    }
    return TelegramPollingService.instance;
  }

  private acquireLock(): boolean {
    const now = Date.now();
    const existingLock = localStorage.getItem(POLLING_LOCK_KEY);
    
    if (existingLock) {
      const lockData = JSON.parse(existingLock);
      // Check if lock is still valid (not expired)
      if (now - lockData.timestamp < LOCK_TIMEOUT) {
        console.log('🔒 Polling lock held by another tab, skipping...');
        return false;
      }
    }
    
    // Acquire or renew lock
    localStorage.setItem(POLLING_LOCK_KEY, JSON.stringify({
      timestamp: now,
      tabId: Math.random().toString(36).substr(2, 9)
    }));
    
    console.log('🔓 Polling lock acquired');
    return true;
  }

  private updateLock(): void {
    const now = Date.now();
    localStorage.setItem(POLLING_LOCK_KEY, JSON.stringify({
      timestamp: now,
      tabId: Math.random().toString(36).substr(2, 9)
    }));
  }

  private releaseLock(): void {
    localStorage.removeItem(POLLING_LOCK_KEY);
    console.log('🔓 Polling lock released');
  }

  start() {
    if (this.isRunning || this.startPromise) {
      console.log('🔄 Service Telegram déjà démarré');
      return;
    }
    
    // Check if another tab is already polling
    if (!this.acquireLock()) {
      console.log('🚫 Another tab is already polling Telegram, skipping...');
      return;
    }
    
    this.startPromise = new Promise<void>((resolve) => {
      this.isRunning = true;
      console.log('🤖 Démarrage du service Telegram polling...');
      
      // Update lock every 15 seconds to keep it alive
      this.lockUpdateInterval = setInterval(() => {
        if (this.isRunning) {
          this.updateLock();
        }
      }, 15000);
      
      startPolling((callbackQuery) => {
        this.handleCallbackQuery(callbackQuery);
      });
      
      resolve();
    });
  }

  stop() {
    this.isRunning = false;
    this.startPromise = null;
    
    if (this.lockUpdateInterval) {
      clearInterval(this.lockUpdateInterval);
      this.lockUpdateInterval = null;
    }
    
    this.releaseLock();
    console.log('🛑 Service Telegram arrêté');
  }

  private async handleCallbackQuery(callbackQuery: any) {
    try {
      const { id: callbackQueryId, data: callbackData } = callbackQuery;
      console.log('🔄 === DÉBUT TRAITEMENT CALLBACK ===');
      console.log('📋 Callback Data:', callbackData);
      console.log('🆔 Callback Query ID:', callbackQueryId);
      console.log('👤 User Info:', callbackQuery.from);
      console.log('💬 Message Info:', callbackQuery.message);
      
      if (callbackData.startsWith('accept_') || callbackData.startsWith('refuse_')) {
        const [action, orderId] = callbackData.split('_');
        console.log('⚡ Action détectée:', action);
        console.log('🎯 Order ID extrait:', orderId);
        
        // Vérifier si l'orderId existe
        if (!orderId) {
          console.error('❌ OrderId manquant dans callback_data:', callbackData);
          await answerCallbackQuery(callbackQueryId, '❌ Erreur: ID commande manquant');
          return;
        }
        
        if (action === 'accept') {
          console.log('✅ === ACCEPTATION COMMANDE ===');
          console.log('🎯 Order ID à accepter:', orderId);
          
          // Vérifier d'abord si la commande existe
          console.log('🔍 Vérification existence commande...');
          try {
            const { getDoc } = await import('firebase/firestore');
            const orderDoc = await getDoc(doc(db, 'orders', orderId));
            
            if (!orderDoc.exists()) {
              console.error('❌ Commande introuvable:', orderId);
              await answerCallbackQuery(callbackQueryId, '❌ Commande introuvable ou déjà traitée');
              return;
            }
            
            const orderData = orderDoc.data();
            if (orderData.status !== 'ready') {
              console.error('❌ Commande pas prête:', orderData.status);
              await answerCallbackQuery(callbackQueryId, '❌ Commande non disponible');
              return;
            }
            
            console.log('✅ Commande trouvée et prête:', orderData);
          } catch (checkError) {
            console.error('❌ ERREUR VÉRIFICATION:', checkError);
            await answerCallbackQuery(callbackQueryId, '❌ Erreur lors de la vérification');
            return;
          }
          
          // Mettre à jour le statut de la commande à "accepted" avec driverId
          console.log('🔄 Mise à jour Firestore en cours...');
          try {
            await updateDoc(doc(db, 'orders', orderId), {
              status: 'accepted',
              driverId: 'driver-001'
            });
            console.log('✅ ✅ FIRESTORE MIS À JOUR - COMMANDE ACCEPTÉE ✅ ✅');
          } catch (firestoreError) {
            console.error('❌ ERREUR FIRESTORE:', firestoreError);
            throw firestoreError;
          }
          
          console.log('📤 Envoi réponse callback...');
          try {
            await answerCallbackQuery(callbackQueryId, '✅ Commande acceptée');
            console.log('✅ Callback query répondu avec succès');
          } catch (callbackError) {
            console.error('❌ ERREUR CALLBACK QUERY:', callbackError);
          }
          
          console.log('📝 Mise à jour des boutons du message...');
          try {
            // Remplacer les boutons Accepter/Refuser par le bouton Livraison effectuée
            const messageId = callbackQuery.message.message_id;
            await editMessageReplyMarkup(messageId, [
              { text: '🚚 Marquer livrée', callback_data: `delivered_${orderId}` }
            ]);
            console.log('✅ Boutons mis à jour avec succès');
          } catch (messageError) {
            console.error('❌ ERREUR MISE À JOUR BOUTONS:', messageError);
          }
          
          // Envoyer un message de confirmation séparé
          try {
            await sendTelegramMessage('✅ Commande acceptée ! Vous pouvez maintenant la livrer.');
            console.log('✅ Message de confirmation envoyé');
          } catch (confirmError) {
            console.error('❌ ERREUR MESSAGE CONFIRMATION:', confirmError);
          }
          console.log('✅ ✅ PROCESSUS ACCEPTATION TERMINÉ ✅ ✅');
          
        } else if (action === 'refuse') {
          console.log('❌ === REFUS COMMANDE ===');
          console.log('🎯 Order ID à refuser:', orderId);
          
          // Vérifier d'abord si la commande existe
          console.log('🔍 Vérification existence commande...');
          try {
            const { getDoc } = await import('firebase/firestore');
            const orderDoc = await getDoc(doc(db, 'orders', orderId));
            
            if (!orderDoc.exists()) {
              console.error('❌ Commande introuvable:', orderId);
              await answerCallbackQuery(callbackQueryId, '❌ Commande introuvable ou déjà traitée');
              return;
            }
            
            const orderData = orderDoc.data();
            if (orderData.status !== 'ready') {
              console.error('❌ Commande pas prête:', orderData.status);
              await answerCallbackQuery(callbackQueryId, '❌ Commande non disponible');
              return;
            }
            
            console.log('✅ Commande trouvée et prête:', orderData);
          } catch (checkError) {
            console.error('❌ ERREUR VÉRIFICATION REFUS:', checkError);
            await answerCallbackQuery(callbackQueryId, '❌ Erreur lors de la vérification');
            return;
          }
          
          // Mettre à jour le statut de la commande à "cancelled"
          console.log('🔄 Mise à jour Firestore en cours...');
          try {
            await updateDoc(doc(db, 'orders', orderId), {
              status: 'cancelled'
            });
            console.log('❌ ❌ FIRESTORE MIS À JOUR - COMMANDE ANNULÉE ❌ ❌');
          } catch (firestoreError) {
            console.error('❌ ERREUR FIRESTORE REFUS:', firestoreError);
            throw firestoreError;
          }
          
          console.log('📤 Envoi réponse callback...');
          try {
            await answerCallbackQuery(callbackQueryId, '❌ Commande refusée');
            console.log('❌ Callback query refus répondu avec succès');
          } catch (callbackError) {
            console.error('❌ ERREUR CALLBACK QUERY REFUS:', callbackError);
          }
          
          console.log('📝 Suppression des boutons du message...');
          try {
            // Supprimer tous les boutons après refus
            const messageId = callbackQuery.message.message_id;
            await editMessageReplyMarkup(messageId, []);
            console.log('✅ Boutons supprimés avec succès');
          } catch (messageError) {
            console.error('❌ ERREUR SUPPRESSION BOUTONS:', messageError);
          }
          
          // Envoyer un message de confirmation séparé
          try {
            await sendTelegramMessage('❌ Commande refusée.');
            console.log('❌ Message de confirmation envoyé');
          } catch (messageError) {
            console.error('❌ ERREUR MESSAGE REFUS:', messageError);
          }
          console.log('❌ ❌ PROCESSUS REFUS TERMINÉ ❌ ❌');
        }
      } else if (callbackData.startsWith('delivered_')) {
        const orderId = callbackData.split('_')[1];
        console.log('🚚 === MARQUAGE LIVRAISON ===');
        console.log('🎯 Order ID à marquer livré:', orderId);
        
        if (!orderId) {
          console.error('❌ OrderId manquant dans callback_data:', callbackData);
          await answerCallbackQuery(callbackQueryId, '❌ Erreur: ID commande manquant');
          return;
        }
        
        try {
          // Vérifier d'abord le statut actuel de la commande
          const { getDoc } = await import('firebase/firestore');
          const orderDoc = await getDoc(doc(db, 'orders', orderId));
          
          if (!orderDoc.exists()) {
            console.error('❌ Commande introuvable:', orderId);
            await answerCallbackQuery(callbackQueryId, '❌ Commande introuvable');
            return;
          }
          
          const orderData = orderDoc.data();
          
          // Vérifier si la commande est déjà livrée
          if (orderData.status === 'delivered') {
            console.log('⚠️ Commande déjà livrée, ignorer le double clic');
            await answerCallbackQuery(callbackQueryId, '⚠️ Commande déjà livrée');
            return;
          }
          
          // Vérifier si la commande est bien acceptée par ce livreur
          if (orderData.status !== 'accepted' || orderData.driverId !== 'driver-001') {
            console.log('❌ Commande non acceptée ou pas assignée à ce livreur');
            await answerCallbackQuery(callbackQueryId, '❌ Commande non disponible');
            return;
          }
          
          // Marquer comme livré avec le driver ID fixe
          await updateDoc(doc(db, 'orders', orderId), {
            status: 'delivered',
            deliveredAt: new Date(),
            driverId: 'driver-001'
          });
          
          // Mettre à jour le solde du livreur (+5€)
          const { increment } = await import('firebase/firestore');
          await updateDoc(doc(db, 'drivers', 'driver-001'), {
            balance: increment(5)
          });
          
          console.log('✅ Commande marquée livrée et solde mis à jour (+5€)');
          
          // Supprimer le bouton "Marquer livrée" après utilisation
          try {
            const messageId = callbackQuery.message.message_id;
            await editMessageReplyMarkup(messageId, []);
            console.log('✅ Bouton livraison supprimé');
          } catch (editError) {
            console.error('❌ Erreur suppression bouton livraison:', editError);
          }
          
          await answerCallbackQuery(callbackQueryId, '✅ Livraison confirmée');
          await sendTelegramMessage('✅ Livraison confirmée ! +5€ ajoutés au solde.');
          
        } catch (error) {
          console.error('❌ Erreur lors du marquage livraison:', error);
          await answerCallbackQuery(callbackQueryId, '❌ Erreur lors de la livraison');
        }
      } else {
        console.log('⚠️ ⚠️ CALLBACK_DATA NON RECONNU ⚠️ ⚠️');
        console.log('📋 Data reçue:', callbackData);
      }
      
      console.log('🏁 === FIN TRAITEMENT CALLBACK ===');
    } catch (error) {
      console.error('💥 💥 ERREUR CRITIQUE DANS CALLBACK 💥 💥');
      console.error('📋 Callback data:', callbackQuery?.data);
      console.error('🆔 Callback ID:', callbackQuery?.id);
      console.error('❌ Erreur complète:', error);
      
      // Répondre au callback même en cas d'erreur
      try {
        await answerCallbackQuery(callbackQuery.id, '❌ Erreur lors du traitement');
      } catch (answerError) {
        console.error('💥 Erreur lors de la réponse au callback:', answerError);
      }
    }
  }
}