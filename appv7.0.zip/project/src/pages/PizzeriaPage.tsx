import React, { useState, useEffect } from 'react';
import { Plus, Search, Filter, Euro, RotateCcw } from 'lucide-react';
import { Layout } from '../components/Layout';
import { OrderCard } from '../components/OrderCard';
import { OrderModal } from '../components/OrderModal';
import { GPS } from '../components/GPS';
import { Notification } from '../components/Notification';
import { NotificationSettings } from '../components/NotificationSettings';
import { useOrders } from '../context/OrderContext';
import { useAuth } from '../context/AuthContext';
import { Order } from '../types';
import { doc, onSnapshot, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase/config';

export const PizzeriaPage: React.FC = () => {
  const { user } = useAuth();
  const { orders, addOrder, updateOrder, deleteOrder, markAsReady } = useOrders();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<Order['status'] | 'all'>('all');
  const [notification, setNotification] = useState<{ message: string; type: 'info' | 'success' | 'warning' } | null>(null);
  const [driverPosition, setDriverPosition] = useState<{ lat: number; lng: number } | null>(null);
  const [driverBalance, setDriverBalance] = useState(0);
  const [lastGPSUpdate, setLastGPSUpdate] = useState<string>('');

  // Listen for driver position updates
  useEffect(() => {
    console.log('📡 PIZZERIA - Setting up driver position listener...');
    
    // Fonction pour récupérer la position
    const fetchDriverPosition = async () => {
      try {
        const { getDoc } = await import('firebase/firestore');
        const docRef = doc(db, 'driver-positions', 'current');
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          const data = docSnap.data();
          console.log('📡 PIZZERIA - Position récupérée:', data);
          
          if (data.position) {
            const newPosition = data.position;
            const updateTime = data.timestamp?.toDate?.()?.toLocaleTimeString() || 'Inconnue';
            
            console.log('📍 PIZZERIA - Nouvelle position:', newPosition);
            setDriverPosition(newPosition);
            setLastGPSUpdate(updateTime);
          }
        } else {
          console.log('❌ PIZZERIA - Aucune position trouvée');
          setDriverPosition(null);
        }
      } catch (error) {
        console.error('❌ PIZZERIA - Erreur récupération position:', error);
      }
    };
    
    // Récupération initiale
    fetchDriverPosition();
    
    // Listener en temps réel
    const unsubscribe = onSnapshot(
      doc(db, 'driver-positions', 'current'),
      {
        includeMetadataChanges: true
      },
      (doc) => {
        console.log('🔄 PIZZERIA - Changement détecté:', doc.exists(), doc.metadata.hasPendingWrites);
        
        if (doc.exists() && !doc.metadata.hasPendingWrites) {
          const data = doc.data();
          console.log('📡 PIZZERIA - Nouvelles données:', data);
          
          if (data.position) {
            const newPosition = data.position;
            const updateTime = data.timestamp?.toDate?.()?.toLocaleTimeString() || 'Jamais';
            
            console.log('📍 PIZZERIA - Position mise à jour:', newPosition, 'à', updateTime);
            setDriverPosition({ ...newPosition }); // Force new object reference
            setLastGPSUpdate(updateTime);
            
            // Force re-render
            console.log('🔄 PIZZERIA - Force re-render avec nouvelle position');
          }
        }
      },
      (error) => {
        console.error('❌ PIZZERIA - Erreur listener:', error);
        // Retry après 5 secondes
        setTimeout(fetchDriverPosition, 5000);
      }
    );
    
    // Polling de secours toutes les 30 secondes
    const pollingInterval = setInterval(fetchDriverPosition, 180000); // 3 minutes

    return () => {
      unsubscribe();
      clearInterval(pollingInterval);
    };
  }, []);

  // Listen for driver balance updates
  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, 'drivers', 'driver-001'), (doc) => {
      if (doc.exists()) {
        const data = doc.data();
        setDriverBalance(data.balance || 0);
      }
    });

    return () => unsubscribe();
  }, []);

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.clientAddress.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.city.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleAddOrder = async (orderData: Omit<Order, 'id' | 'createdAt' | 'status'>) => {
    try {
      await addOrder(orderData);
      setNotification({
        message: 'Commande créée avec succès',
        type: 'success'
      });
    } catch (error) {
      setNotification({
        message: 'Erreur lors de la création de la commande',
        type: 'warning'
      });
    }
  };

  const handleEditOrder = async (orderData: Omit<Order, 'id' | 'createdAt' | 'status'>) => {
    if (!editingOrder) return;
    
    try {
      await updateOrder(editingOrder.id, orderData);
      setNotification({
        message: 'Commande modifiée avec succès',
        type: 'success'
      });
      setEditingOrder(null);
    } catch (error) {
      setNotification({
        message: 'Erreur lors de la modification',
        type: 'warning'
      });
    }
  };

  const handleDeleteOrder = async (id: string) => {
    const order = orders.find(o => o.id === id);
    const isAccepted = order?.status === 'accepted';
    const confirmMessage = isAccepted 
      ? 'Cette commande a été acceptée par le livreur. Êtes-vous sûr de vouloir l\'annuler ? Le livreur sera notifié.'
      : 'Êtes-vous sûr de vouloir supprimer cette commande ?';
    
    if (window.confirm(confirmMessage)) {
      try {
        if (isAccepted) {
          // Si la commande est acceptée, on l'annule au lieu de la supprimer
          await updateOrder(id, { status: 'cancelled' });
        } else {
          // Si elle n'est pas encore acceptée, on peut la supprimer
          await deleteOrder(id);
        }
        setNotification({
          message: isAccepted ? 'Commande annulée - Livreur notifié' : 'Commande supprimée',
          type: 'info'
        });
      } catch (error) {
        setNotification({
          message: isAccepted ? 'Erreur lors de l\'annulation' : 'Erreur lors de la suppression',
          type: 'warning'
        });
      }
    }
  };

  const handleMarkReady = async (id: string) => {
    try {
      await markAsReady(id);
      setNotification({
        message: 'Commande marquée comme prête - Livreur notifié',
        type: 'success'
      });
    } catch (error) {
      setNotification({
        message: 'Erreur lors de la mise à jour',
        type: 'warning'
      });
    }
  };

  const handleResetBalance = async () => {
    if (window.confirm(`Demander une remise à zéro du solde de ${driverBalance.toFixed(2)}€ ?`)) {
      try {
        // Create a balance reset request
        await setDoc(doc(db, 'balance-requests', 'current'), {
          driverId: 'driver-001',
          amount: driverBalance,
          status: 'pending',
          createdAt: new Date()
        });
        
        setNotification({
          message: 'Demande de remise à zéro envoyée au livreur',
          type: 'info'
        });
      } catch (error) {
        setNotification({
          message: 'Erreur lors de la demande',
          type: 'warning'
        });
      }
    }
  };

  const openEditModal = (order: Order) => {
    setEditingOrder(order);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingOrder(null);
  };

  const pendingOrders = orders.filter(order => order.status === 'pending').length;
  const readyOrders = orders.filter(order => order.status === 'ready').length;
  const completedOrders = orders.filter(order => order.status === 'delivered').length;

  return (
    <Layout title="Interface Pizzeria">
      <div className="space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">En attente</h3>
            <p className="text-3xl font-bold text-yellow-600">{pendingOrders}</p>
          </div>
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Prêtes</h3>
            <p className="text-3xl font-bold text-blue-600">{readyOrders}</p>
          </div>
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Livrées</h3>
            <p className="text-3xl font-bold text-green-600">{completedOrders}</p>
          </div>
        </div>

        {/* Notification Settings */}
        <NotificationSettings />

        {/* Driver Balance Card */}
        <div className="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 p-6 rounded-lg border border-gray-200 dark:border-gray-700 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">Solde livreur à payer</h3>
              <div className="flex items-center space-x-1">
                <Euro className="w-6 h-6 text-green-600" />
                <span className="text-3xl font-bold text-green-600">
                  {driverBalance.toFixed(2)}
                </span>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                {Math.floor(driverBalance / 5)} livraisons × 5€
              </p>
            </div>
            <button
              onClick={handleResetBalance}
              disabled={driverBalance === 0}
              className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg font-medium transition-colors"
            >
              <RotateCcw className="w-5 h-5" />
              <span className="hidden sm:block">Remettre à zéro</span>
            </button>
          </div>
        </div>

        {/* GPS Tracking */}
        <div className="space-y-4">
          {/* Debug GPS Info */}
          <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
            <h4 className="font-semibold text-yellow-800 dark:text-yellow-300 mb-2">🔍 Debug GPS Pizzeria</h4>
            <div className="text-sm space-y-1">
              <p><strong>Position livreur:</strong> {driverPosition ? `${driverPosition.lat.toFixed(6)}, ${driverPosition.lng.toFixed(6)}` : 'Aucune'}</p>
              <p><strong>Dernière MAJ:</strong> {lastGPSUpdate || 'Jamais'}</p>
              <p><strong>Status:</strong> {driverPosition ? '🟢 Connecté' : '🔴 Déconnecté'}</p>
            </div>
          </div>
          
          <GPS onLocationUpdate={undefined} updateOnDemand={true} driverPosition={driverPosition} showGPSToggle={true} readOnly={true} />
        </div>

        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-4 sm:space-y-0">
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Rechercher une commande..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent w-full sm:w-64 bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors"
              />
            </div>
            
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as Order['status'] | 'all')}
                className="pl-10 pr-8 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors"
              >
                <option value="all">Tous les statuts</option>
                <option value="pending">En attente</option>
                <option value="ready">Prêtes</option>
                <option value="accepted">Acceptées</option>
                <option value="delivered">Livrées</option>
                <option value="cancelled">Annulées</option>
              </select>
            </div>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
          >
            <Plus className="w-5 h-5" />
            <span>Nouvelle commande</span>
          </button>
        </div>

        {/* Orders List */}
        <div className="space-y-4">
          {filteredOrders.length > 0 ? (
            filteredOrders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                userRole="pizzeria"
                onEdit={openEditModal}
                onDelete={handleDeleteOrder}
                onMarkReady={handleMarkReady}
              />
            ))
          ) : (
            <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 transition-colors">
              <p className="text-gray-500 dark:text-gray-400">Aucune commande trouvée</p>
            </div>
          )}
        </div>

        {/* Order Modal */}
        <OrderModal
          isOpen={isModalOpen}
          onClose={closeModal}
          onSubmit={editingOrder ? handleEditOrder : handleAddOrder}
          editOrder={editingOrder}
        />

        {/* Notifications */}
        {notification && (
          <Notification
            message={notification.message}
            type={notification.type}
            onClose={() => setNotification(null)}
          />
        )}
      </div>
    </Layout>
  );
};