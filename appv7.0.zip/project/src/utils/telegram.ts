const TELEGRAM_TOKEN = '8061630351:AAECVOwxhfUVdEjiYXq5TtULTmGrCuzqawk';
const TELEGRAM_CHAT_ID = '7625568866';

// Fonction pour vérifier le bot et obtenir des infos
export const getBotInfo = async () => {
  try {
    const url = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/getMe`;
    const response = await fetch(url);
    const data = await response.json();
    console.log('🤖 Info du bot:', data);
    return data;
  } catch (error) {
    console.error('❌ Erreur lors de la récupération des infos du bot:', error);
    return null;
  }
};

// Fonction pour supprimer le webhook (au cas où il y en aurait un)
export const deleteWebhook = async () => {
  try {
    const url = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/deleteWebhook`;
    const response = await fetch(url, { method: 'POST' });
    const data = await response.json();
    console.log('🗑️ Suppression webhook:', data);
    return data;
  } catch (error) {
    console.error('❌ Erreur lors de la suppression du webhook:', error);
    return null;
  }
};

interface TelegramButton {
  text: string;
  callback_data: string;
}

export const sendTelegramMessage = async (text: string, buttons?: TelegramButton[]) => {
  try {
    console.log('📤 Envoi message Telegram:', { text: text.substring(0, 50) + '...', buttons });
    
    const url = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`;
    
    const payload: any = {
      chat_id: TELEGRAM_CHAT_ID,
      text: text,
      parse_mode: 'HTML'
    };

    if (buttons && buttons.length > 0) {
      payload.reply_markup = {
        inline_keyboard: [buttons.map(button => ({
          text: button.text,
          callback_data: button.callback_data
        }))]
      };
    }

    console.log('📤 Payload complet:', payload);
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Erreur Telegram API:', response.status, errorText);
      throw new Error(`Telegram API error: ${response.status}`);
    }

    const result = await response.json();
    console.log('✅ Message envoyé avec succès:', result);
    return result;
  } catch (error) {
    console.error('Error sending Telegram message:', error);
    throw error;
  }
};

export const answerCallbackQuery = async (callbackQueryId: string, text: string) => {
  try {
    const url = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/answerCallbackQuery`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        callback_query_id: callbackQueryId,
        text: text,
        show_alert: false
      })
    });

    return await response.json();
  } catch (error) {
    console.error('Error answering callback query:', error);
    throw error;
  }
};

export const editMessageReplyMarkup = async (messageId: number, buttons?: TelegramButton[]) => {
  try {
    const url = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/editMessageReplyMarkup`;
    
    const payload: any = {
      chat_id: TELEGRAM_CHAT_ID,
      message_id: messageId
    };

    if (buttons && buttons.length > 0) {
      payload.reply_markup = {
        inline_keyboard: [buttons.map(button => ({
          text: button.text,
          callback_data: button.callback_data
        }))]
      };
    } else {
      // Supprimer tous les boutons
      payload.reply_markup = {
        inline_keyboard: []
      };
    }

    console.log('📝 Mise à jour des boutons:', payload);
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Erreur edit message:', response.status, errorText);
      throw new Error(`Telegram API error: ${response.status}`);
    }

    const result = await response.json();
    console.log('✅ Boutons mis à jour:', result);
    return result;
  } catch (error) {
    console.error('Error editing message buttons:', error);
    throw error;
  }
};

// Long polling pour récupérer les updates
let lastUpdateId = 0;
let isPolling = false;
let pollingPromise: Promise<void> | null = null;

export const getUpdates = async () => {
  try {
    const url = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/getUpdates`;
    
    const payload = {
      offset: lastUpdateId + 1,
      timeout: 10,
      limit: 100
    };
    
    console.log('📡 Requête getUpdates:', payload);
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`Telegram API error: ${response.status}`);
    }

    const data = await response.json();
    console.log('📥 Réponse Telegram complète:', data);
    
    if (data.result && data.result.length > 0) {
      console.log('📨 Updates trouvés:', data.result.length, data.result);
    } else {
      console.log('📭 Aucun update reçu');
    }
    
    return data.result || [];
  } catch (error) {
    console.error('Error getting updates:', error);
    return [];
  }
};

export const startPolling = (onCallbackQuery: (callbackQuery: any) => void) => {
  if (isPolling || pollingPromise) {
    console.log('🔄 Polling déjà en cours, ignoré');
    return;
  }
  
  isPolling = true;
  console.log('🤖 Démarrage du polling Telegram...');
  console.log('🔑 Token utilisé:', TELEGRAM_TOKEN.substring(0, 10) + '...');
  console.log('💬 Chat ID:', TELEGRAM_CHAT_ID);

  const poll = async () => {
    if (!isPolling) {
      pollingPromise = null;
      return;
    }

    try {
      const updates = await getUpdates();
      
      for (const update of updates) {
        lastUpdateId = Math.max(lastUpdateId, update.update_id);
        console.log('🔄 Processing update:', update.update_id, 'Type:', Object.keys(update));
        
        if (update.callback_query) {
          console.log('📞 Callback reçu:', update.callback_query.data);
          console.log('👤 User:', update.callback_query.from);
          console.log('💬 Message:', update.callback_query.message);
          onCallbackQuery(update.callback_query);
        } else {
          console.log('ℹ️ Update sans callback_query:', update);
        }
      }
      
      // Continuer le polling seulement après que la requête précédente soit terminée
      if (isPolling) {
        setTimeout(poll, 5000);
      }
    } catch (error) {
      console.error('Erreur lors du polling:', error);
      // En cas d'erreur 409, arrêter le polling pour éviter les conflits
      if (error.message && error.message.includes('409')) {
        console.log('⚠️ Conflit 409 détecté - arrêt du polling pour éviter les conflits');
        isPolling = false;
        pollingPromise = null;
        return;
      } else {
        // Pour les autres erreurs, attendre 8 secondes
        if (isPolling) {
          setTimeout(poll, 8000);
        }
      }
    }
  };

  // Vérifier le bot et supprimer tout webhook existant avant de démarrer
  const initBot = async () => {
    try {
      await getBotInfo();
      await deleteWebhook();
      console.log('✅ Bot initialisé, démarrage du polling...');
      // Attendre 1 seconde après suppression webhook pour éviter conflit 409
      setTimeout(() => {
        console.log('🚀 Démarrage du polling après délai...');
        poll();
      }, 1000);
    } catch (error) {
      console.error('❌ Erreur lors de l\'initialisation du bot:', error);
      if (isPolling) {
        setTimeout(initBot, 10000); // Réessayer dans 10 secondes
      }
    }
  };

  pollingPromise = new Promise<void>((resolve) => {
    // Attendre 2 secondes puis initialiser le bot
    setTimeout(() => {
      initBot();
      resolve();
    }, 2000);
  });
};

export const stopPolling = () => {
  isPolling = false;
  pollingPromise = null;
  console.log('🛑 Arrêt du polling Telegram');
};