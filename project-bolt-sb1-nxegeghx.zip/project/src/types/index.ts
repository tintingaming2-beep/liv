export interface User {
  id: string;
  username: string;
  role: 'pizzeria' | 'livreur';
  isOnline: boolean;
  lastSeen: Date;
}

export interface Order {
  id: string;
  customerAddress: string;
  city: string;
  customerPhone: string;
  pickupTime: string;
  amount: number;
  status: 'pending' | 'ready' | 'accepted' | 'delivered' | 'cancelled';
  createdAt: Date;
  updatedAt: Date;
  assignedTo?: string;
  deliveredAt?: Date;
}

export interface DeliveryDriver {
  id: string;
  username: string;
  balance: number;
  position?: {
    lat: number;
    lng: number;
    timestamp: Date;
  };
  isAvailable: boolean;
}

export interface AppNotification {
  id: string;
  type: 'new_order' | 'order_ready' | 'order_delivered' | 'balance_reset_request';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  recipientId: string;
  orderId?: string;
}

export const CITIES = [
  'Le Quesnoy',
  'Villereau',
  'Potelle',
  'Louvignies-Quesnoy',
  'Ghissignies',
  'Orsinval',
  'Beaudignies',
  'Jolimetz',
  'Villers-Pol',
  'Gommegnies',
  'Poix-du-Nord',
  'Jenlain',
  'Artres',
  'Sepmeries',
  'Valenciennes',
  'Maubeuge',
  'Vendegies-sur-Écaillon',
  'Wargnies-le-Grand',
  'Saint-Martin-sur-Écaillon',
  'Escarmain',
  'Préseau',
  'Maresches',
  'Ruesnes',
  'Bermerain'
];