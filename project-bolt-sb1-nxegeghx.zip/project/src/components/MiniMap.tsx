import React from 'react';
import { MapPin, Navigation } from 'lucide-react';

interface MiniMapProps {
  position: { lat: number; lng: number } | null;
}

const MiniMap: React.FC<MiniMapProps> = ({ position }) => {
  if (!position) {
    return (
      <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
        <div className="text-center text-gray-500">
          <MapPin className="w-12 h-12 mx-auto mb-2 opacity-50" />
          <p>Position non disponible</p>
          <p className="text-sm">Activez la géolocalisation</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Mini Map Visualization */}
      <div className="relative h-64 bg-gradient-to-br from-blue-100 to-green-100 rounded-lg border-2 border-dashed border-blue-300 flex items-center justify-center">
        <div className="text-center">
          <div className="bg-blue-500 w-10 h-10 rounded-full flex items-center justify-center mb-3 mx-auto animate-bounce">
            <MapPin className="w-6 h-6 text-white" />
          </div>
          <p className="text-sm font-medium text-gray-700 mb-1">Vous êtes ici</p>
          <p className="text-xs text-gray-500">
            {position.lat.toFixed(4)}, {position.lng.toFixed(4)}
          </p>
        </div>
      </div>

      {/* Position Details */}
      <div className="bg-gray-50 rounded-lg p-3 text-sm space-y-2">
        <div className="flex justify-between">
          <span className="text-gray-600">Latitude:</span>
          <span className="font-mono">{position.lat.toFixed(6)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600">Longitude:</span>
          <span className="font-mono">{position.lng.toFixed(6)}</span>
        </div>
      </div>

      {/* Navigation Button */}
      <a
        href={`https://www.google.com/maps?q=${position.lat},${position.lng}`}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center gap-2 w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
      >
        <Navigation className="w-5 h-5" />
        Ouvrir dans Google Maps
      </a>
    </div>
  );
};

export default MiniMap;