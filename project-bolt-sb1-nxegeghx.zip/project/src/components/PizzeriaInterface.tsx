import React, { useState, useEffect } from 'react';
import { Plus, MapPin, Clock, Euro, Edit3, Trash2, Check, Eye, LogOut, Pizza } from 'lucide-react';
import { Order, CITIES } from '../types';
import { OrderService } from '../services/orderService';
import { NotificationService } from '../services/notificationService';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';
import OrderForm from './OrderForm';
import OrderDetails from './OrderDetails';
import LiveMap from './LiveMap';

const PizzeriaInterface: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [activeTab, setActiveTab] = useState<'orders' | 'map' | 'history'>('orders');
  const { logout } = useAuth();

  useEffect(() => {
    // Charger les commandes initiales
    const storedOrders = OrderService.getStoredOrders();
    setOrders(storedOrders);

    // Écouter les changements en temps réel
    const unsubscribe = OrderService.subscribeToOrders(setOrders);
    return unsubscribe;
  }, []);

  const handleCreateOrder = async (orderData: Omit<Order, 'id' | 'createdAt' | 'updatedAt' | 'status'>) => {
    const result = await OrderService.createOrder(orderData);
    
    if (result.success && result.order) {
      // Notifier le livreur
      await NotificationService.sendNotification({
        type: 'new_order',
        title: '🍕 Nouvelle commande !',
        message: `Livraison vers ${result.order.city} - ${result.order.amount}€`,
        recipientId: 'livreur-1',
        orderId: result.order.id
      });
      
      toast.success('Commande créée avec succès !');
      setShowOrderForm(false);
    } else {
      toast.error(result.error || 'Erreur lors de la création');
    }
  };

  const handleUpdateOrder = async (orderId: string, updates: Partial<Order>) => {
    const result = await OrderService.updateOrder(orderId, updates);
    
    if (result.success) {
      if (updates.status === 'ready') {
        // Notifier le livreur que la commande est prête
        await NotificationService.sendNotification({
          type: 'order_ready',
          title: '✅ Commande prête !',
          message: `La commande pour ${result.order?.city} est prête à être récupérée`,
          recipientId: 'livreur-1',
          orderId: orderId
        });
        toast.success('Livreur notifié !');
      } else {
        toast.success('Commande mise à jour !');
      }
      setEditingOrder(null);
    } else {
      toast.error(result.error || 'Erreur lors de la mise à jour');
    }
  };

  const handleDeleteOrder = async (orderId: string) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer cette commande ?')) {
      const result = await OrderService.deleteOrder(orderId);
      if (result.success) {
        toast.success('Commande supprimée !');
      } else {
        toast.error(result.error || 'Erreur lors de la suppression');
      }
    }
  };

  const getStatusBadge = (status: Order['status']) => {
    const badges = {
      pending: { label: 'En attente', class: 'bg-yellow-100 text-yellow-800' },
      ready: { label: 'Prête', class: 'bg-blue-100 text-blue-800' },
      accepted: { label: 'En livraison', class: 'bg-orange-100 text-orange-800' },
      delivered: { label: 'Livrée', class: 'bg-green-100 text-green-800' },
      cancelled: { label: 'Annulée', class: 'bg-red-100 text-red-800' }
    };
    
    return badges[status];
  };

  const currentOrders = orders.filter(o => o.status !== 'delivered' && o.status !== 'cancelled');
  const completedOrders = orders.filter(o => o.status === 'delivered' || o.status === 'cancelled');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="px-4 py-3 flex items-center justify-between">
          <h1 className="text-xl font-bold text-gray-800">🍕 Pizzeria Dashboard</h1>
          <button
            onClick={logout}
            className="flex items-center gap-2 text-gray-600 hover:text-red-600 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            Déconnexion
          </button>
        </div>
      </div>

      {/* Navigation */}
      <div className="bg-white border-b">
        <div className="flex">
          <button
            onClick={() => setActiveTab('orders')}
            className={`flex-1 py-3 px-4 text-sm font-medium text-center transition-colors ${
              activeTab === 'orders' 
                ? 'border-b-2 border-blue-600 text-blue-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Commandes ({currentOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('map')}
            className={`flex-1 py-3 px-4 text-sm font-medium text-center transition-colors ${
              activeTab === 'map' 
                ? 'border-b-2 border-blue-600 text-blue-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Suivi GPS
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-3 px-4 text-sm font-medium text-center transition-colors ${
              activeTab === 'history' 
                ? 'border-b-2 border-blue-600 text-blue-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Historique
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {activeTab === 'orders' && (
          <>
            {/* Add Order Button */}
            <button
              onClick={() => setShowOrderForm(true)}
              className="w-full mb-4 bg-blue-600 text-white py-4 px-6 rounded-lg font-medium text-lg flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors shadow-lg"
            >
              <Plus className="w-6 h-6" />
              Nouvelle commande
            </button>

            {/* Orders List */}
            <div className="space-y-3">
              {currentOrders.map((order) => (
                <div key={order.id} className="bg-white rounded-lg shadow-sm border p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(order.status).class}`}>
                          {getStatusBadge(order.status).label}
                        </span>
                        {order.customerPhone && (
                          <a
                            href={`tel:${order.customerPhone}`}
                            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                          >
                            {order.customerPhone}
                          </a>
                        )}
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span>{order.customerAddress}, {order.city}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            <span>{order.pickupTime}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Euro className="w-4 h-4" />
                            <span className="font-medium">{order.amount}€</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedOrder(order)}
                        className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                      >
                        <Eye className="w-5 h-5" />
                      </button>
                      
                      {order.status !== 'delivered' && (
                        <>
                          <button
                            onClick={() => setEditingOrder(order)}
                            className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                          >
                            <Edit3 className="w-5 h-5" />
                          </button>
                          
                          <button
                            onClick={() => handleDeleteOrder(order.id)}
                            className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-3 border-t">
                    {order.status === 'pending' && (
                      <button
                        onClick={() => handleUpdateOrder(order.id, { status: 'ready' })}
                        className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg font-medium text-sm flex items-center justify-center gap-1 hover:bg-green-700 transition-colors"
                      >
                        <Check className="w-4 h-4" />
                        Marquer prête
                      </button>
                    )}
                    
                    {order.status === 'ready' && (
                      <div className="flex-1 bg-blue-50 text-blue-700 py-2 px-4 rounded-lg text-sm text-center font-medium">
                        En attente du livreur
                      </div>
                    )}
                    
                    {order.status === 'accepted' && (
                      <div className="flex-1 bg-orange-50 text-orange-700 py-2 px-4 rounded-lg text-sm text-center font-medium">
                        En cours de livraison
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {currentOrders.length === 0 && (
                <div className="text-center py-12 text-gray-500">
                  <Pizza className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p className="text-lg">Aucune commande en cours</p>
                  <p className="text-sm">Cliquez sur "Nouvelle commande" pour commencer</p>
                </div>
              )}
            </div>
          </>
        )}

        {activeTab === 'map' && <LiveMap />}

        {activeTab === 'history' && (
          <div className="space-y-3">
            {completedOrders.map((order) => (
              <div key={order.id} className="bg-white rounded-lg shadow-sm border p-4 opacity-75">
                <div className="flex items-center justify-between mb-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(order.status).class}`}>
                    {getStatusBadge(order.status).label}
                  </span>
                  <span className="text-xs text-gray-500">
                    {order.deliveredAt?.toLocaleDateString()} {order.deliveredAt?.toLocaleTimeString()}
                  </span>
                </div>
                <div className="text-sm text-gray-600 space-y-1">
                  <div>{order.customerAddress}, {order.city}</div>
                  <div className="flex items-center gap-3">
                    <span>{order.pickupTime}</span>
                    <span className="font-medium">{order.amount}€</span>
                  </div>
                </div>
              </div>
            ))}

            {completedOrders.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                <Clock className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p>Aucune commande terminée</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modals */}
      {showOrderForm && (
        <OrderForm
          onSubmit={handleCreateOrder}
          onCancel={() => setShowOrderForm(false)}
        />
      )}

      {editingOrder && (
        <OrderForm
          order={editingOrder}
          onSubmit={(data) => handleUpdateOrder(editingOrder.id, data)}
          onCancel={() => setEditingOrder(null)}
        />
      )}

      {selectedOrder && (
        <OrderDetails
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
        />
      )}
    </div>
  );
};

export default PizzeriaInterface;