import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, RefreshCw } from 'lucide-react';

interface Position {
  lat: number;
  lng: number;
  timestamp?: string;
}

const LiveMap: React.FC = () => {
  const [livreurPosition, setLivreurPosition] = useState<Position | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  useEffect(() => {
    const updatePosition = () => {
      const stored = localStorage.getItem('livreurPosition');
      if (stored) {
        try {
          const position = JSON.parse(stored);
          setLivreurPosition(position);
          setLastUpdate(new Date(position.timestamp));
        } catch (error) {
          console.error('Error parsing livreur position:', error);
        }
      }
    };

    updatePosition();
    const interval = setInterval(updatePosition, 2000);

    return () => clearInterval(interval);
  }, []);

  const refreshPosition = () => {
    const stored = localStorage.getItem('livreurPosition');
    if (stored) {
      const position = JSON.parse(stored);
      setLivreurPosition(position);
      setLastUpdate(new Date(position.timestamp));
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Suivi GPS du livreur</h3>
        <button
          onClick={refreshPosition}
          className="flex items-center gap-1 text-blue-600 hover:text-blue-800 text-sm font-medium"
        >
          <RefreshCw className="w-4 h-4" />
          Actualiser
        </button>
      </div>

      {livreurPosition ? (
        <div className="bg-white rounded-lg border shadow-sm">
          {/* Mini Map Container */}
          <div className="relative h-64 bg-gradient-to-br from-green-100 to-blue-100 rounded-t-lg flex items-center justify-center">
            <div className="text-center">
              <div className="bg-red-500 w-8 h-8 rounded-full flex items-center justify-center mb-2 mx-auto animate-pulse">
                <MapPin className="w-5 h-5 text-white" />
              </div>
              <p className="text-sm font-medium text-gray-700">Position du livreur</p>
              <p className="text-xs text-gray-500">
                {livreurPosition.lat.toFixed(4)}, {livreurPosition.lng.toFixed(4)}
              </p>
            </div>
          </div>

          {/* Position Info */}
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Latitude</span>
              <span className="font-mono font-medium">{livreurPosition.lat.toFixed(6)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Longitude</span>
              <span className="font-mono font-medium">{livreurPosition.lng.toFixed(6)}</span>
            </div>
            {lastUpdate && (
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Dernière mise à jour</span>
                <span className="text-green-600 font-medium">
                  {lastUpdate.toLocaleTimeString()}
                </span>
              </div>
            )}

            {/* Quick Actions */}
            <div className="pt-3 border-t">
              <a
                href={`https://www.google.com/maps?q=${livreurPosition.lat},${livreurPosition.lng}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
              >
                <Navigation className="w-4 h-4" />
                Voir sur Google Maps
              </a>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-lg border shadow-sm p-8 text-center">
          <MapPin className="w-12 h-12 mx-auto mb-4 text-gray-400" />
          <p className="text-gray-600 mb-2">Position du livreur non disponible</p>
          <p className="text-sm text-gray-500">
            Le livreur doit être connecté et avoir activé sa géolocalisation
          </p>
        </div>
      )}

      {/* Info Card */}
      <div className="bg-blue-50 rounded-lg p-4">
        <h4 className="font-medium text-blue-800 mb-2">ℹ️ Information</h4>
        <p className="text-sm text-blue-700">
          La position du livreur se met à jour automatiquement toutes les 2 secondes quand il est connecté.
          Cliquez sur "Voir sur Google Maps" pour ouvrir la position dans votre application de navigation.
        </p>
      </div>
    </div>
  );
};

export default LiveMap;