import React, { useState, useEffect } from 'react';
import { Bell, MapPin, Euro, Check, Phone, Clock, LogOut, Wallet, History } from 'lucide-react';
import { Order } from '../types';
import { OrderService } from '../services/orderService';
import { NotificationService } from '../services/notificationService';
import { useAuth } from '../contexts/AuthContext';
import { useGeolocation } from '../hooks/useGeolocation';
import toast from 'react-hot-toast';
import MiniMap from './MiniMap';

const LivreurInterface: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [balance, setBalance] = useState(0);
  const [deliveredOrders, setDeliveredOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<'orders' | 'map' | 'balance'>('orders');
  const { logout } = useAuth();
  const { position } = useGeolocation();

  useEffect(() => {
    // Charger les commandes et le solde
    const loadData = () => {
      const allOrders = OrderService.getStoredOrders();
      const availableOrders = allOrders.filter(o => 
        o.status === 'ready' || o.status === 'accepted'
      );
      const completed = allOrders.filter(o => o.status === 'delivered');
      
      setOrders(availableOrders);
      setDeliveredOrders(completed);

      // Charger le solde
      const storedBalance = localStorage.getItem('livreurBalance');
      setBalance(storedBalance ? parseFloat(storedBalance) : 0);
    };

    loadData();

    // Écouter les changements en temps réel
    const unsubscribe = OrderService.subscribeToOrders(() => {
      loadData();
    });

    // Vérifier les nouvelles notifications
    const checkNotifications = () => {
      const notifications = NotificationService.getStoredNotifications();
      const unreadForLivreur = notifications.filter(n => 
        n.recipientId === 'livreur-1' && !n.read
      );

      unreadForLivreur.forEach(notification => {
        if (notification.type === 'new_order' || notification.type === 'order_ready') {
          toast.success(notification.message, {
            duration: 5000,
            icon: '🔔'
          });
          NotificationService.markAsRead(notification.id);
        }
      });
    };

    const notificationInterval = setInterval(checkNotifications, 2000);

    return () => {
      unsubscribe();
      clearInterval(notificationInterval);
    };
  }, []);

  const handleAcceptOrder = async (orderId: string) => {
    const result = await OrderService.updateOrder(orderId, { 
      status: 'accepted',
      assignedTo: 'livreur-1'
    });

    if (result.success) {
      toast.success('Commande acceptée !');
    } else {
      toast.error('Erreur lors de l\'acceptation');
    }
  };

  const handleCompleteDelivery = async (orderId: string, amount: number) => {
    const result = await OrderService.updateOrder(orderId, { 
      status: 'delivered',
      deliveredAt: new Date()
    });

    if (result.success) {
      // Ajouter 5€ au solde
      const newBalance = balance + 5;
      setBalance(newBalance);
      localStorage.setItem('livreurBalance', newBalance.toString());

      // Notifier la pizzeria
      await NotificationService.sendNotification({
        type: 'order_delivered',
        title: '✅ Commande livrée !',
        message: `Commande #${orderId} livrée avec succès`,
        recipientId: 'kiosk-1',
        orderId: orderId
      });

      toast.success('Livraison confirmée ! +5€ ajoutés à votre solde');
    } else {
      toast.error('Erreur lors de la confirmation');
    }
  };

  const getStatusBadge = (status: Order['status']) => {
    if (status === 'ready') {
      return { label: 'Prête à récupérer', class: 'bg-blue-100 text-blue-800' };
    } else if (status === 'accepted') {
      return { label: 'En livraison', class: 'bg-orange-100 text-orange-800' };
    }
    return { label: status, class: 'bg-gray-100 text-gray-800' };
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="px-4 py-3 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-800">🚚 Livreur Dashboard</h1>
            <p className="text-sm text-gray-600">Solde: {balance.toFixed(2)}€</p>
          </div>
          <button
            onClick={logout}
            className="flex items-center gap-2 text-gray-600 hover:text-red-600 transition-colors"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Navigation */}
      <div className="bg-white border-b">
        <div className="flex">
          <button
            onClick={() => setActiveTab('orders')}
            className={`flex-1 py-3 px-4 text-sm font-medium text-center transition-colors ${
              activeTab === 'orders' 
                ? 'border-b-2 border-green-600 text-green-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <div className="flex items-center justify-center gap-1">
              <Bell className="w-4 h-4" />
              Commandes ({orders.length})
            </div>
          </button>
          <button
            onClick={() => setActiveTab('map')}
            className={`flex-1 py-3 px-4 text-sm font-medium text-center transition-colors ${
              activeTab === 'map' 
                ? 'border-b-2 border-green-600 text-green-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <div className="flex items-center justify-center gap-1">
              <MapPin className="w-4 h-4" />
              Ma position
            </div>
          </button>
          <button
            onClick={() => setActiveTab('balance')}
            className={`flex-1 py-3 px-4 text-sm font-medium text-center transition-colors ${
              activeTab === 'balance' 
                ? 'border-b-2 border-green-600 text-green-600' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <div className="flex items-center justify-center gap-1">
              <Wallet className="w-4 h-4" />
              Solde
            </div>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {activeTab === 'orders' && (
          <div className="space-y-3">
            {orders.map((order) => (
              <div key={order.id} className="bg-white rounded-lg shadow-sm border p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(order.status).class}`}>
                        {getStatusBadge(order.status).label}
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-gray-500" />
                        <span className="text-sm font-medium">{order.customerAddress}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-600 bg-gray-100 px-2 py-1 rounded">
                          {order.city}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{order.pickupTime}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Euro className="w-4 h-4" />
                          <span className="font-medium text-green-600">{order.amount}€</span>
                        </div>
                      </div>

                      {order.customerPhone && (
                        <a
                          href={`tel:${order.customerPhone}`}
                          className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-800 text-sm font-medium"
                        >
                          <Phone className="w-4 h-4" />
                          {order.customerPhone}
                        </a>
                      )}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="pt-3 border-t">
                  {order.status === 'ready' && (
                    <button
                      onClick={() => handleAcceptOrder(order.id)}
                      className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-green-700 transition-colors"
                    >
                      <Check className="w-5 h-5" />
                      Accepter cette livraison
                    </button>
                  )}
                  
                  {order.status === 'accepted' && order.assignedTo === 'livreur-1' && (
                    <button
                      onClick={() => handleCompleteDelivery(order.id, order.amount)}
                      className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors"
                    >
                      <Check className="w-5 h-5" />
                      Confirmer la livraison
                    </button>
                  )}
                </div>
              </div>
            ))}

            {orders.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                <Bell className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p className="text-lg">Aucune livraison disponible</p>
                <p className="text-sm">Vous serez notifié des nouvelles commandes</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'map' && (
          <div className="bg-white rounded-lg shadow-sm p-4">
            <h3 className="text-lg font-medium mb-4">Ma position GPS</h3>
            <MiniMap position={position} />
            {position && (
              <div className="mt-4 text-sm text-gray-600">
                <p>Latitude: {position.lat.toFixed(6)}</p>
                <p>Longitude: {position.lng.toFixed(6)}</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'balance' && (
          <div className="space-y-4">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="text-center">
                <Wallet className="w-16 h-16 mx-auto mb-4 text-green-600" />
                <h2 className="text-3xl font-bold text-green-600 mb-2">
                  {balance.toFixed(2)}€
                </h2>
                <p className="text-gray-600">Solde actuel</p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-4">
              <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
                <History className="w-5 h-5" />
                Historique des livraisons
              </h3>
              
              <div className="space-y-3">
                {deliveredOrders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div>
                      <div className="font-medium text-sm">{order.city}</div>
                      <div className="text-xs text-gray-600">
                        {order.deliveredAt?.toLocaleDateString()} {order.deliveredAt?.toLocaleTimeString()}
                      </div>
                    </div>
                    <div className="text-green-600 font-medium">+5€</div>
                  </div>
                ))}

                {deliveredOrders.length === 0 && (
                  <p className="text-center text-gray-500 py-6">
                    Aucune livraison effectuée
                  </p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LivreurInterface;