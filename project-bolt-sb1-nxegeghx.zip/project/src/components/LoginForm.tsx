import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Pizza, Truck, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';

const LoginForm: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    setIsLoading(true);
    const success = await login(username, password);
    
    if (success) {
      toast.success('Connexion réussie !');
    } else {
      toast.error('Identifiants incorrects');
    }
    setIsLoading(false);
  };

  const quickLogin = async (role: string) => {
    setIsLoading(true);
    const success = await login(role, '1234');
    if (success) {
      toast.success(`Connecté en tant que ${role}`);
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-blue-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="bg-orange-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Pizza className="w-10 h-10 text-orange-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Pizza Express</h1>
          <p className="text-gray-600">Plateforme de livraison</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Identifiant
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              placeholder="livreur ou kiosk"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Mot de passe
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              placeholder="1234"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-orange-600 text-white py-3 px-4 rounded-lg hover:bg-orange-700 transition-colors font-medium disabled:opacity-50"
          >
            {isLoading ? 'Connexion...' : 'Se connecter'}
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-gray-200">
          <p className="text-center text-sm text-gray-500 mb-4">Connexion rapide</p>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => quickLogin('kiosk')}
              disabled={isLoading}
              className="flex items-center justify-center gap-2 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium disabled:opacity-50"
            >
              <Pizza className="w-4 h-4" />
              Pizzeria
            </button>
            <button
              onClick={() => quickLogin('livreur')}
              disabled={isLoading}
              className="flex items-center justify-center gap-2 bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors text-sm font-medium disabled:opacity-50"
            >
              <Truck className="w-4 h-4" />
              Livreur
            </button>
          </div>
        </div>

        <div className="mt-6 p-3 bg-yellow-50 rounded-lg flex items-start gap-2">
          <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-yellow-800">
            <p className="font-medium">Comptes de test :</p>
            <p>• Pizzeria: kiosk / 1234</p>
            <p>• Livreur: livreur / 1234</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;