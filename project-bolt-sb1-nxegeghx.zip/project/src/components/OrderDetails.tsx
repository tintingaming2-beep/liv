import React from 'react';
import { X, MapPin, Clock, Euro, Phone, Calendar } from 'lucide-react';
import { Order } from '../types';

interface OrderDetailsProps {
  order: Order;
  onClose: () => void;
}

const OrderDetails: React.FC<OrderDetailsProps> = ({ order, onClose }) => {
  const getStatusInfo = (status: Order['status']) => {
    const statusMap = {
      pending: { label: 'En attente', color: 'bg-yellow-100 text-yellow-800', icon: '⏳' },
      ready: { label: 'Prête', color: 'bg-blue-100 text-blue-800', icon: '✅' },
      accepted: { label: 'En livraison', color: 'bg-orange-100 text-orange-800', icon: '🚚' },
      delivered: { label: 'Livrée', color: 'bg-green-100 text-green-800', icon: '✨' },
      cancelled: { label: 'Annulée', color: 'bg-red-100 text-red-800', icon: '❌' }
    };
    return statusMap[status];
  };

  const statusInfo = getStatusInfo(order.status);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-bold">Détails de la commande</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Status */}
          <div className="text-center">
            <div className="text-4xl mb-2">{statusInfo.icon}</div>
            <span className={`px-4 py-2 rounded-full text-sm font-medium ${statusInfo.color}`}>
              {statusInfo.label}
            </span>
          </div>

          {/* Order Info */}
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-gray-500 mt-1 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-800">Adresse de livraison</p>
                <p className="text-gray-600">{order.customerAddress}</p>
                <p className="text-sm text-gray-500 bg-gray-100 inline-block px-2 py-1 rounded mt-1">
                  {order.city}
                </p>
              </div>
            </div>

            {order.customerPhone && (
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="font-medium text-gray-800">Téléphone client</p>
                  <a
                    href={`tel:${order.customerPhone}`}
                    className="text-blue-600 hover:text-blue-800 font-medium"
                  >
                    {order.customerPhone}
                  </a>
                </div>
              </div>
            )}

            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-gray-500" />
              <div>
                <p className="font-medium text-gray-800">Heure de récupération</p>
                <p className="text-gray-600">{order.pickupTime}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Euro className="w-5 h-5 text-gray-500" />
              <div>
                <p className="font-medium text-gray-800">Montant à encaisser</p>
                <p className="text-2xl font-bold text-green-600">{order.amount.toFixed(2)}€</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-gray-500" />
              <div>
                <p className="font-medium text-gray-800">Date de création</p>
                <p className="text-gray-600">
                  {order.createdAt.toLocaleDateString()} à {order.createdAt.toLocaleTimeString()}
                </p>
              </div>
            </div>

            {order.deliveredAt && (
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-green-500" />
                <div>
                  <p className="font-medium text-gray-800">Date de livraison</p>
                  <p className="text-green-600 font-medium">
                    {order.deliveredAt.toLocaleDateString()} à {order.deliveredAt.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Order ID */}
          <div className="pt-4 border-t">
            <p className="text-xs text-gray-500">ID Commande: {order.id}</p>
          </div>
        </div>

        <div className="p-4 border-t">
          <button
            onClick={onClose}
            className="w-full py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};

export default OrderDetails;