import { signInWithEmailAndPassword, signOut, User } from 'firebase/auth';
import { auth } from '../config/firebase';

const DEMO_ACCOUNTS = {
  livreur: { email: 'livreur@demo.com', password: '1234', role: 'livreur' as const },
  kiosk: { email: 'kiosk@demo.com', password: '1234', role: 'pizzeria' as const }
};

export const loginUser = async (username: string, password: string) => {
  try {
    if (username === 'livreur' && password === '1234') {
      // Simulation de connexion livreur
      return { success: true, user: { id: 'livreur-1', username: 'livreur', role: 'livreur' as const } };
    } else if (username === 'kiosk' && password === '1234') {
      // Simulation de connexion pizzeria
      return { success: true, user: { id: 'kiosk-1', username: 'kiosk', role: 'pizzeria' as const } };
    } else {
      throw new Error('Identifiants invalides');
    }
  } catch (error) {
    return { success: false, error: (error as Error).message };
  }
};

export const logoutUser = async () => {
  try {
    // Simulation de déconnexion
    return { success: true };
  } catch (error) {
    return { success: false, error: (error as Error).message };
  }
};