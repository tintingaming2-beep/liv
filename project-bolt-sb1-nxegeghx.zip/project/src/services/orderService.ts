import { collection, addDoc, updateDoc, deleteDoc, doc, onSnapshot, query, orderBy, Timestamp } from 'firebase/firestore';
import { db } from '../config/firebase';
import { Order } from '../types';

export class OrderService {
  private static ordersCollection = collection(db, 'orders');

  static async createOrder(orderData: Omit<Order, 'id' | 'createdAt' | 'updatedAt' | 'status'>) {
    try {
      // Simulation d'ajout sans Firebase pour le prototype
      const newOrder: Order = {
        ...orderData,
        id: `order-${Date.now()}`,
        status: 'pending',
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      // Stocker dans localStorage pour simulation
      const orders = this.getStoredOrders();
      orders.push(newOrder);
      localStorage.setItem('orders', JSON.stringify(orders));
      
      return { success: true, order: newOrder };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }

  static async updateOrder(orderId: string, updates: Partial<Order>) {
    try {
      const orders = this.getStoredOrders();
      const orderIndex = orders.findIndex(o => o.id === orderId);
      
      if (orderIndex === -1) {
        throw new Error('Commande non trouvée');
      }

      orders[orderIndex] = { ...orders[orderIndex], ...updates, updatedAt: new Date() };
      localStorage.setItem('orders', JSON.stringify(orders));
      
      return { success: true, order: orders[orderIndex] };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }

  static async deleteOrder(orderId: string) {
    try {
      const orders = this.getStoredOrders();
      const filteredOrders = orders.filter(o => o.id !== orderId);
      localStorage.setItem('orders', JSON.stringify(filteredOrders));
      
      return { success: true };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }

  static getStoredOrders(): Order[] {
    try {
      const stored = localStorage.getItem('orders');
      return stored ? JSON.parse(stored).map((order: any) => ({
        ...order,
        createdAt: new Date(order.createdAt),
        updatedAt: new Date(order.updatedAt),
        deliveredAt: order.deliveredAt ? new Date(order.deliveredAt) : undefined
      })) : [];
    } catch {
      return [];
    }
  }

  static subscribeToOrders(callback: (orders: Order[]) => void) {
    // Simulation d'écoute temps réel avec polling
    const interval = setInterval(() => {
      const orders = this.getStoredOrders();
      callback(orders);
    }, 1000);

    return () => clearInterval(interval);
  }
}