import { AppNotification } from '../types';

export class NotificationService {
  static async sendNotification(notification: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) {
    try {
      const newNotification: AppNotification = {
        ...notification,
        id: `notif-${Date.now()}`,
        timestamp: new Date(),
        read: false
      };

      // Stocker en localStorage pour simulation
      const notifications = this.getStoredNotifications();
      notifications.push(newNotification);
      localStorage.setItem('notifications', JSON.stringify(notifications));

      // Notification browser si autorisée
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(notification.title, {
          body: notification.message,
          icon: '/pizza-icon.png',
          badge: '/pizza-icon.png'
        });
      }

      return { success: true, notification: newNotification };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }

  static getStoredNotifications(): AppNotification[] {
    try {
      const stored = localStorage.getItem('notifications');
      return stored ? JSON.parse(stored).map((notif: any) => ({
        ...notif,
        timestamp: new Date(notif.timestamp)
      })) : [];
    } catch {
      return [];
    }
  }

  static markAsRead(notificationId: string) {
    const notifications = this.getStoredNotifications();
    const updatedNotifications = notifications.map(n => 
      n.id === notificationId ? { ...n, read: true } : n
    );
    localStorage.setItem('notifications', JSON.stringify(updatedNotifications));
  }

  static async requestPermission() {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }
    return false;
  }
}