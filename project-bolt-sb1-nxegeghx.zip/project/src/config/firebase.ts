// firebase.js

// Import Firebase SDKs
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getAnalytics, isSupported } from "firebase/analytics";

// 👉 Ta config Firebase (depuis la console)
const firebaseConfig = {
  apiKey: "AIzaSyBClvppqvQKaWsraAqXtaBn_KQM9WMxr88",
  authDomain: "delivery-platform-demo.firebaseapp.com",
  projectId: "delivery-platform-demo",
  storageBucket: "delivery-platform-demo.appspot.com", // ✅ corrigé
  messagingSenderId: "560862028112",
  appId: "1:560862028112:web:d0721d829c462ed4e1cc55",
  measurementId: "G-RX7RFGQ5NT"
};

// Initialisation de Firebase
const app = initializeApp(firebaseConfig);

// Services utilisés
export const auth = getAuth(app);
export const db = getFirestore(app);

// Analytics (optionnel + safe check pour éviter les erreurs en SSR/Node)
let analytics;
if (typeof window !== "undefined") {
  isSupported().then((yes) => {
    if (yes) {
      analytics = getAnalytics(app);
    }
  });
}

export { analytics };
export default app;
