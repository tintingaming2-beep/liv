/*
  # Schéma de base de données pour l'application de livraison pizza

  1. Nouvelles tables
    - `users` - Comptes utilisateurs (pizzeria/livreur)
    - `orders` - Commandes de livraison
    - `delivery_persons` - Informations des livreurs (solde, position)
    - `notifications` - Système de notifications
    - `balance_requests` - Demandes de remise à zéro du solde

  2. Sécurité
    - Activation de RLS sur toutes les tables
    - Politiques d'accès basées sur l'authentification
    - Restrictions d'accès par type d'utilisateur

  3. Fonctionnalités temps réel
    - Triggers pour les notifications automatiques
    - Mise à jour en temps réel des positions GPS
*/

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text UNIQUE NOT NULL,
  user_type text NOT NULL CHECK (user_type IN ('pizzeria', 'livreur')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Table des livreurs avec informations étendues
CREATE TABLE IF NOT EXISTS delivery_persons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT 'Livreur',
  balance decimal(10,2) DEFAULT 0,
  current_latitude decimal(10,8),
  current_longitude decimal(10,8),
  is_online boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Table des commandes
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pizzeria_id uuid REFERENCES users(id) ON DELETE CASCADE,
  customer_phone text NOT NULL,
  delivery_address text NOT NULL,
  delivery_time text NOT NULL,
  amount decimal(10,2) NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'ready', 'picked_up', 'delivered')),
  latitude decimal(10,8),
  longitude decimal(10,8),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Table des notifications
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('new_order', 'order_ready', 'order_delivered', 'balance_reset_request', 'balance_reset_response')),
  message text NOT NULL,
  read boolean DEFAULT false,
  data jsonb,
  created_at timestamptz DEFAULT now()
);

-- Table des demandes de remise à zéro du solde
CREATE TABLE IF NOT EXISTS balance_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_person_id uuid REFERENCES delivery_persons(id) ON DELETE CASCADE,
  amount decimal(10,2) NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Activation de RLS sur toutes les tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_persons ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE balance_requests ENABLE ROW LEVEL SECURITY;

-- Politiques RLS pour les utilisateurs
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Politiques RLS pour les livreurs
CREATE POLICY "Delivery persons can read own data"
  ON delivery_persons
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Delivery persons can update own data"
  ON delivery_persons
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Pizzeria can read delivery person data"
  ON delivery_persons
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users 
    WHERE users.id = auth.uid() 
    AND users.user_type = 'pizzeria'
  ));

-- Politiques RLS pour les commandes
CREATE POLICY "Users can read all orders"
  ON orders
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Pizzeria can insert orders"
  ON orders
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM users 
    WHERE users.id = auth.uid() 
    AND users.user_type = 'pizzeria'
  ));

CREATE POLICY "Pizzeria can update own orders"
  ON orders
  FOR UPDATE
  TO authenticated
  USING (pizzeria_id = auth.uid());

CREATE POLICY "Pizzeria can delete own orders"
  ON orders
  FOR DELETE
  TO authenticated
  USING (pizzeria_id = auth.uid());

-- Politiques RLS pour les notifications
CREATE POLICY "Users can read own notifications"
  ON notifications
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert notifications"
  ON notifications
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update own notifications"
  ON notifications
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

-- Politiques RLS pour les demandes de solde
CREATE POLICY "Users can read related balance requests"
  ON balance_requests
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM delivery_persons 
    WHERE delivery_persons.id = balance_requests.delivery_person_id 
    AND delivery_persons.user_id = auth.uid()
  ));

CREATE POLICY "Pizzeria can insert balance requests"
  ON balance_requests
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM users 
    WHERE users.id = auth.uid() 
    AND users.user_type = 'pizzeria'
  ));

CREATE POLICY "Users can update related balance requests"
  ON balance_requests
  FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM delivery_persons 
    WHERE delivery_persons.id = balance_requests.delivery_person_id 
    AND delivery_persons.user_id = auth.uid()
  ));

-- Index pour les performances
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read);
CREATE INDEX IF NOT EXISTS idx_delivery_persons_user_id ON delivery_persons(user_id);

-- Fonction pour mettre à jour automatiquement updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers pour updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_delivery_persons_updated_at BEFORE UPDATE ON delivery_persons FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_balance_requests_updated_at BEFORE UPDATE ON balance_requests FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();