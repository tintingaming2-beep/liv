import React, { useState } from 'react';
import { X, MapPin, Clock, Phone, Euro } from 'lucide-react';
import { geocodingService } from '../../utils/geocoding';

interface AddOrderFormProps {
  onClose: () => void;
  onAddOrder: (order: {
    id?: string;
    customerPhone: string;
    deliveryAddress: string;
    deliveryTime: string;
    amount: number;
  }) => void;
  editingOrder?: Order | null;
}

const AddOrderForm: React.FC<AddOrderFormProps> = ({ onClose, onAddOrder, editingOrder }) => {
  const [formData, setFormData] = useState({
    id: editingOrder?.id || '',
    customerPhone: editingOrder?.customerPhone || '',
    deliveryAddress: editingOrder?.deliveryAddress || '',
    deliveryTime: editingOrder?.deliveryTime || '',
    amount: editingOrder?.amount || 0
  });
  const [addressSuggestions, setAddressSuggestions] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (editingOrder) {
      setFormData({
        id: editingOrder.id,
        customerPhone: editingOrder.customerPhone,
        deliveryAddress: editingOrder.deliveryAddress,
        deliveryTime: editingOrder.deliveryTime,
        amount: editingOrder.amount
      });
    }
  }, [editingOrder]);

  const handleAddressChange = async (value: string) => {
    setFormData(prev => ({ ...prev, deliveryAddress: value }));
    
    if (value.length > 1) {
      const suggestions = await geocodingService.searchAddresses(value);
      setAddressSuggestions(suggestions);
    } else {
      setAddressSuggestions([]);
    }
  };

  const selectAddress = (address: string) => {
    setFormData(prev => ({ ...prev, deliveryAddress: address }));
    setAddressSuggestions([]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));

    onAddOrder(formData);
    setIsLoading(false);
    onClose();
  };

  const generateDefaultTime = () => {
    const now = new Date();
    now.setMinutes(now.getMinutes() + 30);
    return now.toTimeString().slice(0, 5);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-800">
            {editingOrder ? 'Modifier la commande' : 'Nouvelle commande'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-2">
              <Phone className="h-4 w-4" />
              <span>Téléphone client</span>
            </label>
            <input
              type="tel"
              value={formData.customerPhone}
              onChange={(e) => setFormData(prev => ({ ...prev, customerPhone: e.target.value }))}
              placeholder="06 12 34 56 78"
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200"
              required
            />
          </div>

          <div className="relative">
            <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-2">
              <MapPin className="h-4 w-4" />
              <span>Adresse de livraison</span>
            </label>
            <input
              type="text"
              value={formData.deliveryAddress}
              onChange={(e) => handleAddressChange(e.target.value)}
              placeholder="Commencez à taper l'adresse..."
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200"
              required
            />
            
            {addressSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-xl mt-1 shadow-lg z-10 max-h-48 overflow-y-auto">
                {addressSuggestions.map((address, index) => (
                  <button
                    key={index}
                    type="button"
                    onClick={() => selectAddress(address)}
                    className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors duration-200 border-b border-gray-100 last:border-b-0"
                  >
                    {address}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-2">
              <Clock className="h-4 w-4" />
              <span>Heure de livraison souhaitée</span>
            </label>
            <div className="flex space-x-2">
              <input
                type="time"
                value={formData.deliveryTime}
                onChange={(e) => setFormData(prev => ({ ...prev, deliveryTime: e.target.value }))}
                className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200"
                required
              />
              <button
                type="button"
                onClick={() => setFormData(prev => ({ ...prev, deliveryTime: generateDefaultTime() }))}
                className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-colors duration-200 whitespace-nowrap"
              >
                +30min
              </button>
            </div>
          </div>

          <div>
            <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-2">
              <Euro className="h-4 w-4" />
              <span>Montant à encaisser</span>
            </label>
            <div className="relative">
              <input
                type="number"
                step="0.01"
                min="0"
                value={formData.amount || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                placeholder="0.00"
                className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200"
                required
              />
              <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500">€</span>
            </div>
          </div>

          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 font-medium transition-colors duration-200"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl hover:from-orange-600 hover:to-red-600 font-medium transition-all duration-200 disabled:opacity-50"
            >
              {isLoading ? (editingOrder ? 'Modification...' : 'Création...') : (editingOrder ? 'Modifier' : 'Créer la commande')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddOrderForm;