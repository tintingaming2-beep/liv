import React, { useEffect, useState } from 'react';
import { Bell, Package, Check, X } from 'lucide-react';

interface NotificationPopupProps {
  message: string;
  type: 'new_order' | 'order_ready' | 'order_delivered' | 'balance_reset_request' | 'balance_reset_response';
  onClose: () => void;
  duration?: number;
}

const NotificationPopup: React.FC<NotificationPopupProps> = ({ 
  message, 
  type, 
  onClose, 
  duration = 5000 
}) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Animate in
    setTimeout(() => setIsVisible(true), 100);

    // Auto close
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onClose, 300);
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onClose]);

  const getIcon = () => {
    switch (type) {
      case 'new_order': return <Bell className="h-6 w-6" />;
      case 'order_ready': return <Package className="h-6 w-6" />;
      case 'order_delivered': return <Check className="h-6 w-6" />;
      case 'balance_reset_request': return <Bell className="h-6 w-6" />;
      case 'balance_reset_response': return <Check className="h-6 w-6" />;
    }
  };

  const getColors = () => {
    switch (type) {
      case 'new_order': return 'from-orange-500 to-red-500 text-white';
      case 'order_ready': return 'from-blue-500 to-purple-500 text-white';
      case 'order_delivered': return 'from-green-500 to-emerald-500 text-white';
      case 'balance_reset_request': return 'from-yellow-500 to-orange-500 text-white';
      case 'balance_reset_response': return 'from-green-500 to-emerald-500 text-white';
    }
  };

  const getTitle = () => {
    switch (type) {
      case 'new_order': return 'Nouvelle commande !';
      case 'order_ready': return 'Commande prête !';
      case 'order_delivered': return 'Livraison effectuée !';
      case 'balance_reset_request': return 'Demande de paiement !';
      case 'balance_reset_response': return 'Réponse reçue !';
    }
  };

  return (
    <div className="fixed top-4 right-4 z-50">
      <div 
        className={`transform transition-all duration-300 ${
          isVisible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'
        }`}
      >
        <div className={`bg-gradient-to-r ${getColors()} rounded-xl shadow-2xl p-4 max-w-sm min-w-[300px] border border-white/20`}>
          <div className="flex items-start space-x-3">
            <div className="bg-white/20 p-2 rounded-lg flex-shrink-0">
              {getIcon()}
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-sm mb-1">{getTitle()}</h4>
              <p className="text-sm opacity-90 leading-relaxed">{message}</p>
            </div>
            <button
              onClick={() => {
                setIsVisible(false);
                setTimeout(onClose, 300);
              }}
              className="bg-white/20 hover:bg-white/30 p-1 rounded-full transition-colors duration-200 flex-shrink-0"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationPopup;