import React from 'react';
import { Order } from '../../types';
import { Clock, Phone, MapPin, Euro, Check, Package, Truck } from 'lucide-react';

interface OrderCardProps {
  order: Order;
  userType: 'pizzeria' | 'livreur';
  onUpdateStatus?: (orderId: string, status: Order['status']) => void;
  onEditOrder?: (order: Order) => void;
  onDeleteOrder?: (orderId: string) => void;
  onCall?: (phone: string) => void;
}

const OrderCard: React.FC<OrderCardProps> = ({ order, userType, onUpdateStatus, onEditOrder, onDeleteOrder, onCall }) => {
  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'pending': return 'bg-orange-100 text-orange-800';
      case 'ready': return 'bg-blue-100 text-blue-800';
      case 'picked_up': return 'bg-purple-100 text-purple-800';
      case 'delivered': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'pending': return <Clock className="h-4 w-4" />;
      case 'ready': return <Package className="h-4 w-4" />;
      case 'picked_up': return <Truck className="h-4 w-4" />;
      case 'delivered': return <Check className="h-4 w-4" />;
    }
  };

  const getStatusText = (status: Order['status']) => {
    switch (status) {
      case 'pending': return 'En préparation';
      case 'ready': return 'Prête';
      case 'picked_up': return 'Récupérée';
      case 'delivered': return 'Livrée';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-orange-500">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-2">
          <span className={`px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-1 ${getStatusColor(order.status)}`}>
            {getStatusIcon(order.status)}
            <span>{getStatusText(order.status)}</span>
          </span>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-500">Commande #{order.id.slice(-6)}</p>
          <p className="text-xs text-gray-400">
            {order.createdAt.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
          </p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center space-x-3">
          <Clock className="h-5 w-5 text-gray-400" />
          <div>
            <p className="text-sm text-gray-600">Heure de livraison</p>
            <p className="font-semibold">{order.deliveryTime}</p>
          </div>
        </div>

        <div className="flex items-start space-x-3">
          <MapPin className="h-5 w-5 text-gray-400 mt-1" />
          <div className="flex-1">
            <p className="text-sm text-gray-600">Adresse de livraison</p>
            <p className="font-medium">{order.deliveryAddress}</p>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Phone className="h-5 w-5 text-gray-400" />
            <div>
              <p className="text-sm text-gray-600">Téléphone client</p>
              <p className="font-semibold">{order.customerPhone}</p>
            </div>
          </div>
          <button
            onClick={() => onCall?.(order.customerPhone)}
            className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors duration-200 flex items-center space-x-1"
          >
            <Phone className="h-4 w-4" />
            <span>Appeler</span>
          </button>
        </div>

        <div className="flex items-center space-x-3">
          <Euro className="h-5 w-5 text-gray-400" />
          <div>
            <p className="text-sm text-gray-600">Montant à encaisser</p>
            <p className="font-bold text-lg text-green-600">{order.amount}€</p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-6 flex space-x-3">
        {userType === 'pizzeria' && (order.status === 'pending' || order.status === 'ready') && (
          <>
            {onEditOrder && (
              <button
                onClick={() => onEditOrder(order)}
                className="flex-1 bg-gray-500 text-white py-3 rounded-lg font-medium hover:bg-gray-600 transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <span>Modifier</span>
              </button>
            )}
            {onDeleteOrder && (
              <button
                onClick={() => onDeleteOrder(order.id)}
                className="flex-1 bg-red-500 text-white py-3 rounded-lg font-medium hover:bg-red-600 transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <span>Supprimer</span>
              </button>
            )}
          </>
        )}

        {userType === 'pizzeria' && order.status === 'pending' && onUpdateStatus && (
          <button
            onClick={() => onUpdateStatus(order.id, 'ready')}
            className="flex-1 bg-blue-500 text-white py-3 rounded-lg font-medium hover:bg-blue-600 transition-colors duration-200 flex items-center justify-center space-x-2"
          >
            <Package className="h-4 w-4" />
            <span>Marquer comme prête</span>
          </button>
        )}

        {userType === 'livreur' && order.status === 'ready' && onUpdateStatus && (
          <button
            onClick={() => onUpdateStatus(order.id, 'picked_up')}
            className="flex-1 bg-purple-500 text-white py-3 rounded-lg font-medium hover:bg-purple-600 transition-colors duration-200 flex items-center justify-center space-x-2"
          >
            <Truck className="h-4 w-4" />
            <span>Récupérée</span>
          </button>
        )}

        {userType === 'livreur' && order.status === 'picked_up' && onUpdateStatus && (
          <button
            onClick={() => onUpdateStatus(order.id, 'delivered')}
            className="flex-1 bg-green-500 text-white py-3 rounded-lg font-medium hover:bg-green-600 transition-colors duration-200 flex items-center justify-center space-x-2"
          >
            <Check className="h-4 w-4" />
            <span>Livraison effectuée (+5€)</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default OrderCard;