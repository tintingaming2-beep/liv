import React, { useEffect, useRef } from 'react';
import { MapPin, Navigation } from 'lucide-react';

interface MapProps {
  centerLat?: number;
  centerLng?: number;
  deliveryLocation?: { lat: number; lng: number; address: string };
  livreurLocation?: { lat: number; lng: number };
  className?: string;
}

const Map: React.FC<MapProps> = ({
  centerLat = 50.2449,
  centerLng = 3.6352,
  deliveryLocation,
  livreurLocation,
  className = "h-64"
}) => {
  const mapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // In a real app, you would initialize Google Maps here
    // For now, we'll show a styled placeholder
  }, [centerLat, centerLng, deliveryLocation, livreurLocation]);

  return (
    <div 
      ref={mapRef}
      className={`${className} bg-gradient-to-br from-blue-100 to-green-100 rounded-xl relative overflow-hidden border-2 border-gray-200`}
    >
      {/* Map Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="grid grid-cols-8 grid-rows-8 h-full w-full">
          {Array.from({ length: 64 }).map((_, i) => (
            <div key={i} className="border border-gray-300"></div>
          ))}
        </div>
      </div>

      {/* Center Point (Le Quesnoy) */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div className="bg-orange-500 w-3 h-3 rounded-full animate-pulse"></div>
        <span className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-xs font-medium text-gray-700 whitespace-nowrap">
          Le Quesnoy
        </span>
      </div>

      {/* Delivery Location */}
      {deliveryLocation && (
        <div className="absolute top-1/4 right-1/4 transform">
          <MapPin className="h-6 w-6 text-red-500 animate-bounce" />
          <span className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-xs font-medium text-red-600 whitespace-nowrap">
            Livraison
          </span>
        </div>
      )}

      {/* Livreur Location */}
      {livreurLocation && (
        <div className="absolute bottom-1/3 left-1/3 transform">
          <Navigation className="h-6 w-6 text-blue-500 animate-pulse" />
          <span className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-xs font-medium text-blue-600 whitespace-nowrap">
            Livreur
          </span>
        </div>
      )}

      {/* Distance Indicator */}
      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-2 rounded-lg shadow-lg">
        <span className="text-sm font-medium text-gray-700">Zone: 20km</span>
      </div>

      {/* Map Controls */}
      <div className="absolute bottom-4 right-4 flex flex-col space-y-2">
        <button className="bg-white/90 backdrop-blur-sm p-2 rounded-lg shadow-lg hover:bg-white transition-colors">
          <span className="text-lg font-bold text-gray-700">+</span>
        </button>
        <button className="bg-white/90 backdrop-blur-sm p-2 rounded-lg shadow-lg hover:bg-white transition-colors">
          <span className="text-lg font-bold text-gray-700">−</span>
        </button>
      </div>
    </div>
  );
};

export default Map;