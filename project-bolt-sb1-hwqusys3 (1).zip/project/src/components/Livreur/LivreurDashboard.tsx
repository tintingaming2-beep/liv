import React, { useState, useEffect } from 'react';
import { Navigation, DollarSign, History, MapPin, LogOut, Phone, Clock } from 'lucide-react';
import { Order, DeliveryPerson } from '../../types';
import { storage } from '../../utils/storage';
import { notificationService } from '../../utils/notifications';
import { AppNotification } from '../../types';
import OrderCard from '../Shared/OrderCard';
import Map from '../Shared/Map';
import NotificationBell from '../Shared/NotificationBell';
import NotificationPopup from '../Shared/NotificationPopup';

interface LivreurDashboardProps {
  onLogout: () => void;
}

const LivreurDashboard: React.FC<LivreurDashboardProps> = ({ onLogout }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [deliveryPerson, setDeliveryPerson] = useState<DeliveryPerson>({
    id: 'livreur-1',
    name: 'Livreur',
    balance: 0,
    isOnline: false
  });
  const [activeTab, setActiveTab] = useState<'available' | 'history'>('available');
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [currentNotification, setCurrentNotification] = useState<AppNotification | null>(null);

  useEffect(() => {
    loadOrders();
    loadDeliveryPerson();
    startLocationTracking();

    // Request notification permission
    notificationService.requestPermission();

    // Auto-refresh orders every 5 seconds
    const interval = setInterval(() => {
      loadOrders();
    }, 5000);

    // Listen for notifications
    const handleNotification = (notification: AppNotification) => {
      if (notification.type === 'new_order' || notification.type === 'order_ready' || notification.type === 'balance_reset_request') {
        setCurrentNotification(notification);
      }
    };

    notificationService.addNotificationListener(handleNotification);

    return () => {
      clearInterval(interval);
      notificationService.removeNotificationListener(handleNotification);
    };
  }, []);

  const loadOrders = () => {
    const allOrders = storage.getOrders();
    setOrders(allOrders.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()));
  };

  const loadDeliveryPerson = () => {
    const person = storage.getDeliveryPerson();
    setDeliveryPerson(person);
  };

  const startLocationTracking = () => {
    if (navigator.geolocation) {
      navigator.geolocation.watchPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation({ lat: latitude, lng: longitude });
          
          // Update delivery person location
          storage.updateDeliveryPerson({
            currentLatitude: latitude,
            currentLongitude: longitude,
            isOnline: true
          });
          loadDeliveryPerson();
        },
        (error) => {
          console.log('Error getting location:', error);
          // Simulate location around Le Quesnoy
          const simulatedLat = 50.2449 + (Math.random() - 0.5) * 0.01;
          const simulatedLng = 3.6352 + (Math.random() - 0.5) * 0.01;
          
          setLocation({ lat: simulatedLat, lng: simulatedLng });
          storage.updateDeliveryPerson({
            currentLatitude: simulatedLat,
            currentLongitude: simulatedLng,
            isOnline: true
          });
          loadDeliveryPerson();
        },
        { enableHighAccuracy: true, maximumAge: 10000, timeout: 15000 }
      );
    }
  };

  const handleUpdateOrderStatus = (orderId: string, status: Order['status']) => {
    storage.updateOrder(orderId, { status });
    
    if (status === 'delivered') {
      // Add 5€ to balance
      const newBalance = deliveryPerson.balance + 5;
      storage.updateDeliveryPerson({ balance: newBalance });
      setDeliveryPerson(prev => ({ ...prev, balance: newBalance }));

      notificationService.addNotification(
        'order_delivered',
        `Livraison terminée! +5€ ajoutés à votre solde`
      );
    }
    
    loadOrders();
  };

  const handleBalanceResetResponse = (requestId: string, accepted: boolean) => {
    if (accepted) {
      storage.updateDeliveryPerson({ balance: 0 });
      setDeliveryPerson(prev => ({ ...prev, balance: 0 }));
      
      notificationService.addNotification(
        'balance_reset_response',
        `Solde remis à zéro avec succès`
      );
    } else {
      notificationService.addNotification(
        'balance_reset_response',
        `Demande de remise à zéro refusée`
      );
    }
    
    storage.updateBalanceRequest(requestId, { 
      status: accepted ? 'accepted' : 'rejected' 
    });
    
    setCurrentNotification(null);
  };

  const handleCall = (phoneNumber: string) => {
    window.open(`tel:${phoneNumber}`);
  };

  const toggleOnlineStatus = () => {
    const newStatus = !deliveryPerson.isOnline;
    storage.updateDeliveryPerson({ isOnline: newStatus });
    setDeliveryPerson(prev => ({ ...prev, isOnline: newStatus }));
  };

  const availableOrders = orders.filter(order => 
    order.status === 'ready' || order.status === 'picked_up'
  );
  const completedOrders = orders.filter(order => order.status === 'delivered');

  const todayStats = {
    deliveries: completedOrders.filter(order => {
      const today = new Date();
      return order.updatedAt.toDateString() === today.toDateString();
    }).length,
    earnings: completedOrders.filter(order => {
      const today = new Date();
      return order.updatedAt.toDateString() === today.toDateString();
    }).length * 5
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-800">Livreur Dashboard</h1>
              <div className="flex items-center space-x-2 mt-1">
                <div className={`w-2 h-2 rounded-full ${deliveryPerson.isOnline ? 'bg-green-500' : 'bg-red-500'}`}></div>
                <p className="text-sm text-gray-600">
                  {deliveryPerson.isOnline ? 'En ligne' : 'Hors ligne'}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={toggleOnlineStatus}
                className={`px-4 py-2 rounded-xl font-medium transition-colors duration-200 ${
                  deliveryPerson.isOnline
                    ? 'bg-red-100 text-red-700 hover:bg-red-200'
                    : 'bg-green-100 text-green-700 hover:bg-green-200'
                }`}
              >
                {deliveryPerson.isOnline ? 'Se déconnecter' : 'Se connecter'}
              </button>
              <NotificationBell userType="livreur" />
              <button
                onClick={onLogout}
                className="p-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors duration-200"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="px-4 py-6">
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex flex-col items-center text-center">
              <div className="bg-green-100 p-2 rounded-lg mb-2">
                <DollarSign className="h-5 w-5 text-green-600" />
              </div>
              <p className="text-sm text-gray-600">Solde</p>
              <p className="text-xl font-bold text-green-600">{deliveryPerson.balance}€</p>
            </div>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex flex-col items-center text-center">
              <div className="bg-blue-100 p-2 rounded-lg mb-2">
                <Navigation className="h-5 w-5 text-blue-600" />
              </div>
              <p className="text-sm text-gray-600">Aujourd'hui</p>
              <p className="text-xl font-bold text-gray-800">{todayStats.deliveries}</p>
            </div>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex flex-col items-center text-center">
              <div className="bg-orange-100 p-2 rounded-lg mb-2">
                <Clock className="h-5 w-5 text-orange-600" />
              </div>
              <p className="text-sm text-gray-600">Disponibles</p>
              <p className="text-xl font-bold text-gray-800">{availableOrders.length}</p>
            </div>
          </div>
        </div>

        {/* Map Section */}
        {location && (
          <div className="bg-white rounded-xl p-4 shadow-sm mb-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center space-x-2">
              <MapPin className="h-5 w-5" />
              <span>Ma position</span>
            </h3>
            <Map
              centerLat={location.lat}
              centerLng={location.lng}
              livreurLocation={location}
              deliveryLocation={
                availableOrders.length > 0 && availableOrders[0].latitude && availableOrders[0].longitude
                  ? {
                      lat: availableOrders[0].latitude,
                      lng: availableOrders[0].longitude,
                      address: availableOrders[0].deliveryAddress
                    }
                  : undefined
              }
              className="h-48"
            />
          </div>
        )}

        {/* Quick Actions */}
        {availableOrders.length > 0 && (
          <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-xl p-4 text-white mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">Prochaine livraison</h3>
                <p className="text-sm opacity-90">{availableOrders[0].deliveryAddress}</p>
                <p className="text-sm opacity-90">À livrer: {availableOrders[0].deliveryTime}</p>
              </div>
              <button
                onClick={() => handleCall(availableOrders[0].customerPhone)}
                className="bg-white/20 backdrop-blur-sm p-3 rounded-full hover:bg-white/30 transition-colors duration-200"
              >
                <Phone className="h-5 w-5" />
              </button>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="flex space-x-4 mb-6">
          <button
            onClick={() => setActiveTab('available')}
            className={`flex-1 py-3 px-4 rounded-xl font-medium transition-colors duration-200 ${
              activeTab === 'available'
                ? 'bg-blue-500 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
          >
            Disponibles ({availableOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-3 px-4 rounded-xl font-medium transition-colors duration-200 ${
              activeTab === 'history'
                ? 'bg-blue-500 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
          >
            Historique ({completedOrders.length})
          </button>
        </div>

        {/* Orders List */}
        <div className="space-y-4 pb-6">
          {activeTab === 'available' ? (
            availableOrders.length > 0 ? (
              availableOrders.map(order => (
                <OrderCard
                  key={order.id}
                  order={order}
                  userType="livreur"
                  onUpdateStatus={handleUpdateOrderStatus}
                  onCall={handleCall}
                />
              ))
            ) : (
              <div className="bg-white rounded-xl p-8 text-center">
                <Navigation className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Aucune livraison disponible</p>
                <p className="text-sm text-gray-400 mt-1">
                  {deliveryPerson.isOnline 
                    ? "Vous recevrez une notification dès qu'une commande sera prête"
                    : "Connectez-vous pour recevoir des commandes"
                  }
                </p>
              </div>
            )
          ) : (
            completedOrders.length > 0 ? (
              completedOrders.map(order => (
                <OrderCard
                  key={order.id}
                  order={order}
                  userType="livreur"
                  onCall={handleCall}
                />
              ))
            ) : (
              <div className="bg-white rounded-xl p-8 text-center">
                <History className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Aucune livraison terminée</p>
              </div>
            )
          )}
        </div>
      </div>

      {/* Notification Popup */}
      {currentNotification && (
        currentNotification.type === 'balance_reset_request' ? (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md">
              <h3 className="text-lg font-bold text-gray-800 mb-4">Demande de remise à zéro</h3>
              <p className="text-gray-600 mb-6">{currentNotification.message}</p>
              <div className="flex space-x-3">
                <button
                  onClick={() => handleBalanceResetResponse(currentNotification.data?.requestId, false)}
                  className="flex-1 bg-gray-500 text-white py-3 rounded-lg font-medium hover:bg-gray-600 transition-colors duration-200"
                >
                  Refuser
                </button>
                <button
                  onClick={() => handleBalanceResetResponse(currentNotification.data?.requestId, true)}
                  className="flex-1 bg-green-500 text-white py-3 rounded-lg font-medium hover:bg-green-600 transition-colors duration-200"
                >
                  Accepter
                </button>
              </div>
            </div>
          </div>
        ) : (
          <NotificationPopup
            message={currentNotification.message}
            type={currentNotification.type}
            onClose={() => setCurrentNotification(null)}
          />
        )
      )}
    </div>
  );
};

export default LivreurDashboard;