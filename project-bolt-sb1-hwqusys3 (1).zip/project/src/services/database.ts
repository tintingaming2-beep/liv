import { supabase } from '../lib/supabase';
import { Order, User, DeliveryPerson, AppNotification, BalanceResetRequest } from '../types';
import { geocodingService } from '../utils/geocoding';

export class DatabaseService {
  // ==================== AUTHENTIFICATION ====================
  
  async signInWithCredentials(username: string, password: string): Promise<User | null> {
    try {
      // Pour le prototype, on utilise une authentification simple
      const validCredentials = [
        { username: 'livreur', password: '1234', type: 'livreur' as const },
        { username: 'kiosk', password: '1234', type: 'pizzeria' as const }
      ];

      const credential = validCredentials.find(
        cred => cred.username === username && cred.password === password
      );

      if (!credential) return null;

      // Vérifier si l'utilisateur existe déjà
      const { data: existingUser } = await supabase
        .from('users')
        .select('*')
        .eq('username', username)
        .single();

      let user: User;

      if (existingUser) {
        user = {
          id: existingUser.id,
          username: existingUser.username,
          type: existingUser.user_type
        };
      } else {
        // Créer l'utilisateur
        const { data: newUser, error } = await supabase
          .from('users')
          .insert({
            username: credential.username,
            user_type: credential.type
          })
          .select()
          .single();

        if (error) throw error;

        user = {
          id: newUser.id,
          username: newUser.username,
          type: newUser.user_type
        };

        // Si c'est un livreur, créer son profil de livreur
        if (credential.type === 'livreur') {
          await supabase
            .from('delivery_persons')
            .insert({
              user_id: newUser.id,
              name: 'Livreur',
              balance: 0,
              is_online: false
            });
        }
      }

      return user;
    } catch (error) {
      console.error('Erreur de connexion:', error);
      return null;
    }
  }

  // ==================== COMMANDES ====================

  async getOrders(): Promise<Order[]> {
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      return data.map(order => ({
        id: order.id,
        pizzeriaId: order.pizzeria_id,
        customerPhone: order.customer_phone,
        deliveryAddress: order.delivery_address,
        deliveryTime: order.delivery_time,
        amount: order.amount,
        status: order.status,
        latitude: order.latitude,
        longitude: order.longitude,
        createdAt: new Date(order.created_at),
        updatedAt: new Date(order.updated_at)
      }));
    } catch (error) {
      console.error('Erreur lors du chargement des commandes:', error);
      return [];
    }
  }

  async addOrder(orderData: {
    pizzeriaId: string;
    customerPhone: string;
    deliveryAddress: string;
    deliveryTime: string;
    amount: number;
  }): Promise<Order | null> {
    try {
      // Géocoder l'adresse
      const coordinates = await geocodingService.geocodeAddress(orderData.deliveryAddress);

      const { data, error } = await supabase
        .from('orders')
        .insert({
          pizzeria_id: orderData.pizzeriaId,
          customer_phone: orderData.customerPhone,
          delivery_address: orderData.deliveryAddress,
          delivery_time: orderData.deliveryTime,
          amount: orderData.amount,
          latitude: coordinates?.lat,
          longitude: coordinates?.lng,
          status: 'pending'
        })
        .select()
        .single();

      if (error) throw error;

      // Envoyer notification au livreur
      await this.sendNotificationToLivreurs(
        'new_order',
        `Nouvelle commande: ${orderData.deliveryAddress} - ${orderData.deliveryTime}`
      );

      return {
        id: data.id,
        pizzeriaId: data.pizzeria_id,
        customerPhone: data.customer_phone,
        deliveryAddress: data.delivery_address,
        deliveryTime: data.delivery_time,
        amount: data.amount,
        status: data.status,
        latitude: data.latitude,
        longitude: data.longitude,
        createdAt: new Date(data.created_at),
        updatedAt: new Date(data.updated_at)
      };
    } catch (error) {
      console.error('Erreur lors de l\'ajout de la commande:', error);
      return null;
    }
  }

  async updateOrder(orderId: string, updates: Partial<Order>): Promise<boolean> {
    try {
      const updateData: any = {};
      
      if (updates.customerPhone) updateData.customer_phone = updates.customerPhone;
      if (updates.deliveryAddress) updateData.delivery_address = updates.deliveryAddress;
      if (updates.deliveryTime) updateData.delivery_time = updates.deliveryTime;
      if (updates.amount !== undefined) updateData.amount = updates.amount;
      if (updates.status) updateData.status = updates.status;
      if (updates.latitude !== undefined) updateData.latitude = updates.latitude;
      if (updates.longitude !== undefined) updateData.longitude = updates.longitude;

      const { error } = await supabase
        .from('orders')
        .update(updateData)
        .eq('id', orderId);

      if (error) throw error;

      // Envoyer notifications selon le statut
      if (updates.status === 'ready') {
        await this.sendNotificationToLivreurs(
          'order_ready',
          `Commande #${orderId.slice(-6)} prête à être récupérée`
        );
      } else if (updates.status === 'delivered') {
        await this.sendNotificationToPizzeria(
          'order_delivered',
          `Livraison terminée pour la commande #${orderId.slice(-6)}`
        );
      }

      return true;
    } catch (error) {
      console.error('Erreur lors de la mise à jour de la commande:', error);
      return false;
    }
  }

  async deleteOrder(orderId: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('orders')
        .delete()
        .eq('id', orderId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Erreur lors de la suppression de la commande:', error);
      return false;
    }
  }

  // ==================== LIVREURS ====================

  async getDeliveryPerson(userId: string): Promise<DeliveryPerson | null> {
    try {
      const { data, error } = await supabase
        .from('delivery_persons')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error) throw error;

      return {
        id: data.id,
        name: data.name,
        balance: data.balance,
        currentLatitude: data.current_latitude,
        currentLongitude: data.current_longitude,
        isOnline: data.is_online
      };
    } catch (error) {
      console.error('Erreur lors du chargement du livreur:', error);
      return null;
    }
  }

  async updateDeliveryPerson(userId: string, updates: Partial<DeliveryPerson>): Promise<boolean> {
    try {
      const updateData: any = {};
      
      if (updates.name) updateData.name = updates.name;
      if (updates.balance !== undefined) updateData.balance = updates.balance;
      if (updates.currentLatitude !== undefined) updateData.current_latitude = updates.currentLatitude;
      if (updates.currentLongitude !== undefined) updateData.current_longitude = updates.currentLongitude;
      if (updates.isOnline !== undefined) updateData.is_online = updates.isOnline;

      const { error } = await supabase
        .from('delivery_persons')
        .update(updateData)
        .eq('user_id', userId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Erreur lors de la mise à jour du livreur:', error);
      return false;
    }
  }

  // ==================== NOTIFICATIONS ====================

  async getNotifications(userId: string): Promise<AppNotification[]> {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      return data.map(notif => ({
        id: notif.id,
        type: notif.type,
        message: notif.message,
        timestamp: new Date(notif.created_at),
        read: notif.read,
        data: notif.data
      }));
    } catch (error) {
      console.error('Erreur lors du chargement des notifications:', error);
      return [];
    }
  }

  async addNotification(userId: string, type: AppNotification['type'], message: string, data?: any): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('notifications')
        .insert({
          user_id: userId,
          type,
          message,
          data,
          read: false
        });

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Erreur lors de l\'ajout de la notification:', error);
      return false;
    }
  }

  async markNotificationAsRead(notificationId: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('id', notificationId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Erreur lors du marquage de la notification:', error);
      return false;
    }
  }

  // ==================== DEMANDES DE SOLDE ====================

  async addBalanceRequest(deliveryPersonId: string, amount: number): Promise<string | null> {
    try {
      const { data, error } = await supabase
        .from('balance_requests')
        .insert({
          delivery_person_id: deliveryPersonId,
          amount,
          status: 'pending'
        })
        .select()
        .single();

      if (error) throw error;
      return data.id;
    } catch (error) {
      console.error('Erreur lors de la création de la demande de solde:', error);
      return null;
    }
  }

  async updateBalanceRequest(requestId: string, status: 'accepted' | 'rejected'): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('balance_requests')
        .update({ status })
        .eq('id', requestId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Erreur lors de la mise à jour de la demande de solde:', error);
      return false;
    }
  }

  // ==================== MÉTHODES UTILITAIRES ====================

  private async sendNotificationToLivreurs(type: AppNotification['type'], message: string, data?: any) {
    try {
      const { data: livreurs } = await supabase
        .from('users')
        .select('id')
        .eq('user_type', 'livreur');

      if (livreurs) {
        for (const livreur of livreurs) {
          await this.addNotification(livreur.id, type, message, data);
        }
      }
    } catch (error) {
      console.error('Erreur lors de l\'envoi de notifications aux livreurs:', error);
    }
  }

  private async sendNotificationToPizzeria(type: AppNotification['type'], message: string, data?: any) {
    try {
      const { data: pizzerias } = await supabase
        .from('users')
        .select('id')
        .eq('user_type', 'pizzeria');

      if (pizzerias) {
        for (const pizzeria of pizzerias) {
          await this.addNotification(pizzeria.id, type, message, data);
        }
      }
    } catch (error) {
      console.error('Erreur lors de l\'envoi de notifications aux pizzerias:', error);
    }
  }

  // ==================== TEMPS RÉEL ====================

  subscribeToOrders(callback: (orders: Order[]) => void) {
    return supabase
      .channel('orders')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'orders' },
        () => {
          this.getOrders().then(callback);
        }
      )
      .subscribe();
  }

  subscribeToNotifications(userId: string, callback: (notifications: AppNotification[]) => void) {
    return supabase
      .channel(`notifications_${userId}`)
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'notifications', filter: `user_id=eq.${userId}` },
        () => {
          this.getNotifications(userId).then(callback);
        }
      )
      .subscribe();
  }

  subscribeToDeliveryPerson(userId: string, callback: (deliveryPerson: DeliveryPerson | null) => void) {
    return supabase
      .channel(`delivery_person_${userId}`)
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'delivery_persons', filter: `user_id=eq.${userId}` },
        () => {
          this.getDeliveryPerson(userId).then(callback);
        }
      )
      .subscribe();
  }
}

export const databaseService = new DatabaseService();