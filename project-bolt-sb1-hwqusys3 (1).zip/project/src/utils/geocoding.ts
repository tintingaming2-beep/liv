const QUESNOY_CENTER = {
  lat: 50.2449,
  lng: 3.6352
};

const RADIUS_KM = 20;

export const geocodingService = {
  async searchAddresses(query: string): Promise<string[]> {
    // Simulate address search with common addresses around Le Quesnoy
    const commonAddresses = [
      'Avenue de la Gare, Le Quesnoy',
      'Rue du Général de Gaulle, Le Quesnoy',
      'Place du Général Leclerc, Le Quesnoy',
      'Rue de Valenciennes, Le Quesnoy',
      'Avenue Anatole France, Le Quesnoy',
      'Rue Jean Jaurès, Bavay',
      'Grande Rue, Gommegnies',
      'Rue de la Mairie, Frasnoy',
      'Avenue du Général de Gaulle, Jenlain',
      'Rue Principale, Jolimetz'
    ];

    if (!query || query.length < 2) return [];

    return commonAddresses
      .filter(addr => addr.toLowerCase().includes(query.toLowerCase()))
      .slice(0, 5);
  },

  async geocodeAddress(address: string): Promise<{ lat: number; lng: number } | null> {
    // Simulate geocoding - in real app, use Google Maps API or similar
    const randomOffset = () => (Math.random() - 0.5) * 0.3; // ~15km radius
    
    return {
      lat: QUESNOY_CENTER.lat + randomOffset(),
      lng: QUESNOY_CENTER.lng + randomOffset()
    };
  },

  calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }
};