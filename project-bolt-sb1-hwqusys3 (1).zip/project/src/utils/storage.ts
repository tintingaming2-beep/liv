import { Order, User, DeliveryPerson, Notification } from '../types';

const STORAGE_KEYS = {
  CURRENT_USER: 'currentUser',
  ORDERS: 'orders',
  DELIVERY_PERSON: 'deliveryPerson',
  NOTIFICATIONS: 'notifications',
  BALANCE_REQUESTS: 'balanceRequests'
};

export const storage = {
  getCurrentUser: (): User | null => {
    const user = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return user ? JSON.parse(user) : null;
  },

  setCurrentUser: (user: User) => {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  },

  clearCurrentUser: () => {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  },

  getOrders: (): Order[] => {
    const orders = localStorage.getItem(STORAGE_KEYS.ORDERS);
    return orders ? JSON.parse(orders).map((order: any) => ({
      ...order,
      createdAt: new Date(order.createdAt),
      updatedAt: new Date(order.updatedAt)
    })) : [];
  },

  addOrder: (order: Order) => {
    const orders = storage.getOrders();
    orders.push(order);
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  },

  updateOrder: (orderId: string, updates: Partial<Order>) => {
    const orders = storage.getOrders();
    const index = orders.findIndex(order => order.id === orderId);
    if (index !== -1) {
      orders[index] = { ...orders[index], ...updates, updatedAt: new Date() };
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    }
  },

  deleteOrder: (orderId: string) => {
    const orders = storage.getOrders();
    const filteredOrders = orders.filter(order => order.id !== orderId);
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(filteredOrders));
  },

  getDeliveryPerson: (): DeliveryPerson => {
    const person = localStorage.getItem(STORAGE_KEYS.DELIVERY_PERSON);
    return person ? JSON.parse(person) : {
      id: 'livreur-1',
      name: 'Livreur',
      balance: 0,
      isOnline: false
    };
  },

  updateDeliveryPerson: (updates: Partial<DeliveryPerson>) => {
    const person = storage.getDeliveryPerson();
    const updated = { ...person, ...updates };
    localStorage.setItem(STORAGE_KEYS.DELIVERY_PERSON, JSON.stringify(updated));
  },

  getNotifications: (): Notification[] => {
    const notifications = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    return notifications ? JSON.parse(notifications).map((notif: any) => ({
      ...notif,
      timestamp: new Date(notif.timestamp)
    })) : [];
  },

  addNotification: (notification: Notification) => {
    const notifications = storage.getNotifications();
    notifications.unshift(notification);
    // Keep only last 50 notifications
    notifications.splice(50);
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  },

  getBalanceRequests: (): any[] => {
    const requests = localStorage.getItem(STORAGE_KEYS.BALANCE_REQUESTS);
    return requests ? JSON.parse(requests) : [];
  },

  addBalanceRequest: (request: any) => {
    const requests = storage.getBalanceRequests();
    requests.unshift(request);
    localStorage.setItem(STORAGE_KEYS.BALANCE_REQUESTS, JSON.stringify(requests));
  },

  updateBalanceRequest: (requestId: string, updates: any) => {
    const requests = storage.getBalanceRequests();
    const index = requests.findIndex(req => req.id === requestId);
    if (index !== -1) {
      requests[index] = { ...requests[index], ...updates };
      localStorage.setItem(STORAGE_KEYS.BALANCE_REQUESTS, JSON.stringify(requests));
    }
  }
};