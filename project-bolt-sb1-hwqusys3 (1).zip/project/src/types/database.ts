export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          username: string;
          user_type: 'pizzeria' | 'livreur';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          username: string;
          user_type: 'pizzeria' | 'livreur';
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          username?: string;
          user_type?: 'pizzeria' | 'livreur';
          created_at?: string;
          updated_at?: string;
        };
      };
      delivery_persons: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          balance: number;
          current_latitude: number | null;
          current_longitude: number | null;
          is_online: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name?: string;
          balance?: number;
          current_latitude?: number | null;
          current_longitude?: number | null;
          is_online?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          name?: string;
          balance?: number;
          current_latitude?: number | null;
          current_longitude?: number | null;
          is_online?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      orders: {
        Row: {
          id: string;
          pizzeria_id: string;
          customer_phone: string;
          delivery_address: string;
          delivery_time: string;
          amount: number;
          status: 'pending' | 'ready' | 'picked_up' | 'delivered';
          latitude: number | null;
          longitude: number | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          pizzeria_id: string;
          customer_phone: string;
          delivery_address: string;
          delivery_time: string;
          amount: number;
          status?: 'pending' | 'ready' | 'picked_up' | 'delivered';
          latitude?: number | null;
          longitude?: number | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          pizzeria_id?: string;
          customer_phone?: string;
          delivery_address?: string;
          delivery_time?: string;
          amount?: number;
          status?: 'pending' | 'ready' | 'picked_up' | 'delivered';
          latitude?: number | null;
          longitude?: number | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          type: 'new_order' | 'order_ready' | 'order_delivered' | 'balance_reset_request' | 'balance_reset_response';
          message: string;
          read: boolean;
          data: any;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          type: 'new_order' | 'order_ready' | 'order_delivered' | 'balance_reset_request' | 'balance_reset_response';
          message: string;
          read?: boolean;
          data?: any;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          type?: 'new_order' | 'order_ready' | 'order_delivered' | 'balance_reset_request' | 'balance_reset_response';
          message?: string;
          read?: boolean;
          data?: any;
          created_at?: string;
        };
      };
      balance_requests: {
        Row: {
          id: string;
          delivery_person_id: string;
          amount: number;
          status: 'pending' | 'accepted' | 'rejected';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          delivery_person_id: string;
          amount: number;
          status?: 'pending' | 'accepted' | 'rejected';
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          delivery_person_id?: string;
          amount?: number;
          status?: 'pending' | 'accepted' | 'rejected';
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
}