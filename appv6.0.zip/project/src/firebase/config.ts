import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBClvppqvQKaWsraAqXtaBn_KQM9WMxr88",
  authDomain: "delivery-platform-demo.firebaseapp.com",
  projectId: "delivery-platform-demo",
  storageBucket: "delivery-platform-demo.firebasestorage.app",
  messagingSenderId: "560862028112",
  appId: "1:560862028112:web:d0721d829c462ed4e1cc55",
  measurementId: "G-RX7RFGQ5NT"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);