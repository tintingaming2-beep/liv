import React, { useEffect, useState } from 'react';
import { MapPin, Navigation, ChevronDown, ChevronUp, Clock, Route, Power, PowerOff } from 'lucide-react';
import { InteractiveMap } from './InteractiveMap';

// Position fixe de la pizzeria
const PIZZERIA_POSITION = {
  lat: 50.2572671,
  lng: 3.6309771
};

interface LocationInfo {
  city?: string;
  address?: string;
}

interface GPSProps {
  onLocationUpdate?: (lat: number, lng: number) => void;
  updateOnDemand?: boolean;
  driverPosition?: { lat: number; lng: number } | null;
  showGPSToggle?: boolean;
  readOnly?: boolean;
}

const reverseGeocode = async (lat: number, lng: number): Promise<LocationInfo> => {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&addressdetails=1&accept-language=fr`
    );
    
    if (!response.ok) {
      throw new Error('Erreur API géocodage');
    }
    
    const data = await response.json();
    
    if (data && data.address) {
      const address = data.address;
      const city = address.city || address.town || address.village || address.municipality || 'Ville inconnue';
      
      // Construire l'adresse complète
      const addressParts = [];
      if (address.house_number) addressParts.push(address.house_number);
      if (address.road) addressParts.push(address.road);
      if (city) addressParts.push(city);
      if (address.country) addressParts.push(address.country);
      
      return {
        city,
        address: addressParts.length > 0 ? addressParts.join(', ') : data.display_name
      };
    }
    
    return {};
  } catch (error) {
    console.error('Erreur géocodage inversé:', error);
    return {};
  }
};

// Fonction pour calculer la distance entre deux points (formule de Haversine)
const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
  const R = 6371; // Rayon de la Terre en km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c; // Distance en km
};

// Fonction pour estimer le temps d'arrivée
const estimateArrivalTime = (driverPosition: { lat: number; lng: number }): { distance: number; timeMinutes: number } => {
  const distance = calculateDistance(
    driverPosition.lat, 
    driverPosition.lng, 
    PIZZERIA_POSITION.lat, 
    PIZZERIA_POSITION.lng
  );
  
  // Vitesse moyenne estimée : 30 km/h en ville
  const averageSpeed = 30; // km/h
  const timeHours = distance / averageSpeed;
  const timeMinutes = Math.round(timeHours * 60) + 2; // +2 minutes par défaut
  
  return { distance, timeMinutes };
};

// Système de limitation des requêtes GPS
const GPS_LIMITS = {
  MAX_REQUESTS_PER_DAY: 200, // 200 requêtes GPS max par jour (sur 10k total)
  MIN_INTERVAL_MINUTES: 2,   // Minimum 2 minutes entre chaque requête
  MIN_DISTANCE_METERS: 1000  // Minimum 1km de déplacement
};

// Calculer la distance entre deux points en mètres
const calculateDistanceMeters = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
  const R = 6371000; // Rayon de la Terre en mètres
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

// Vérifier si on est dans les heures de service (18h-21h30)
const isServiceHours = (): boolean => {
  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();
  const currentTime = hours + minutes / 60;
  
  return currentTime >= 18 && currentTime <= 21.5;
};

// Gestionnaire de quota GPS
class GPSQuotaManager {
  private static instance: GPSQuotaManager;
  private requestCount: number = 0;
  private lastResetDate: string = '';
  private lastPosition: { lat: number; lng: number } | null = null;
  private lastUpdateTime: number = 0;

  static getInstance(): GPSQuotaManager {
    if (!GPSQuotaManager.instance) {
      GPSQuotaManager.instance = new GPSQuotaManager();
    }
    return GPSQuotaManager.instance;
  }

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    const today = new Date().toDateString();
    const stored = localStorage.getItem('gps-quota');
    
    if (stored) {
      const data = JSON.parse(stored);
      if (data.date === today) {
        this.requestCount = data.count || 0;
        this.lastPosition = data.lastPosition || null;
        this.lastUpdateTime = data.lastUpdateTime || 0;
      } else {
        // Nouveau jour, reset
        this.requestCount = 0;
        this.lastPosition = null;
        this.lastUpdateTime = 0;
      }
    }
    this.lastResetDate = today;
  }

  private saveToStorage() {
    const data = {
      date: this.lastResetDate,
      count: this.requestCount,
      lastPosition: this.lastPosition,
      lastUpdateTime: this.lastUpdateTime
    };
    localStorage.setItem('gps-quota', JSON.stringify(data));
  }

  canMakeRequest(lat: number, lng: number): { allowed: boolean; reason?: string; remaining: number } {
    const now = Date.now();
    const today = new Date().toDateString();
    
    // Reset si nouveau jour
    if (this.lastResetDate !== today) {
      this.requestCount = 0;
      this.lastPosition = null;
      this.lastUpdateTime = 0;
      this.lastResetDate = today;
    }

    const remaining = GPS_LIMITS.MAX_REQUESTS_PER_DAY - this.requestCount;

    // Vérifier quota journalier
    if (this.requestCount >= GPS_LIMITS.MAX_REQUESTS_PER_DAY) {
      return { 
        allowed: false, 
        reason: `Quota journalier atteint (${GPS_LIMITS.MAX_REQUESTS_PER_DAY} requêtes)`,
        remaining: 0
      };
    }

    // Vérifier intervalle minimum
    const timeSinceLastUpdate = now - this.lastUpdateTime;
    const minInterval = GPS_LIMITS.MIN_INTERVAL_MINUTES * 60 * 1000;
    
    if (timeSinceLastUpdate < minInterval) {
      const remainingTime = Math.ceil((minInterval - timeSinceLastUpdate) / 1000 / 60);
      return { 
        allowed: false, 
        reason: `Attendre ${remainingTime} min (intervalle minimum: ${GPS_LIMITS.MIN_INTERVAL_MINUTES} min)`,
        remaining
      };
    }

    // Vérifier distance minimum
    if (this.lastPosition) {
      const distance = calculateDistanceMeters(
        this.lastPosition.lat, 
        this.lastPosition.lng, 
        lat, 
        lng
      );
      
      if (distance < GPS_LIMITS.MIN_DISTANCE_METERS) {
        return { 
          allowed: false, 
          reason: `Déplacement insuffisant (${Math.round(distance)}m < ${(GPS_LIMITS.MIN_DISTANCE_METERS/1000).toFixed(1)}km)`,
          remaining
        };
      }
    }

    return { allowed: true, remaining };
  }

  recordRequest(lat: number, lng: number) {
    this.requestCount++;
    this.lastPosition = { lat, lng };
    this.lastUpdateTime = Date.now();
    this.saveToStorage();
    
    console.log(`📊 GPS Request ${this.requestCount}/${GPS_LIMITS.MAX_REQUESTS_PER_DAY} (${GPS_LIMITS.MAX_REQUESTS_PER_DAY - this.requestCount} restantes)`);
  }

  getStats() {
    return {
      used: this.requestCount,
      remaining: GPS_LIMITS.MAX_REQUESTS_PER_DAY - this.requestCount,
      total: GPS_LIMITS.MAX_REQUESTS_PER_DAY,
      lastUpdate: this.lastUpdateTime,
      lastPosition: this.lastPosition
    };
  }
}

export const GPS: React.FC<GPSProps> = ({ 
  onLocationUpdate, 
  updateOnDemand = false,
  driverPosition,
  showGPSToggle = false,
  readOnly = false,
}) => {
  const [position, setPosition] = useState<{ lat: number; lng: number } | null>(null);
  const [error, setError] = useState<string>('');
  const [watching, setWatching] = useState(false);
  const [gpsEnabled, setGpsEnabled] = useState(false);
  const [locationInfo, setLocationInfo] = useState<LocationInfo>({});
  const [loadingAddress, setLoadingAddress] = useState(false);
  const [mapVisible, setMapVisible] = useState(false);
  const [arrivalEstimate, setArrivalEstimate] = useState<{ distance: number; timeMinutes: number } | null>(null);
  const [quotaInfo, setQuotaInfo] = useState<string>('');
  const [quotaManager] = useState(() => GPSQuotaManager.getInstance());
  const [serviceHours, setServiceHours] = useState(isServiceHours());
  const [manualOverride, setManualOverride] = useState(false);

  // Vérifier les heures de service toutes les minutes
  useEffect(() => {
    const interval = setInterval(() => {
      setServiceHours(isServiceHours());
    }, 60000); // Vérifier toutes les minutes

    return () => clearInterval(interval);
  }, []);

  // Auto-désactiver le GPS en dehors des heures de service
  useEffect(() => {
    if (!serviceHours && gpsEnabled && !manualOverride) {
      setGpsEnabled(false);
      setError('GPS désactivé - En dehors des heures de service (18h-21h30)');
    }
  }, [serviceHours, gpsEnabled, manualOverride]);

  // GPS avec limitation stricte
  const throttledLocationUpdate = (lat: number, lng: number, forceUpdate = false) => {
    if (!onLocationUpdate) return;

    const quotaCheck = forceUpdate ? { allowed: true, remaining: 999 } : quotaManager.canMakeRequest(lat, lng);
    const stats = quotaManager.getStats();
    
    setQuotaInfo(`${stats.used}/${stats.total} requêtes utilisées`);
    
    if (quotaCheck.allowed) {
      onLocationUpdate(lat, lng);
      if (!forceUpdate) {
        quotaManager.recordRequest(lat, lng);
      }
      console.log('✅ GPS position updated to Firestore');
      setError('');
    } else {
      console.log(`🚫 GPS update blocked: ${quotaCheck.reason}`);
      setError(`GPS limité: ${quotaCheck.reason}`);
    }
  };

  useEffect(() => {
    if (!onLocationUpdate || updateOnDemand || !gpsEnabled) {
      setWatching(false);
      return;
    }

    if (!navigator.geolocation) {
      setError('Géolocalisation non supportée');
      return;
    }

    // GPS avec intervalle fixe de 2 minutes
    const updateGPS = () => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const newPosition = {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude
          };
          console.log('🔄 GPS Update (2min interval):', newPosition);
          setPosition(newPosition);
          if (!updateOnDemand) {
            throttledLocationUpdate(newPosition.lat, newPosition.lng);
          }
          setWatching(true);
          setError('');
        },
        (err) => {
          setError('Erreur de géolocalisation');
          console.error('GPS Error:', err);
          setWatching(false);
        },
        {
          enableHighAccuracy: true,
          maximumAge: 60000,  // 1 minute de cache
          timeout: 30000      // 30 secondes timeout
        }
      );
    };

    // Première mise à jour immédiate
    updateGPS();
    
    // Puis toutes les 2 minutes
    const intervalId = setInterval(updateGPS, 120000); // 120000ms = 2 minutes
    
    return () => {
      clearInterval(intervalId);
      setWatching(false);
    };
  }, [onLocationUpdate, quotaManager, updateOnDemand, gpsEnabled]);

  // Fonction pour forcer une mise à jour GPS à la demande
  const forceGPSUpdate = () => {
    if (!position || !onLocationUpdate) return;
    
    throttledLocationUpdate(position.lat, position.lng, true);
  };

  // Géocodage inversé quand la position change
  useEffect(() => {
    const currentPosition = driverPosition || position;
    if (!currentPosition) return;

    const fetchAddress = async () => {
      setLoadingAddress(true);
      const info = await reverseGeocode(currentPosition.lat, currentPosition.lng);
      setLocationInfo(info);
      setLoadingAddress(false);
    };

    // Délai pour éviter trop d'appels API
    const timeoutId = setTimeout(fetchAddress, 1000);
    return () => clearTimeout(timeoutId);
  }, [position, driverPosition]);

  // Calculer l'estimation d'arrivée quand la position du livreur change
  useEffect(() => {
    if (driverPosition) {
      const estimate = estimateArrivalTime(driverPosition);
      setArrivalEstimate(estimate);
    } else {
      setArrivalEstimate(null);
    }
  }, [driverPosition]);

  const displayPosition = driverPosition || position;

  // Show component even without onLocationUpdate (for pizzeria page)
  const showGPSTracking = !!onLocationUpdate;

  const toggleGPS = () => {
    if (!serviceHours && !gpsEnabled) {
      // Permettre l'activation manuelle hors heures
      setManualOverride(true);
      setGpsEnabled(true);
      setError('GPS activé manuellement (hors heures de service)');
      return;
    }
    
    setGpsEnabled(!gpsEnabled);
    if (gpsEnabled) {
      setManualOverride(false);
      setError('');
    } else {
      if (!serviceHours) {
        setManualOverride(true);
        setError('GPS activé manuellement (hors heures de service)');
      } else {
        setError('');
      }
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm p-4 transition-colors">
      <div 
        className="flex items-center justify-between mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 -m-4 p-4 rounded-lg transition-colors"
        onClick={() => {
          setMapVisible(!mapVisible);
          if (updateOnDemand && !mapVisible && position) {
            forceGPSUpdate();
          }
        }}
      >
        <div className="flex items-center space-x-2">
          <Navigation className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-gray-900 dark:text-white">
            {showGPSTracking ? 'Position GPS' : 'Carte des positions'}
          </h3>
        </div>
        <div className="flex items-center space-x-2">
          {showGPSToggle && (
            <button
              onClick={toggleGPS}
              className={`flex items-center space-x-1 px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                gpsEnabled 
                  ? 'bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-400 hover:bg-green-200 dark:hover:bg-green-900/30' 
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
              title="Mode automatique (19h-7h)"
            >
              {gpsEnabled ? (
                <>
                  <Power className="w-4 h-4" />
                  <span>ON</span>
                </>
              ) : (
                <>
                  <PowerOff className="w-4 h-4" />
                  <span>OFF</span>
                </>
              )}
            </button>
          )}
          {showGPSTracking && watching && gpsEnabled && (
            <div className="flex items-center space-x-1 text-green-600">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-xs font-medium">Actif</span>
            </div>
          )}
          {showGPSTracking && !serviceHours && (
            <div className="flex items-center space-x-1 text-amber-600">
              {manualOverride && gpsEnabled ? (
                <>
                  <Clock className="w-4 h-4" />
                  <span className="text-xs font-medium dark:text-amber-400">Manuel</span>
                </>
              ) : (
                <>
                  <Clock className="w-4 h-4" />
                  <span className="text-xs font-medium dark:text-amber-400">Hors service</span>
                </>
              )}
            </div>
          )}
          <div className="text-blue-600">
            {mapVisible ? (
              <ChevronUp className="w-5 h-5" />
            ) : (
              <ChevronDown className="w-5 h-5" />
            )}
          </div>
        </div>
      </div>

      {/* Estimation d'arrivée du livreur */}
      {arrivalEstimate && !showGPSTracking && (
        <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Clock className="w-5 h-5 text-blue-600" />
            <h4 className="font-semibold text-blue-900 dark:text-blue-300">Estimation d'arrivée du livreur</h4>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <Route className="w-4 h-4 text-blue-500" />
              <span className="text-gray-700 dark:text-gray-300">
                Distance: <strong>{arrivalEstimate.distance.toFixed(1)} km</strong>
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-blue-500" />
              <span className="text-gray-700 dark:text-gray-300">
                Temps estimé: <strong>
                  {arrivalEstimate.timeMinutes < 1 
                    ? "< 1 min" 
                    : `${arrivalEstimate.timeMinutes} min`}
                </strong>
              </span>
            </div>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
            * Estimation basée sur une vitesse moyenne de 30 km/h
          </p>
        </div>
      )}

      {error && (
        <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
          <p className="text-red-600 dark:text-red-400 text-sm">{error}</p>
        </div>
      )}

      {/* Service Hours Info */}
      {showGPSToggle && !readOnly && (
        <div className={`mb-4 p-3 rounded-lg border ${
          serviceHours || (gpsEnabled && manualOverride)
            ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
            : 'bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800'
        }`}>
          <div className="flex items-center space-x-2">
            <Clock className={`w-4 h-4 ${
              serviceHours || (gpsEnabled && manualOverride) ? 'text-green-600' : 'text-amber-600'
            }`} />
            <p className={`text-sm font-medium ${
              serviceHours || (gpsEnabled && manualOverride) 
                ? 'text-green-800 dark:text-green-300' 
                : 'text-amber-800 dark:text-amber-300'
            }`}>
              {serviceHours 
                ? '🟢 Heures de service actives (18h-21h30)'
                : manualOverride && gpsEnabled
                  ? '🔧 GPS activé manuellement (hors heures de service)'
                  : '🟡 Hors heures de service - Cliquez ON pour forcer l\'activation'}
            </p>
          </div>
        </div>
      )}

      {/* Service Hours Info for Pizzeria (read-only) */}
      {showGPSToggle && readOnly && (
        <div className={`mb-4 p-3 rounded-lg border ${
          serviceHours 
            ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800' 
            : 'bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700'
        }`}>
          <p className={`text-sm font-medium ${serviceHours ? 'text-blue-800 dark:text-blue-300' : 'text-gray-600 dark:text-gray-300'}`}>
            État GPS du livreur : {gpsEnabled ? '🟢 Activé' : '🔴 Désactivé'}
            {!serviceHours && ' (Hors heures de service)'}
          </p>
        </div>
      )}

      {/* Quota Info */}
      {showGPSTracking && !updateOnDemand && quotaInfo && gpsEnabled && (
        <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
          <p className="text-blue-600 dark:text-blue-400 text-sm">
            📊 Quota GPS: {quotaInfo} aujourd'hui
          </p>
        </div>
      )}

      {(displayPosition || driverPosition) && (
        <div className="space-y-3">
          {displayPosition && (
            <div className="flex items-center space-x-3 text-sm text-gray-600 dark:text-gray-300">
              <MapPin className="w-4 h-4" />
              <div>
                <p>Lat: {displayPosition.lat.toFixed(6)}</p>
                <p>Lng: {displayPosition.lng.toFixed(6)}</p>
                {loadingAddress ? (
                  <p className="text-gray-500 dark:text-gray-400 italic">Recherche d'adresse...</p>
                ) : (
                  <>
                    {locationInfo.city && (
                      <p className="font-medium text-gray-700 dark:text-gray-200">Ville : {locationInfo.city}</p>
                    )}
                    {locationInfo.address && (
                      <p className="text-gray-600 dark:text-gray-300">Adresse : {locationInfo.address}</p>
                    )}
                    {!locationInfo.city && !locationInfo.address && !loadingAddress && (
                      <p className="text-gray-500 dark:text-gray-400 italic">Adresse inconnue</p>
                    )}
                  </>
                )}
              </div>
            </div>
          )}

          {mapVisible && (
            <div className="mt-4">
              <InteractiveMap
                position={displayPosition || driverPosition || PIZZERIA_POSITION}
                pizzeriaPosition={PIZZERIA_POSITION}
                driverPosition={driverPosition}
                showDriver={!!driverPosition}
                locationInfo={locationInfo}
                height="400px"
              />
            </div>
          )}
        </div>
      )}

      {showGPSTracking && !displayPosition && !error && gpsEnabled && (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
          <p className="text-gray-600 dark:text-gray-300 text-sm">Recherche de position...</p>
        </div>
      )}

      {showGPSTracking && !gpsEnabled && !error && (
        <div className="text-center py-8">
          <PowerOff className="w-12 h-12 text-gray-300 mx-auto mb-2" />
          <p className="text-gray-600 dark:text-gray-300 text-sm">
            GPS désactivé - Cliquez sur ON pour activer
            {!serviceHours && ' (activation manuelle hors heures)'}
          </p>
        </div>
      )}

      {!showGPSTracking && !driverPosition && !mapVisible && (
        <div className="text-center py-4">
          <p className="text-gray-600 dark:text-gray-300 text-sm">
            {updateOnDemand ? 'Cliquez pour voir la position du livreur' : 'Cliquez pour afficher la carte'}
          </p>
        </div>
      )}
    </div>
  );
};