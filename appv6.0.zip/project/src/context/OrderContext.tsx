import React, { createContext, useContext, useState, useEffect } from 'react';
import { collection, onSnapshot, addDoc, updateDoc, deleteDoc, doc, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase/config';
import { Order } from '../types';
import { useAuth } from './AuthContext';
import { sendTelegramMessage } from '../utils/telegram';
import { NotificationService } from '../services/NotificationService';

interface OrderContextType {
  orders: Order[];
  addOrder: (order: Omit<Order, 'id' | 'createdAt' | 'status'>) => Promise<void>;
  updateOrder: (id: string, updates: Partial<Order>) => Promise<void>;
  deleteOrder: (id: string) => Promise<void>;
  markAsReady: (id: string) => Promise<void>;
  markAsDelivered: (id: string, driverId: string) => Promise<void>;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export const useOrders = () => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within OrderProvider');
  }
  return context;
};

export const OrderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const { user } = useAuth();
  const notificationService = NotificationService.getInstance();

  // Initialiser les notifications au démarrage
  useEffect(() => {
    const initNotifications = async () => {
      await notificationService.initializeServiceWorker();
      
      // Demander la permission automatiquement
      if (notificationService.isSupported()) {
        await notificationService.requestPermission();
      }
    };
    
    initNotifications();
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const ordersData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        deliveredAt: doc.data().deliveredAt?.toDate()
      })) as Order[];
      setOrders(ordersData);
    });

    return () => unsubscribe();
  }, []);

  const addOrder = async (orderData: Omit<Order, 'id' | 'createdAt' | 'status'>) => {
    const docRef = await addDoc(collection(db, 'orders'), {
      ...orderData,
      status: 'pending',
      createdAt: new Date()
    });
    
    console.log('🔔 === NOUVELLE COMMANDE CRÉÉE ===');
    console.log('📋 Order ID:', docRef.id);
    console.log('👤 User role:', user?.role);
    
    // Pas de notification PWA pour la pizzeria lors de la création
    console.log('📝 Commande créée, pas de notification PWA (pizzeria)');
    
    // Send Telegram notification for new order
    try {
      const orderText = `🚨 <b>Nouvelle commande reçue !</b>

📍 <b>Adresse:</b> ${orderData.clientAddress}
🏙️ <b>Ville:</b> ${orderData.city}
⏰ <b>Récupération:</b> ${orderData.pickupTime}
💰 <b>Montant:</b> ${orderData.amount.toFixed(2)}€
${orderData.clientPhone ? `📞 <b>Téléphone:</b> ${orderData.clientPhone}` : ''}

Voulez-vous accepter ou refuser cette commande ?`;

      await sendTelegramMessage(orderText, [
        { text: '✅ Accepter', callback_data: `accept_${docRef.id}` },
        { text: '❌ Refuser', callback_data: `refuse_${docRef.id}` }
      ]);
    } catch (error) {
      console.error('Error sending Telegram notification:', error);
    }
  };

  const updateOrder = async (id: string, updates: Partial<Order>) => {
    await updateDoc(doc(db, 'orders', id), updates);
    
    // Notifications pour changements de statut
    try {
      const { getDoc } = await import('firebase/firestore');
      const orderDoc = await getDoc(doc(db, 'orders', id));
      if (orderDoc.exists()) {
        const orderData = orderDoc.data();
        const userRole = user?.role || 'pizzeria';
        
        if (updates.status === 'accepted') {
          await notificationService.notifyOrderAccepted({
            id,
            clientAddress: orderData.clientAddress,
            city: orderData.city
          }, userRole);
        }
      }
    } catch (error) {
      console.error('Erreur notification status update:', error);
    }
    
    // Si on annule une commande acceptée, notifier le livreur
    if (updates.status === 'cancelled') {
      try {
        const { getDoc } = await import('firebase/firestore');
        const orderDoc = await getDoc(doc(db, 'orders', id));
        if (orderDoc.exists()) {
          const orderData = orderDoc.data();
          if (orderData.driverId) {
            await sendTelegramMessage(
              `❌ <b>Commande annulée par la pizzeria</b>\n\n` +
              `📍 <b>Adresse:</b> ${orderData.clientAddress}\n` +
              `🏙️ <b>Ville:</b> ${orderData.city}\n` +
              `💰 <b>Montant:</b> ${orderData.amount.toFixed(2)}€\n\n` +
              `La commande a été annulée par le client.`
            );
          }
        }
      } catch (error) {
        console.error('Error sending cancellation notification:', error);
      }
    }
  };

  const deleteOrder = async (id: string) => {
    await deleteDoc(doc(db, 'orders', id));
  };

  const markAsReady = async (id: string) => {
    await updateDoc(doc(db, 'orders', id), { status: 'ready' });
    
    // Notification push pour le livreur quand commande prête (SANS son côté pizzeria)
    try {
      const { getDoc } = await import('firebase/firestore');
      const orderDoc = await getDoc(doc(db, 'orders', id));
      if (orderDoc.exists()) {
        const orderData = orderDoc.data();
        console.log('🔔 === COMMANDE PRÊTE - NOTIFICATION LIVREUR (SANS SON PIZZERIA) ===');
        
        // Notification silencieuse côté pizzeria - le son sera déclenché côté livreur
        await notificationService.notifyOrderReadyForDriver({
          id,
          clientAddress: orderData.clientAddress,
          city: orderData.city,
          amount: orderData.amount,
          pickupTime: orderData.pickupTime
        });
        
        console.log('✅ Notification livreur envoyée (son déclenché côté livreur uniquement)');
      }
    } catch (error) {
      console.error('Erreur notification commande prête:', error);
    }
  };

  const markAsDelivered = async (id: string, driverId: string) => {
    // Vérifier d'abord si la commande n'est pas déjà livrée
    const { getDoc } = await import('firebase/firestore');
    const orderDoc = await getDoc(doc(db, 'orders', id));
    
    if (!orderDoc.exists()) {
      throw new Error('Commande introuvable');
    }
    
    const orderData = orderDoc.data();
    if (orderData.status === 'delivered') {
      throw new Error('Commande déjà livrée');
    }
    
    // Get current driver balance before updating
    const driverDoc = await getDoc(doc(db, 'drivers', driverId));
    const currentBalance = driverDoc.exists() ? (driverDoc.data().balance || 0) : 0;
    const newBalance = currentBalance + 5;
    
    await updateDoc(doc(db, 'orders', id), { 
      status: 'delivered',
      deliveredAt: new Date(),
      driverId
    });
    
    // Update driver balance
    const driverRef = doc(db, 'drivers', driverId);
    const { increment } = await import('firebase/firestore');
    await updateDoc(driverRef, {
      balance: increment(5)
    });
    
    // Notification PWA pour livraison terminée
    try {
      const userRole = user?.role || 'driver';
      await notificationService.notifyOrderDelivered({
        id,
        clientAddress: orderData.clientAddress,
        city: orderData.city,
        amount: orderData.amount
      }, userRole);
    } catch (error) {
      console.error('Erreur notification livraison:', error);
    }
    
    // Send Telegram notification for delivery completion
    try {
      await sendTelegramMessage(
        `✅ <b>Livraison effectuée !</b> 💰 Solde mis à jour : <b>${newBalance.toFixed(2)}€</b>`
      );
    } catch (error) {
      console.error('Error sending Telegram delivery notification:', error);
    }
  };

  return (
    <OrderContext.Provider value={{
      orders,
      addOrder,
      updateOrder,
      deleteOrder,
      markAsReady,
      markAsDelivered
    }}>
      {children}
    </OrderContext.Provider>
  );
};