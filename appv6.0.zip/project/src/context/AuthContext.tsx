import React, { createContext, useContext, useState, useEffect } from 'react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../firebase/config';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

// Local credentials
const LOCAL_CREDENTIALS = {
  kiosk: { password: '1234', role: 'pizzeria' as const, name: 'Pizzeria' },
  livreur: { password: '1234', role: 'driver' as const, name: 'Livreur' }
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is already logged in (from localStorage)
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        console.error('Error parsing saved user:', error);
        localStorage.removeItem('currentUser');
      }
    }
    setLoading(false);
  }, []);

  const login = async (username: string, password: string) => {
    try {
      // Check local credentials
      const credentials = LOCAL_CREDENTIALS[username as keyof typeof LOCAL_CREDENTIALS];
      
      if (!credentials || credentials.password !== password) {
        throw new Error('Identifiants incorrects');
      }

      // Create user ID based on username
      const userId = username === 'kiosk' ? 'pizzeria-001' : 'driver-001';
      
      const userData: User = {
        uid: userId,
        role: credentials.role,
        name: credentials.name
      };

      // Save user data to Firestore for synchronization
      try {
        await setDoc(doc(db, 'users', userId), userData);
        
        // Create driver document if it's a driver
        if (username === 'livreur') {
          const driverDoc = await getDoc(doc(db, 'drivers', userId));
          if (!driverDoc.exists()) {
            await setDoc(doc(db, 'drivers', userId), {
              id: userId,
              name: 'Livreur',
              balance: 0
            });
          }
        }
      } catch (firestoreError) {
        console.error('Error saving to Firestore:', firestoreError);
        // Continue with local login even if Firestore fails
      }

      // Save to localStorage and set user
      localStorage.setItem('currentUser', JSON.stringify(userData));
      setUser(userData);
    } catch (error) {
      console.error('Login error:', error);
      throw new Error('Identifiants incorrects');
    }
  };

  const logout = async () => {
    localStorage.removeItem('currentUser');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};