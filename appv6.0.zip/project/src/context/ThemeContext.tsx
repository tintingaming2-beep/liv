import React, { createContext, useContext, useState, useEffect } from 'react';

interface ThemeContextType {
  isDark: boolean;
  toggleTheme: () => void;
  isAutoMode: boolean;
  setAutoMode: (auto: boolean) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
};

// Vérifier si on est dans les heures sombres (19h-7h)
const isDarkHours = (): boolean => {
  const now = new Date();
  const hours = now.getHours();
  return hours >= 19 || hours < 7;
};

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isDark, setIsDark] = useState(false);
  const [isAutoMode, setIsAutoMode] = useState(true);

  // Charger les préférences depuis localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const savedAutoMode = localStorage.getItem('autoMode');
    
    if (savedAutoMode !== null) {
      const autoMode = JSON.parse(savedAutoMode);
      setIsAutoMode(autoMode);
      
      if (autoMode) {
        setIsDark(isDarkHours());
      } else if (savedTheme) {
        setIsDark(savedTheme === 'dark');
      }
    } else {
      // Premier lancement, activer le mode auto
      setIsAutoMode(true);
      setIsDark(isDarkHours());
    }
  }, []);

  // Vérifier l'heure toutes les minutes en mode auto
  useEffect(() => {
    if (!isAutoMode) return;

    const interval = setInterval(() => {
      setIsDark(isDarkHours());
    }, 60000); // Vérifier toutes les minutes

    return () => clearInterval(interval);
  }, [isAutoMode]);

  // Appliquer le thème au document
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    // Sauvegarder les préférences
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    localStorage.setItem('autoMode', JSON.stringify(isAutoMode));
  }, [isDark, isAutoMode]);

  const toggleTheme = () => {
    if (isAutoMode) {
      // Désactiver le mode auto et basculer
      setIsAutoMode(false);
      setIsDark(!isDark);
    } else {
      // Mode manuel, juste basculer
      setIsDark(!isDark);
    }
  };

  const setAutoMode = (auto: boolean) => {
    setIsAutoMode(auto);
    if (auto) {
      setIsDark(isDarkHours());
    }
  };

  return (
    <ThemeContext.Provider value={{ isDark, toggleTheme, isAutoMode, setAutoMode }}>
      {children}
    </ThemeContext.Provider>
  );
};