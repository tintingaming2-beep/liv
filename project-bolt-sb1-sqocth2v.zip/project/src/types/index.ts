export type UserType = 'pizzeria' | 'livreur';

export interface User {
  username: string;
  type: UserType;
}

export interface Order {
  id: string;
  address: string;
  phoneNumber: string;
  pickupTime: string;
  amount: number;
  status: 'pending' | 'ready' | 'accepted' | 'delivered';
  createdAt: string;
  deliveredAt?: string;
}

export interface DeliveryPerson {
  id: string;
  username: string;
  balance: number;
  location?: {
    lat: number;
    lng: number;
  };
}

export interface Notification {
  id: number;
  message: string;
  type: 'order_created' | 'order_ready' | 'order_delivered' | 'balance_reset';
  timestamp: string;
}