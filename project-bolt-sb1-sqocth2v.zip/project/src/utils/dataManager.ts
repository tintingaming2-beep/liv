import { Order, DeliveryPerson, Notification } from '../types';

// Simuler la lecture/écriture de fichiers JSON
class DataManager {
  private static instance: DataManager;
  private orders: Order[] = [];
  private deliveryPerson: DeliveryPerson = {
    id: '1',
    username: 'livreur',
    balance: 0,
    location: { lat: 50.2486, lng: 3.6358 }
  };
  private notifications: Notification[] = [];

  private constructor() {
    this.loadInitialData();
  }

  static getInstance(): DataManager {
    if (!DataManager.instance) {
      DataManager.instance = new DataManager();
    }
    return DataManager.instance;
  }

  private loadInitialData() {
    // Charger depuis localStorage ou initialiser
    const savedOrders = localStorage.getItem('orders');
    const savedDeliveryPerson = localStorage.getItem('deliveryPerson');
    const savedNotifications = localStorage.getItem('notifications');

    if (savedOrders) {
      this.orders = JSON.parse(savedOrders);
    }
    if (savedDeliveryPerson) {
      this.deliveryPerson = JSON.parse(savedDeliveryPerson);
    }
    if (savedNotifications) {
      this.notifications = JSON.parse(savedNotifications);
    }

    this.saveToFiles();
  }

  private saveToFiles() {
    // Sauvegarder dans localStorage (simule les fichiers JSON)
    localStorage.setItem('orders', JSON.stringify(this.orders, null, 2));
    localStorage.setItem('deliveryPerson', JSON.stringify(this.deliveryPerson, null, 2));
    localStorage.setItem('notifications', JSON.stringify(this.notifications, null, 2));
    
    // Déclencher un événement pour notifier les composants
    window.dispatchEvent(new CustomEvent('dataUpdated'));
  }

  // Orders
  getOrders(): Order[] {
    return this.orders;
  }

  addOrder(order: Order) {
    this.orders.push(order);
    this.saveToFiles();
  }

  updateOrder(orderId: string, updates: Partial<Order>) {
    const index = this.orders.findIndex(o => o.id === orderId);
    if (index !== -1) {
      this.orders[index] = { ...this.orders[index], ...updates };
      this.saveToFiles();
    }
  }

  deleteOrder(orderId: string) {
    this.orders = this.orders.filter(o => o.id !== orderId);
    this.saveToFiles();
  }

  // Delivery Person
  getDeliveryPerson(): DeliveryPerson {
    return this.deliveryPerson;
  }

  updateDeliveryPerson(updates: Partial<DeliveryPerson>) {
    this.deliveryPerson = { ...this.deliveryPerson, ...updates };
    this.saveToFiles();
  }

  // Notifications
  getNotifications(): Notification[] {
    return this.notifications;
  }

  addNotification(notification: Omit<Notification, 'id'>) {
    const newNotification: Notification = {
      ...notification,
      id: Date.now()
    };
    this.notifications.push(newNotification);
    this.saveToFiles();
    return newNotification;
  }

  clearNotifications() {
    this.notifications = [];
    this.saveToFiles();
  }

  // Export/Import JSON
  exportData() {
    return {
      orders: this.orders,
      deliveryPerson: this.deliveryPerson,
      notifications: this.notifications,
      exportedAt: new Date().toISOString()
    };
  }

  importData(data: any) {
    if (data.orders) this.orders = data.orders;
    if (data.deliveryPerson) this.deliveryPerson = data.deliveryPerson;
    if (data.notifications) this.notifications = data.notifications;
    this.saveToFiles();
  }

  // Obtenir les données JSON formatées pour affichage
  getFormattedJSON() {
    return {
      orders: JSON.stringify(this.orders, null, 2),
      deliveryPerson: JSON.stringify(this.deliveryPerson, null, 2),
      notifications: JSON.stringify(this.notifications, null, 2)
    };
  }
}

export default DataManager;