import React, { useState } from 'react';
import { User, UserType } from '../types';
import { Pizza, Bike, Lock, User as UserIcon } from 'lucide-react';

interface LoginFormProps {
  onLogin: (user: User) => void;
}

const LoginForm: React.FC<LoginFormProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Vérification des identifiants
    let userType: UserType | null = null;
    
    if (username === 'livreur' && password === '1234') {
      userType = 'livreur';
    } else if (username === 'kiosk' && password === '1234') {
      userType = 'pizzeria';
    } else {
      setError('Identifiants incorrects');
      return;
    }

    onLogin({ username, type: userType });
  };

  const quickLogin = (type: UserType) => {
    const username = type === 'pizzeria' ? 'kiosk' : 'livreur';
    onLogin({ username, type });
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
        <div className="text-center mb-8">
          <div className="mx-auto w-16 h-16 bg-gradient-to-r from-blue-500 to-orange-500 rounded-full flex items-center justify-center mb-4">
            <Pizza className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Connexion</h1>
          <p className="text-gray-500 mt-2">Plateforme de livraison</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <div className="relative">
              <UserIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Nom d'utilisateur"
                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                required
              />
            </div>
          </div>

          <div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Mot de passe"
                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                required
              />
            </div>
          </div>

          {error && (
            <div className="bg-red-100 border border-red-300 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white py-3 rounded-lg font-medium hover:from-blue-600 hover:to-blue-700 transform hover:scale-[1.02] transition-all duration-200 shadow-lg"
          >
            Se connecter
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-gray-100">
          <p className="text-center text-sm text-gray-500 mb-4">Connexion rapide</p>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => quickLogin('pizzeria')}
              className="flex flex-col items-center p-4 bg-orange-50 hover:bg-orange-100 rounded-lg transition-colors"
            >
              <Pizza className="h-6 w-6 text-orange-500 mb-2" />
              <span className="text-sm font-medium text-gray-700">Pizzeria</span>
              <span className="text-xs text-gray-500">kiosk:1234</span>
            </button>
            
            <button
              onClick={() => quickLogin('livreur')}
              className="flex flex-col items-center p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
            >
              <Bike className="h-6 w-6 text-blue-500 mb-2" />
              <span className="text-sm font-medium text-gray-700">Livreur</span>
              <span className="text-xs text-gray-500">livreur:1234</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;