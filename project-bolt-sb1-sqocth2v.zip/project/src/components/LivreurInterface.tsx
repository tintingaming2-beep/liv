import React, { useState, useEffect } from 'react';
import { Order, DeliveryPerson } from '../types';
import OrderList from './OrderList';
import { Package, DollarSign, MapPin } from 'lucide-react';
import DataManager from '../utils/dataManager';

interface LivreurInterfaceProps {
  onNotify: (notification: any) => void;
}

const LivreurInterface: React.FC<LivreurInterfaceProps> = ({ onNotify }) => {
  const [activeTab, setActiveTab] = useState<'available' | 'accepted' | 'profile'>('available');
  const [orders, setOrders] = useState<Order[]>([]);
  const [deliveryPerson, setDeliveryPerson] = useState<DeliveryPerson>({
    id: '1',
    username: 'livreur',
    balance: 0
  });
  const dataManager = DataManager.getInstance();

  useEffect(() => {
    // Charger les données depuis DataManager
    setOrders(dataManager.getOrders());
    setDeliveryPerson(dataManager.getDeliveryPerson());

    // Écouter les mises à jour de données
    const handleDataUpdate = () => {
      const newOrders = dataManager.getOrders();
      const newDeliveryPerson = dataManager.getDeliveryPerson();
      
      // Vérifier les nouvelles commandes
      const newOrder = newOrders.find((order: Order) => 
        order.status === 'pending' && 
        !orders.find((o: Order) => o.id === order.id)
      );
      
      if (newOrder) {
        onNotify({
          message: `Nouvelle livraison: ${newOrder.address}`,
          type: 'order_created',
          timestamp: new Date().toISOString()
        });
      }
      
      setOrders(newOrders);
      setDeliveryPerson(newDeliveryPerson);
    };

    window.addEventListener('dataUpdated', handleDataUpdate);
    return () => {
      window.removeEventListener('dataUpdated', handleDataUpdate);
    };
  }, [orders, onNotify]);

  const acceptOrder = (orderId: string) => {
    dataManager.updateOrder(orderId, { status: 'accepted' });
  };

  const completeOrder = (orderId: string) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    // Marquer la commande comme livrée
    dataManager.updateOrder(orderId, { 
      status: 'delivered', 
      deliveredAt: new Date().toISOString() 
    });

    // Ajouter 5€ au solde
    const updatedBalance = deliveryPerson.balance + 5;
    dataManager.updateDeliveryPerson({ balance: updatedBalance });

    onNotify({
      message: `Commande livrée ! +5€ ajoutés (Solde: ${updatedBalance}€)`,
      type: 'order_delivered',
      timestamp: new Date().toISOString()
    });
  };

  const openGPS = (address: string) => {
    // Ouvrir Google Maps avec l'adresse
    const encodedAddress = encodeURIComponent(address);
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodedAddress}`, '_blank');
  };

  const availableOrders = orders.filter(o => o.status === 'pending' || o.status === 'ready');
  const acceptedOrders = orders.filter(o => o.status === 'accepted');
  const todayDeliveries = orders.filter(o => 
    o.status === 'delivered' && 
    o.deliveredAt &&
    new Date(o.deliveredAt).toDateString() === new Date().toDateString()
  ).length;

  return (
    <div className="pb-20">
      {/* Stats du livreur */}
      <div className="bg-white p-4 m-4 rounded-xl shadow-sm">
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <Package className="h-6 w-6 text-blue-500 mx-auto mb-2" />
            <p className="text-lg font-bold text-gray-900">{acceptedOrders.length}</p>
            <p className="text-xs text-gray-500">En cours</p>
          </div>
          <div className="text-center">
            <DollarSign className="h-6 w-6 text-green-500 mx-auto mb-2" />
            <p className="text-lg font-bold text-gray-900">{deliveryPerson.balance}€</p>
            <p className="text-xs text-gray-500">Solde</p>
          </div>
          <div className="text-center">
            <MapPin className="h-6 w-6 text-orange-500 mx-auto mb-2" />
            <p className="text-lg font-bold text-gray-900">{todayDeliveries}</p>
            <p className="text-xs text-gray-500">Livrées</p>
          </div>
        </div>
      </div>

      {/* Contenu des onglets */}
      <div className="px-4">
        {activeTab === 'available' && (
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Commandes disponibles ({availableOrders.length})
            </h2>
            {availableOrders.length === 0 ? (
              <div className="bg-gray-50 p-8 rounded-xl text-center">
                <Package className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">Aucune commande disponible</p>
              </div>
            ) : (
              <div className="space-y-4">
                {availableOrders.map((order) => (
                  <div key={order.id} className="bg-white p-4 rounded-xl shadow-sm border">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{order.address}</p>
                        <p className="text-sm text-gray-500">📞 {order.phoneNumber}</p>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        order.status === 'ready' 
                          ? 'bg-green-100 text-green-600' 
                          : 'bg-orange-100 text-orange-600'
                      }`}>
                        {order.status === 'ready' ? 'Prête' : 'En préparation'}
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-sm text-gray-600">
                        🕒 Récupération: {order.pickupTime}
                      </span>
                      <span className="text-lg font-bold text-green-600">
                        {order.amount}€
                      </span>
                    </div>
                    
                    <div className="flex gap-2">
                      <button
                        onClick={() => openGPS(order.address)}
                        className="flex-1 bg-blue-100 text-blue-600 py-2 px-4 rounded-lg text-sm font-medium hover:bg-blue-200 transition-colors"
                      >
                        📍 GPS
                      </button>
                      <button
                        onClick={() => acceptOrder(order.id)}
                        className="flex-1 bg-green-500 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-green-600 transition-colors"
                      >
                        Accepter
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'accepted' && (
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Mes livraisons ({acceptedOrders.length})
            </h2>
            {acceptedOrders.length === 0 ? (
              <div className="bg-gray-50 p-8 rounded-xl text-center">
                <Package className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">Aucune livraison en cours</p>
              </div>
            ) : (
              <div className="space-y-4">
                {acceptedOrders.map((order) => (
                  <div key={order.id} className="bg-white p-4 rounded-xl shadow-sm border border-blue-200">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{order.address}</p>
                        <p className="text-sm text-gray-500">📞 {order.phoneNumber}</p>
                      </div>
                      <span className="px-2 py-1 bg-blue-100 text-blue-600 rounded-full text-xs font-medium">
                        En livraison
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-sm text-gray-600">
                        🕒 Récupération: {order.pickupTime}
                      </span>
                      <span className="text-lg font-bold text-green-600">
                        {order.amount}€
                      </span>
                    </div>
                    
                    <div className="flex gap-2">
                      <button
                        onClick={() => openGPS(order.address)}
                        className="flex-1 bg-blue-100 text-blue-600 py-2 px-4 rounded-lg text-sm font-medium hover:bg-blue-200 transition-colors"
                      >
                        📍 GPS
                      </button>
                      <button
                        onClick={() => completeOrder(order.id)}
                        className="flex-1 bg-green-500 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-green-600 transition-colors"
                      >
                        ✅ Livrée
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'profile' && (
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Mon profil</h2>
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🛵</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900">{deliveryPerson.username}</h3>
                <p className="text-gray-500">Livreur</p>
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="text-gray-600">Solde actuel</span>
                  <span className="text-xl font-bold text-green-600">{deliveryPerson.balance}€</span>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="text-gray-600">Livraisons aujourd'hui</span>
                  <span className="text-xl font-bold text-blue-600">{todayDeliveries}</span>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="text-gray-600">Gains aujourd'hui</span>
                  <span className="text-xl font-bold text-green-600">{todayDeliveries * 5}€</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Navigation bottom */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg">
        <div className="flex">
          <button
            onClick={() => setActiveTab('available')}
            className={`flex-1 py-3 px-2 text-center transition-colors ${
              activeTab === 'available'
                ? 'text-blue-600 bg-blue-50'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Package className="h-5 w-5 mx-auto mb-1" />
            <span className="text-xs">Disponibles</span>
            {availableOrders.length > 0 && (
              <span className="absolute -top-1 left-1/2 transform -translate-x-1/2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {availableOrders.length}
              </span>
            )}
          </button>
          
          <button
            onClick={() => setActiveTab('accepted')}
            className={`flex-1 py-3 px-2 text-center transition-colors relative ${
              activeTab === 'accepted'
                ? 'text-blue-600 bg-blue-50'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <MapPin className="h-5 w-5 mx-auto mb-1" />
            <span className="text-xs">Mes livraisons</span>
            {acceptedOrders.length > 0 && (
              <span className="absolute -top-1 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {acceptedOrders.length}
              </span>
            )}
          </button>
          
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex-1 py-3 px-2 text-center transition-colors ${
              activeTab === 'profile'
                ? 'text-blue-600 bg-blue-50'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <DollarSign className="h-5 w-5 mx-auto mb-1" />
            <span className="text-xs">Profil</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default LivreurInterface;