import React, { useState, useEffect } from 'react';
import DataManager from '../utils/dataManager';
import { Download, Upload, RefreshCw, Database, Eye, EyeOff } from 'lucide-react';

const DataViewer: React.FC = () => {
  const [jsonData, setJsonData] = useState<any>({});
  const [activeTab, setActiveTab] = useState<'orders' | 'deliveryPerson' | 'notifications'>('orders');
  const [isVisible, setIsVisible] = useState(false);
  const dataManager = DataManager.getInstance();

  useEffect(() => {
    loadData();
    
    const handleDataUpdate = () => {
      loadData();
    };

    window.addEventListener('dataUpdated', handleDataUpdate);
    return () => window.removeEventListener('dataUpdated', handleDataUpdate);
  }, []);

  const loadData = () => {
    setJsonData(dataManager.getFormattedJSON());
  };

  const downloadJSON = () => {
    const data = dataManager.exportData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pizzeria-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target?.result as string);
          dataManager.importData(data);
          loadData();
          alert('Données importées avec succès !');
        } catch (error) {
          alert('Erreur lors de l\'importation du fichier JSON');
        }
      };
      reader.readAsText(file);
    }
  };

  if (!isVisible) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <button
          onClick={() => setIsVisible(true)}
          className="bg-gray-800 text-white p-3 rounded-full shadow-lg hover:bg-gray-700 transition-colors"
        >
          <Database className="h-5 w-5" />
        </button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gray-800 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Database className="h-6 w-6" />
            <h2 className="text-lg font-bold">Données JSON - Base de données</h2>
          </div>
          <button
            onClick={() => setIsVisible(false)}
            className="text-gray-300 hover:text-white"
          >
            <EyeOff className="h-5 w-5" />
          </button>
        </div>

        {/* Actions */}
        <div className="p-4 border-b bg-gray-50 flex gap-3 flex-wrap">
          <button
            onClick={downloadJSON}
            className="flex items-center gap-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
          >
            <Download className="h-4 w-4" />
            Télécharger JSON
          </button>
          
          <label className="flex items-center gap-2 bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors cursor-pointer">
            <Upload className="h-4 w-4" />
            Importer JSON
            <input
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
          
          <button
            onClick={loadData}
            className="flex items-center gap-2 bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition-colors"
          >
            <RefreshCw className="h-4 w-4" />
            Actualiser
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b">
          {[
            { key: 'orders', label: 'Commandes', count: JSON.parse(jsonData.orders || '[]').length },
            { key: 'deliveryPerson', label: 'Livreur', count: 1 },
            { key: 'notifications', label: 'Notifications', count: JSON.parse(jsonData.notifications || '[]').length }
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as any)}
              className={`flex-1 py-3 px-4 text-sm font-medium transition-colors ${
                activeTab === tab.key
                  ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab.label} ({tab.count})
            </button>
          ))}
        </div>

        {/* JSON Content */}
        <div className="p-4 overflow-auto max-h-96">
          <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-auto">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400">📄 {activeTab}.json</span>
              <span className="text-xs text-gray-500">
                Dernière mise à jour: {new Date().toLocaleTimeString()}
              </span>
            </div>
            <pre className="whitespace-pre-wrap break-words">
              {jsonData[activeTab] || '{}'}
            </pre>
          </div>
        </div>

        {/* Info */}
        <div className="p-4 bg-blue-50 border-t">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-blue-600 text-xs">ℹ️</span>
            </div>
            <div className="text-sm text-blue-800">
              <p className="font-medium mb-1">Fichiers JSON intégrés</p>
              <p>Les données sont automatiquement synchronisées entre la pizzeria et le livreur. 
              Vous pouvez télécharger une sauvegarde ou importer des données existantes.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataViewer;