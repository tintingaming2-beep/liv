import React, { useEffect, useState } from 'react';
import { DeliveryPerson } from '../types';
import { MapPin, Navigation } from 'lucide-react';

interface DeliveryMapProps {
  deliveryPerson: DeliveryPerson;
}

const DeliveryMap: React.FC<DeliveryMapProps> = ({ deliveryPerson }) => {
  const [currentLocation, setCurrentLocation] = useState<{lat: number; lng: number} | null>(null);

  useEffect(() => {
    // Simuler la position du livreur (en réalité, cela viendrait du GPS)
    const interval = setInterval(() => {
      // Position aléatoire autour du Quesnoy (50.2486° N, 3.6358° E)
      const baseLocation = { lat: 50.2486, lng: 3.6358 };
      const randomOffset = () => (Math.random() - 0.5) * 0.02; // ~1km radius
      
      setCurrentLocation({
        lat: baseLocation.lat + randomOffset(),
        lng: baseLocation.lng + randomOffset()
      });
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const openGoogleMaps = () => {
    if (currentLocation) {
      const url = `https://www.google.com/maps/@${currentLocation.lat},${currentLocation.lng},15z`;
      window.open(url, '_blank');
    }
  };

  const openUberTrip = () => {
    // Ouvrir le lien Uber demandé par l'utilisateur
    window.open('https://trip.uber.com/34qcoyKg', '_blank');
  };

  return (
    <div>
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Position du livreur</h2>
      
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="text-center mb-6">
          <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 relative">
            <MapPin className="h-8 w-8 text-blue-500" />
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
          </div>
          <h3 className="text-xl font-bold text-gray-900">{deliveryPerson.username}</h3>
          <p className="text-gray-500">En ligne</p>
        </div>

        {currentLocation && (
          <div className="space-y-4 mb-6">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Latitude</span>
              <span className="font-mono text-sm">{currentLocation.lat.toFixed(6)}</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Longitude</span>
              <span className="font-mono text-sm">{currentLocation.lng.toFixed(6)}</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
              <span className="text-gray-600">Dernière mise à jour</span>
              <span className="text-sm text-green-600">Il y a {Math.floor(Math.random() * 30)} secondes</span>
            </div>
          </div>
        )}

        <div className="space-y-3">
          <button
            onClick={openGoogleMaps}
            className="w-full bg-blue-500 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-600 transition-colors flex items-center justify-center gap-2"
          >
            <Navigation className="h-5 w-5" />
            Voir sur Google Maps
          </button>
          
          <button
            onClick={openUberTrip}
            className="w-full bg-gray-800 text-white py-3 px-4 rounded-lg font-medium hover:bg-gray-900 transition-colors flex items-center justify-center gap-2"
          >
            <MapPin className="h-5 w-5" />
            Suivi Uber (Lien externe)
          </button>
        </div>

        {/* Simulation de carte */}
        <div className="mt-6 bg-gray-100 h-48 rounded-lg flex items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <div className="w-full h-full bg-gradient-to-br from-green-200 via-blue-200 to-green-100"></div>
          </div>
          <div className="relative z-10 text-center">
            <MapPin className="h-8 w-8 text-red-500 mx-auto mb-2 animate-bounce" />
            <p className="text-sm font-medium text-gray-700">Position en temps réel</p>
            <p className="text-xs text-gray-500">Mise à jour automatique</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryMap;