import React from 'react';
import { Order } from '../types';
import { Clock, Check, MapPin, Trash2, Phone } from 'lucide-react';

interface OrderListProps {
  orders: Order[];
  onUpdateStatus?: (orderId: string, status: Order['status']) => void;
  onDeleteOrder?: (orderId: string) => void;
  userType: 'pizzeria' | 'livreur';
}

const OrderList: React.FC<OrderListProps> = ({ 
  orders, 
  onUpdateStatus, 
  onDeleteOrder, 
  userType 
}) => {
  const activeOrders = orders.filter(order => order.status !== 'delivered');
  const deliveredOrders = orders.filter(order => order.status === 'delivered');

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'pending': return 'bg-orange-100 text-orange-600';
      case 'ready': return 'bg-green-100 text-green-600';
      case 'accepted': return 'bg-blue-100 text-blue-600';
      case 'delivered': return 'bg-gray-100 text-gray-600';
      default: return 'bg-gray-100 text-gray-600';
    }
  };

  const getStatusText = (status: Order['status']) => {
    switch (status) {
      case 'pending': return 'En préparation';
      case 'ready': return 'Prête';
      case 'accepted': return 'En livraison';
      case 'delivered': return 'Livrée';
      default: return status;
    }
  };

  const callClient = (phoneNumber: string) => {
    window.open(`tel:${phoneNumber}`);
  };

  if (orders.length === 0) {
    return (
      <div className="bg-gray-50 p-8 rounded-xl text-center">
        <Clock className="h-12 w-12 text-gray-300 mx-auto mb-4" />
        <p className="text-gray-500">Aucune commande</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Commandes actives */}
      {activeOrders.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Commandes en cours ({activeOrders.length})
          </h3>
          <div className="space-y-4">
            {activeOrders.map((order) => (
              <div key={order.id} className="bg-white p-4 rounded-xl shadow-sm border">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900 mb-1">{order.address}</p>
                    <div className="flex items-center gap-2 mb-2">
                      <Phone className="h-4 w-4 text-gray-400" />
                      <button
                        onClick={() => callClient(order.phoneNumber)}
                        className="text-sm text-blue-600 hover:text-blue-700"
                      >
                        {order.phoneNumber}
                      </button>
                    </div>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                    {getStatusText(order.status)}
                  </span>
                </div>
                
                <div className="flex justify-between items-center mb-4">
                  <span className="text-sm text-gray-600">
                    🕒 {order.pickupTime}
                  </span>
                  <span className="text-lg font-bold text-green-600">
                    {order.amount}€
                  </span>
                </div>
                
                {userType === 'pizzeria' && onUpdateStatus && (
                  <div className="flex gap-2">
                    {order.status === 'pending' && (
                      <button
                        onClick={() => onUpdateStatus(order.id, 'ready')}
                        className="flex-1 bg-green-500 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
                      >
                        <Check className="h-4 w-4" />
                        Marquer prête
                      </button>
                    )}
                    
                    {onDeleteOrder && (
                      <button
                        onClick={() => {
                          if (confirm('Supprimer cette commande ?')) {
                            onDeleteOrder(order.id);
                          }
                        }}
                        className="bg-red-500 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-red-600 transition-colors flex items-center justify-center"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Commandes livrées */}
      {deliveredOrders.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Commandes livrées ({deliveredOrders.length})
          </h3>
          <div className="space-y-4">
            {deliveredOrders.slice(-5).reverse().map((order) => (
              <div key={order.id} className="bg-gray-50 p-4 rounded-xl border">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex-1">
                    <p className="font-medium text-gray-700">{order.address}</p>
                    <p className="text-sm text-gray-500">{order.phoneNumber}</p>
                  </div>
                  <span className="text-lg font-bold text-gray-600">
                    {order.amount}€
                  </span>
                </div>
                
                <div className="flex justify-between items-center text-sm text-gray-500">
                  <span>🕒 {order.pickupTime}</span>
                  {order.deliveredAt && (
                    <span>
                      ✅ {new Date(order.deliveredAt).toLocaleTimeString('fr-FR', { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default OrderList;