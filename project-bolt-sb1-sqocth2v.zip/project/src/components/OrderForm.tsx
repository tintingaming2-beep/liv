import React, { useState } from 'react';
import { Order } from '../types';

interface OrderFormProps {
  onSubmit: (order: Omit<Order, 'id' | 'status' | 'createdAt'>) => void;
}

const OrderForm: React.FC<OrderFormProps> = ({ onSubmit }) => {
  const [address, setAddress] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [pickupTime, setPickupTime] = useState('');
  const [amount, setAmount] = useState('');

  // Adresses pré-remplies autour du Quesnoy (59530) - 20km radius
  const predefinedAddresses = [
    'Le Quesnoy Centre, 59530 Le Quesnoy',
    'Rue Maréchal Joffre, 59530 Le Quesnoy',
    'Valenciennes, 59300 Valenciennes',
    'Bavay, 59570 Bavay',
    'Maubeuge, 59600 Maubeuge',
    'Aulnoye-Aymeries, 59620 Aulnoye-Aymeries',
    'Berlaimont, 59145 Berlaimont',
    'Landrecies, 59550 Landrecies',
    'Avesnes-sur-Helpe, 59440 Avesnes-sur-Helpe',
    'Jolimetz, 59530 Jolimetz',
    'Ruesnes, 59530 Ruesnes',
    'Villereau, 59530 Villereau',
    'Gommegnies, 59144 Gommegnies',
    'Wargnies-le-Grand, 59144 Wargnies-le-Grand',
    'Eth, 59144 Eth'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!address || !phoneNumber || !pickupTime || !amount) {
      alert('Veuillez remplir tous les champs');
      return;
    }

    onSubmit({
      address,
      phoneNumber,
      pickupTime,
      amount: parseFloat(amount)
    });

    // Reset form
    setAddress('');
    setPhoneNumber('');
    setPickupTime('');
    setAmount('');
  };

  return (
    <div>
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Nouvelle commande</h2>
      
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-sm space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Adresse de livraison
          </label>
          <select
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          >
            <option value="">Sélectionner une adresse</option>
            {predefinedAddresses.map((addr, index) => (
              <option key={index} value={addr}>{addr}</option>
            ))}
          </select>
          
          <input
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Ou saisir une adresse personnalisée"
            className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent mt-2"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Numéro de téléphone
          </label>
          <input
            type="tel"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            placeholder="06 12 34 56 78"
            className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Heure de récupération
          </label>
          <input
            type="time"
            value={pickupTime}
            onChange={(e) => setPickupTime(e.target.value)}
            className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Montant à encaisser (€)
          </label>
          <input
            type="number"
            step="0.01"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="15.50"
            className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white py-3 rounded-lg font-medium hover:from-blue-600 hover:to-blue-700 transform hover:scale-[1.02] transition-all duration-200 shadow-lg"
        >
          Créer la commande
        </button>
      </form>
    </div>
  );
};

export default OrderForm;