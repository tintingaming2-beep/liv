import React, { useState, useEffect } from 'react';
import { Order, DeliveryPerson } from '../types';
import OrderForm from './OrderForm';
import OrderList from './OrderList';
import DeliveryMap from './DeliveryMap';
import { Plus, MapPin, DollarSign, Clock } from 'lucide-react';
import DataManager from '../utils/dataManager';

interface PizzeriaInterfaceProps {
  onNotify: (notification: any) => void;
}

const PizzeriaInterface: React.FC<PizzeriaInterfaceProps> = ({ onNotify }) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'map' | 'add'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [deliveryPerson, setDeliveryPerson] = useState<DeliveryPerson>({
    id: '1',
    username: 'livreur',
    balance: 0
  });
  const dataManager = DataManager.getInstance();

  useEffect(() => {
    // Charger les données depuis DataManager
    setOrders(dataManager.getOrders());
    setDeliveryPerson(dataManager.getDeliveryPerson());

    // Écouter les mises à jour de données
    const handleDataUpdate = () => {
      const newOrders = dataManager.getOrders();
      const newDeliveryPerson = dataManager.getDeliveryPerson();
      
      // Vérifier si une commande a été livrée
      const deliveredOrder = newOrders.find((order: Order) => 
        order.status === 'delivered' && 
        !orders.find((o: Order) => o.id === order.id && o.status === 'delivered')
      );
      
      if (deliveredOrder) {
        onNotify({
          message: `Commande ${deliveredOrder.address} livrée !`,
          type: 'order_delivered',
          timestamp: new Date().toISOString()
        });
      }
      
      setOrders(newOrders);
      setDeliveryPerson(newDeliveryPerson);
    };

    window.addEventListener('dataUpdated', handleDataUpdate);
    return () => {
      window.removeEventListener('dataUpdated', handleDataUpdate);
    };
  }, [orders, onNotify]);

  const addOrder = (orderData: Omit<Order, 'id' | 'status' | 'createdAt'>) => {
    const newOrder: Order = {
      ...orderData,
      id: Date.now().toString(),
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    dataManager.addOrder(newOrder);
    
    // Notifier le livreur
    onNotify({
      message: 'Nouvelle livraison reçue !',
      type: 'order_created',
      timestamp: new Date().toISOString()
    });
    
    setActiveTab('orders');
  };

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    dataManager.updateOrder(orderId, { status });
  };

  const deleteOrder = (orderId: string) => {
    dataManager.deleteOrder(orderId);
  };

  const requestBalanceReset = async () => {
    if (deliveryPerson.balance === 0) {
      alert('Le solde est déjà à zéro');
      return;
    }

    const confirmed = window.confirm(
      `Demander la remise à zéro du solde de ${deliveryPerson.balance}€ ?`
    );
    
    if (confirmed) {
      // Simuler une demande de confirmation au livreur
      const livreurConfirm = window.confirm(
        `[SIMULATION LIVREUR] Accepter la remise à zéro du solde de ${deliveryPerson.balance}€ ?`
      );
      
      if (livreurConfirm) {
        dataManager.updateDeliveryPerson({ balance: 0 });
        alert('Solde remis à zéro avec succès !');
      } else {
        alert('Le livreur a refusé la remise à zéro du solde');
      }
    }
  };

  const pendingOrders = orders.filter(o => o.status !== 'delivered').length;
  const todayRevenue = orders.filter(o => 
    o.status === 'delivered' && 
    new Date(o.createdAt).toDateString() === new Date().toDateString()
  ).reduce((sum, o) => sum + o.amount, 0);

  return (
    <div className="pb-20">
      {/* Stats Dashboard */}
      <div className="bg-white p-4 m-4 rounded-xl shadow-sm">
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <Clock className="h-6 w-6 text-orange-500 mx-auto mb-2" />
            <p className="text-lg font-bold text-gray-900">{pendingOrders}</p>
            <p className="text-xs text-gray-500">En cours</p>
          </div>
          <div className="text-center">
            <DollarSign className="h-6 w-6 text-green-500 mx-auto mb-2" />
            <p className="text-lg font-bold text-gray-900">{todayRevenue}€</p>
            <p className="text-xs text-gray-500">Aujourd'hui</p>
          </div>
          <div className="text-center">
            <MapPin className="h-6 w-6 text-blue-500 mx-auto mb-2" />
            <p className="text-lg font-bold text-gray-900">{deliveryPerson.balance}€</p>
            <p className="text-xs text-gray-500">Solde livreur</p>
            {deliveryPerson.balance > 0 && (
              <button
                onClick={requestBalanceReset}
                className="mt-1 px-2 py-1 bg-red-100 text-red-600 text-xs rounded hover:bg-red-200 transition-colors"
              >
                Reset
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Contenu des onglets */}
      <div className="px-4">
        {activeTab === 'orders' && (
          <OrderList
            orders={orders}
            onUpdateStatus={updateOrderStatus}
            onDeleteOrder={deleteOrder}
            userType="pizzeria"
          />
        )}
        
        {activeTab === 'map' && (
          <DeliveryMap deliveryPerson={deliveryPerson} />
        )}
        
        {activeTab === 'add' && (
          <OrderForm onSubmit={addOrder} />
        )}
      </div>

      {/* Navigation bottom */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg">
        <div className="flex">
          <button
            onClick={() => setActiveTab('orders')}
            className={`flex-1 py-3 px-2 text-center transition-colors ${
              activeTab === 'orders'
                ? 'text-blue-600 bg-blue-50'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Clock className="h-5 w-5 mx-auto mb-1" />
            <span className="text-xs">Commandes</span>
          </button>
          
          <button
            onClick={() => setActiveTab('map')}
            className={`flex-1 py-3 px-2 text-center transition-colors ${
              activeTab === 'map'
                ? 'text-blue-600 bg-blue-50'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <MapPin className="h-5 w-5 mx-auto mb-1" />
            <span className="text-xs">Carte</span>
          </button>
          
          <button
            onClick={() => setActiveTab('add')}
            className={`flex-1 py-3 px-2 text-center transition-colors ${
              activeTab === 'add'
                ? 'text-blue-600 bg-blue-50'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Plus className="h-5 w-5 mx-auto mb-1" />
            <span className="text-xs">Ajouter</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default PizzeriaInterface;