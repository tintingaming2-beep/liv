import React, { useState, useEffect } from 'react';
import LoginForm from './components/LoginForm';
import PizzeriaInterface from './components/PizzeriaInterface';
import LivreurInterface from './components/LivreurInterface';
import DataViewer from './components/DataViewer';
import { User, UserType } from './types';
import { Bell } from 'lucide-react';
import DataManager from './utils/dataManager';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [notifications, setNotifications] = useState<any[]>([]);
  const dataManager = DataManager.getInstance();

  useEffect(() => {
    // Charger l'utilisateur sauvegardé
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }

    // Charger les notifications depuis le DataManager
    setNotifications(dataManager.getNotifications());

    // Écouter les mises à jour de données
    const handleDataUpdate = () => {
      setNotifications(dataManager.getNotifications());
    };

    window.addEventListener('dataUpdated', handleDataUpdate);
    return () => window.removeEventListener('dataUpdated', handleDataUpdate);
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('currentUser', JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
  };

  const addNotification = (notification: any) => {
    dataManager.addNotification(notification);
  };

  const clearNotifications = () => {
    dataManager.clearNotifications();
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-orange-50">
        <LoginForm onLogin={handleLogin} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header avec notifications */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="px-4 py-3 flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold text-gray-900">
              {currentUser.type === 'pizzeria' ? '🍕 Pizzeria' : '🛵 Livreur'}
            </h1>
            <p className="text-sm text-gray-500">Connecté: {currentUser.username}</p>
          </div>
          
          <div className="flex items-center gap-3">
            {/* Notifications */}
            <div className="relative">
              <Bell 
                className={`h-6 w-6 ${notifications.length > 0 ? 'text-orange-500 animate-pulse' : 'text-gray-400'}`}
                onClick={clearNotifications}
              />
              {notifications.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center animate-bounce">
                  {notifications.length}
                </span>
              )}
            </div>
            
            {/* Logout */}
            <button
              onClick={handleLogout}
              className="bg-red-500 text-white px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-red-600 transition-colors"
            >
              Déconnexion
            </button>
          </div>
        </div>
        
        {/* Affichage des notifications */}
        {notifications.length > 0 && (
          <div className="bg-orange-100 border-t px-4 py-2">
            {notifications.slice(-1).map((notif) => (
              <p key={notif.id} className="text-sm text-orange-800 font-medium">
                🔔 {notif.message}
              </p>
            ))}
          </div>
        )}
      </header>

      {/* Interface selon le type d'utilisateur */}
      {currentUser.type === 'pizzeria' ? (
        <PizzeriaInterface onNotify={addNotification} />
      ) : (
        <LivreurInterface onNotify={addNotification} />
      )}
      
      {/* Visualiseur de données JSON */}
      <DataViewer />
    </div>
  );
}

export default App;