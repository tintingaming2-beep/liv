import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Order } from '../types';
import { storage } from '../lib/storage';
import { Plus, Clock, MapPin, Euro, Phone, Edit2, Trash2, CheckCircle, Bell, LogOut, Wallet, Archive } from 'lucide-react';
import toast from 'react-hot-toast';

export default function KioskDashboard() {
  const { user, logout } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [deliveredOrders, setDeliveredOrders] = useState<Order[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [notifications, setNotifications] = useState(0);
  const [activeTab, setActiveTab] = useState<'active' | 'delivered'>('active');
  const [deliveryPersonBalance, setDeliveryPersonBalance] = useState(0);

  const [newOrder, setNewOrder] = useState({
    address: '',
    pickup_time: '',
    amount: '',
    client_phone: ''
  });

  useEffect(() => {
    fetchOrders();
    fetchDeliveryPersonBalance();
    
    // Listen for real-time updates
    const handleOrdersUpdate = (event: CustomEvent) => {
      const allOrders = event.detail;
      const activeOrders = allOrders.filter((order: Order) => order.status !== 'delivered');
      const completedOrders = allOrders.filter((order: Order) => order.status === 'delivered');
      setOrders(activeOrders);
      setDeliveredOrders(completedOrders);
    };

    const handleBalanceUpdate = (event: CustomEvent) => {
      if (event.detail.userId === 'livreur') {
        setDeliveryPersonBalance(event.detail.amount);
      }
    };

    window.addEventListener('ordersUpdated', handleOrdersUpdate as EventListener);
    window.addEventListener('balanceUpdated', handleBalanceUpdate as EventListener);

    return () => {
      window.removeEventListener('ordersUpdated', handleOrdersUpdate as EventListener);
      window.removeEventListener('balanceUpdated', handleBalanceUpdate as EventListener);
    };
  }, []);

  const fetchOrders = async () => {
    try {
      const allOrders = storage.getOrders();
      const activeOrders = allOrders.filter(order => order.status !== 'delivered');
      const completedOrders = allOrders.filter(order => order.status === 'delivered');
      setOrders(activeOrders);
      setDeliveredOrders(completedOrders);
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast.error('Erreur lors du chargement des commandes');
    }
  };

  const fetchDeliveryPersonBalance = async () => {
    const balance = storage.getBalance('livreur');
    setDeliveryPersonBalance(balance);
  };

  const resetDeliveryPersonBalance = async () => {
    if (!confirm('Êtes-vous sûr de vouloir remettre à zéro le solde du livreur ?')) return;

    try {
      storage.resetBalance('livreur');
      toast.success('Solde du livreur remis à zéro');
    } catch (error) {
      console.error('Error resetting balance:', error);
      toast.error('Erreur lors de la remise à zéro');
    }
  };

  const handleAddOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOrder.address || !newOrder.pickup_time || !newOrder.amount || !newOrder.client_phone) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    try {
      const order = storage.addOrder({
        address: newOrder.address,
        pickup_time: newOrder.pickup_time,
        amount: parseFloat(newOrder.amount),
        client_phone: newOrder.client_phone,
        status: 'pending'
      });

      // Add notification for delivery person
      storage.addNotification({
        type: 'new_order',
        message: `Nouvelle commande: ${newOrder.address}`,
        recipient_type: 'livreur',
        read: false,
        order_id: order.id
      });

      toast.success('Commande ajoutée avec succès');
      setNewOrder({ address: '', pickup_time: '', amount: '', client_phone: '' });
      setShowAddForm(false);
    } catch (error) {
      console.error('Error adding order:', error);
      toast.error('Erreur lors de l\'ajout de la commande');
    }
  };

  const handleEditOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingOrder) return;

    try {
      storage.updateOrder(editingOrder.id, {
        address: editingOrder.address,
        pickup_time: editingOrder.pickup_time,
        amount: editingOrder.amount,
        client_phone: editingOrder.client_phone
      });

      toast.success('Commande modifiée avec succès');
      setEditingOrder(null);
    } catch (error) {
      console.error('Error updating order:', error);
      toast.error('Erreur lors de la modification');
    }
  };

  const handleDeleteOrder = async (orderId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette commande ?')) return;

    try {
      storage.deleteOrder(orderId);
      toast.success('Commande supprimée');
    } catch (error) {
      console.error('Error deleting order:', error);
      toast.error('Erreur lors de la suppression');
    }
  };

  const markAsReady = async (orderId: string) => {
    try {
      const order = storage.updateOrder(orderId, { status: 'ready' });
      
      if (order) {
        // Add notification for delivery person
        storage.addNotification({
          type: 'order_ready',
          message: `Commande prête: ${order.address}`,
          recipient_type: 'livreur',
          read: false,
          order_id: orderId
        });
      }
      
      toast.success('Commande marquée comme prête');
    } catch (error) {
      console.error('Error marking order as ready:', error);
      toast.error('Erreur lors de la mise à jour');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'ready': return 'bg-blue-100 text-blue-800';
      case 'accepted': return 'bg-green-100 text-green-800';
      case 'delivered': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'En attente';
      case 'ready': return 'Prête';
      case 'accepted': return 'Acceptée';
      case 'delivered': return 'Livrée';
      default: return status;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">P</span>
              </div>
              <h1 className="ml-3 text-xl font-semibold text-gray-900">Pizzeria Dashboard</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-green-50 px-3 py-2 rounded-lg">
                <Wallet className="w-5 h-5 text-green-600 mr-2" />
                <span className="font-medium text-green-900">{deliveryPersonBalance.toFixed(2)}€</span>
                <button
                  onClick={resetDeliveryPersonBalance}
                  className="ml-2 text-xs bg-green-600 text-white px-2 py-1 rounded hover:bg-green-700 transition-colors"
                >
                  Reset
                </button>
              </div>
              
              <div className="relative">
                <Bell className="w-6 h-6 text-gray-600" />
                {notifications > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {notifications}
                  </span>
                )}
              </div>
              
              <button
                onClick={logout}
                className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
              >
                <LogOut className="w-5 h-5 mr-2" />
                Déconnexion
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header with tabs */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
            <button
              onClick={() => setActiveTab('active')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'active'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Commandes actives ({orders.length})
            </button>
            <button
              onClick={() => setActiveTab('delivered')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'delivered'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Archive className="w-4 h-4 mr-2 inline" />
              Livrées ({deliveredOrders.length})
            </button>
          </div>
          
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center"
          >
            <Plus className="w-5 h-5 mr-2" />
            Nouvelle commande
          </button>
        </div>

        {/* Active Orders */}
        {activeTab === 'active' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {orders.map((order) => (
              <div key={order.id} className="bg-white rounded-lg shadow-sm border p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                    {getStatusText(order.status)}
                  </span>
                  <div className="flex items-center space-x-2">
                    {order.status === 'pending' && (
                      <button
                        onClick={() => markAsReady(order.id)}
                        className="p-1 text-blue-600 hover:text-blue-800 transition-colors"
                        title="Marquer comme prête"
                      >
                        <CheckCircle className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => setEditingOrder(order)}
                      className="p-1 text-gray-600 hover:text-gray-800 transition-colors"
                      title="Modifier"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteOrder(order.id)}
                      className="p-1 text-red-600 hover:text-red-800 transition-colors"
                      title="Supprimer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-start">
                    <MapPin className="w-4 h-4 text-gray-400 mt-0.5 mr-2 flex-shrink-0" />
                    <span className="text-sm text-gray-700">{order.address}</span>
                  </div>
                  
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-700">{order.pickup_time}</span>
                  </div>
                  
                  <div className="flex items-center">
                    <Euro className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-sm font-medium text-gray-900">{order.amount}€</span>
                  </div>
                  
                  <div className="flex items-center">
                    <Phone className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-700">{order.client_phone}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Delivered Orders */}
        {activeTab === 'delivered' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {deliveredOrders.map((order) => (
              <div key={order.id} className="bg-gray-50 rounded-lg shadow-sm border p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Livrée
                  </span>
                  <span className="text-xs text-gray-500">
                    {new Date(order.updated_at).toLocaleDateString('fr-FR')} à {new Date(order.updated_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <div className="space-y-3">
                  <div className="flex items-start">
                    <MapPin className="w-4 h-4 text-gray-400 mt-0.5 mr-2 flex-shrink-0" />
                    <span className="text-sm text-gray-600">{order.address}</span>
                  </div>
                  
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-600">{order.pickup_time}</span>
                  </div>
                  
                  <div className="flex items-center">
                    <Euro className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-sm font-medium text-gray-700">{order.amount}€</span>
                  </div>
                  
                  <div className="flex items-center">
                    <Phone className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-600">{order.client_phone}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Empty states */}
        {activeTab === 'active' && orders.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Plus className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune commande</h3>
            <p className="text-gray-600">Commencez par ajouter votre première commande</p>
          </div>
        )}

        {activeTab === 'delivered' && deliveredOrders.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Archive className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune commande livrée</h3>
            <p className="text-gray-600">Les commandes livrées apparaîtront ici</p>
          </div>
        )}
      </div>

      {/* Add Order Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Nouvelle commande</h3>
            
            <form onSubmit={handleAddOrder} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Adresse</label>
                <input
                  type="text"
                  value={newOrder.address}
                  onChange={(e) => setNewOrder({...newOrder, address: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="Entrez l'adresse de livraison"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Heure de récupération</label>
                <input
                  type="time"
                  value={newOrder.pickup_time}
                  onChange={(e) => setNewOrder({...newOrder, pickup_time: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Montant (€)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={newOrder.amount}
                  onChange={(e) => setNewOrder({...newOrder, amount: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="0.00"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Téléphone client</label>
                <input
                  type="tel"
                  value={newOrder.client_phone}
                  onChange={(e) => setNewOrder({...newOrder, client_phone: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="06 12 34 56 78"
                  required
                />
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-200 text-gray-800 py-2 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition-colors"
                >
                  Ajouter
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Order Modal */}
      {editingOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Modifier la commande</h3>
            
            <form onSubmit={handleEditOrder} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Adresse</label>
                <input
                  type="text"
                  value={editingOrder.address}
                  onChange={(e) => setEditingOrder({...editingOrder, address: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="Entrez l'adresse de livraison"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Heure de récupération</label>
                <input
                  type="time"
                  value={editingOrder.pickup_time}
                  onChange={(e) => setEditingOrder({...editingOrder, pickup_time: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Montant (€)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={editingOrder.amount}
                  onChange={(e) => setEditingOrder({...editingOrder, amount: parseFloat(e.target.value)})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Téléphone client</label>
                <input
                  type="tel"
                  value={editingOrder.client_phone}
                  onChange={(e) => setEditingOrder({...editingOrder, client_phone: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  required
                />
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setEditingOrder(null)}
                  className="flex-1 bg-gray-200 text-gray-800 py-2 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition-colors"
                >
                  Modifier
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}