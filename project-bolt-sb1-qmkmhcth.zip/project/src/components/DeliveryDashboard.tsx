import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Order } from '../types';
import { storage } from '../lib/storage';
import { Clock, MapPin, Euro, Phone, Check, Bell, LogOut, Truck, Wallet } from 'lucide-react';
import toast from 'react-hot-toast';

export default function DeliveryDashboard() {
  const { user, logout } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [notifications, setNotifications] = useState(0);
  const [balance, setBalance] = useState(0);

  useEffect(() => {
    fetchOrders();
    fetchBalance();
    
    // Listen for real-time updates
    const handleOrdersUpdate = (event: CustomEvent) => {
      const orders = event.detail.filter((order: Order) => 
        ['pending', 'ready', 'accepted'].includes(order.status)
      );
      setOrders(orders);
      
      // Check for new orders
      const currentOrderIds = orders.map((o: Order) => o.id);
      const newOrders = orders.filter((order: Order) => 
        !orders.some((existing: Order) => existing.id === order.id) && 
        order.status === 'pending'
      );
      
      if (newOrders.length > 0) {
        toast.success('Nouvelle livraison reçue !', {
          icon: '🔔',
          duration: 5000,
        });
        setNotifications(prev => prev + newOrders.length);
      }
    };

    const handleBalanceUpdate = (event: CustomEvent) => {
      if (event.detail.userId === user?.id) {
        setBalance(event.detail.amount);
      }
    };

    window.addEventListener('ordersUpdated', handleOrdersUpdate as EventListener);
    window.addEventListener('balanceUpdated', handleBalanceUpdate as EventListener);

    return () => {
      window.removeEventListener('ordersUpdated', handleOrdersUpdate as EventListener);
      window.removeEventListener('balanceUpdated', handleBalanceUpdate as EventListener);
    };
  }, [user?.id]);

  const fetchOrders = async () => {
    try {
      const allOrders = storage.getOrders();
      const availableOrders = allOrders.filter(order => 
        ['pending', 'ready', 'accepted'].includes(order.status)
      );
      setOrders(availableOrders);
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast.error('Erreur lors du chargement des commandes');
    }
  };

  const fetchBalance = async () => {
    if (user?.id) {
      const currentBalance = storage.getBalance(user.id);
      setBalance(currentBalance);
    }
  };

  const acceptOrder = async (orderId: string) => {
    try {
      storage.updateOrder(orderId, { 
        status: 'accepted',
        delivery_person_id: user?.id
      });
      
      toast.success('Commande acceptée');
    } catch (error) {
      console.error('Error accepting order:', error);
      toast.error('Erreur lors de l\'acceptation');
    }
  };

  const markAsDelivered = async (orderId: string) => {
    if (!confirm('Confirmer que cette commande a été livrée ?')) return;

    try {
      const order = storage.updateOrder(orderId, { status: 'delivered' });
      
      if (order && user?.id) {
        // Add 5€ to balance
        const newBalance = storage.addToBalance(user.id, 5);
        setBalance(newBalance);
        
        // Add notification for kiosk
        storage.addNotification({
          type: 'order_delivered',
          message: `Commande livrée: ${order.address}`,
          recipient_type: 'kiosk',
          read: false,
          order_id: orderId
        });
      }


      toast.success('Commande livrée ! +5€ ajoutés à votre solde');
    } catch (error) {
      console.error('Error marking as delivered:', error);
      toast.error('Erreur lors de la validation');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'ready': return 'bg-blue-100 text-blue-800';
      case 'accepted': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'En attente';
      case 'ready': return 'Prête';
      case 'accepted': return 'Acceptée';
      default: return status;
    }
  };

  const clearNotifications = () => {
    setNotifications(0);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                <Truck className="w-5 h-5 text-white" />
              </div>
              <h1 className="ml-3 text-xl font-semibold text-gray-900">Dashboard Livreur</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-green-50 px-3 py-2 rounded-lg">
                <Wallet className="w-5 h-5 text-green-600 mr-2" />
                <span className="font-medium text-green-900">{balance.toFixed(2)}€</span>
              </div>
              
              <div className="relative">
                <button onClick={clearNotifications} className="relative">
                  <Bell className="w-6 h-6 text-gray-600" />
                  {notifications > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                      {notifications}
                    </span>
                  )}
                </button>
              </div>
              
              <button
                onClick={logout}
                className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
              >
                <LogOut className="w-5 h-5 mr-2" />
                Déconnexion
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Commandes disponibles</h2>
          <div className="text-sm text-gray-600">
            {orders.length} commande{orders.length !== 1 ? 's' : ''} disponible{orders.length !== 1 ? 's' : ''}
          </div>
        </div>

        {/* Orders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {orders.map((order) => (
            <div key={order.id} className="bg-white rounded-lg shadow-sm border p-6">
              <div className="flex items-center justify-between mb-4">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                  {getStatusText(order.status)}
                </span>
                {order.status === 'ready' && (
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                )}
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-start">
                  <MapPin className="w-4 h-4 text-gray-400 mt-0.5 mr-2 flex-shrink-0" />
                  <span className="text-sm text-gray-700">{order.address}</span>
                </div>
                
                <div className="flex items-center">
                  <Clock className="w-4 h-4 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-700">À récupérer à {order.pickup_time}</span>
                </div>
                
                <div className="flex items-center">
                  <Euro className="w-4 h-4 text-gray-400 mr-2" />
                  <span className="text-sm font-medium text-gray-900">À encaisser: {order.amount}€</span>
                </div>
                
                <div className="flex items-center">
                  <Phone className="w-4 h-4 text-gray-400 mr-2" />
                  <a 
                    href={`tel:${order.client_phone}`}
                    className="text-sm text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    {order.client_phone}
                  </a>
                </div>
              </div>

              <div className="flex space-x-2">
                {order.status === 'pending' || order.status === 'ready' ? (
                  <button
                    onClick={() => acceptOrder(order.id)}
                    className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Accepter
                  </button>
                ) : (
                  <button
                    onClick={() => markAsDelivered(order.id)}
                    className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Livré
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {orders.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Truck className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune commande disponible</h3>
            <p className="text-gray-600">Les nouvelles commandes apparaîtront ici automatiquement</p>
          </div>
        )}
      </div>

      {/* Balance Reset Notification */}
      {/* This would be implemented with real notifications system */}
    </div>
  );
}