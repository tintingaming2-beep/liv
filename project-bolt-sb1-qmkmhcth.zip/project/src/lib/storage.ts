import { Order, User, Notification, DeliveryLocation } from '../types';

// Simulation d'une base de données avec localStorage
class LocalStorage {
  private getItem<T>(key: string, defaultValue: T): T {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  private setItem<T>(key: string, value: T): void {
    localStorage.setItem(key, JSON.stringify(value));
  }

  // Orders
  getOrders(): Order[] {
    return this.getItem('orders', []);
  }

  addOrder(order: Omit<Order, 'id' | 'created_at' | 'updated_at'>): Order {
    const orders = this.getOrders();
    const newOrder: Order = {
      ...order,
      id: Date.now().toString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    orders.unshift(newOrder);
    this.setItem('orders', orders);
    
    // Trigger storage event for real-time updates
    window.dispatchEvent(new CustomEvent('ordersUpdated', { detail: orders }));
    
    return newOrder;
  }

  updateOrder(id: string, updates: Partial<Order>): Order | null {
    const orders = this.getOrders();
    const index = orders.findIndex(order => order.id === id);
    
    if (index === -1) return null;
    
    orders[index] = {
      ...orders[index],
      ...updates,
      updated_at: new Date().toISOString(),
    };
    
    this.setItem('orders', orders);
    window.dispatchEvent(new CustomEvent('ordersUpdated', { detail: orders }));
    
    return orders[index];
  }

  deleteOrder(id: string): boolean {
    const orders = this.getOrders();
    const filteredOrders = orders.filter(order => order.id !== id);
    
    if (filteredOrders.length === orders.length) return false;
    
    this.setItem('orders', filteredOrders);
    window.dispatchEvent(new CustomEvent('ordersUpdated', { detail: filteredOrders }));
    
    return true;
  }

  // Notifications
  getNotifications(): Notification[] {
    return this.getItem('notifications', []);
  }

  addNotification(notification: Omit<Notification, 'id' | 'created_at'>): Notification {
    const notifications = this.getNotifications();
    const newNotification: Notification = {
      ...notification,
      id: Date.now().toString(),
      created_at: new Date().toISOString(),
    };
    notifications.unshift(newNotification);
    this.setItem('notifications', notifications);
    
    window.dispatchEvent(new CustomEvent('notificationsUpdated', { detail: notifications }));
    
    return newNotification;
  }

  markNotificationAsRead(id: string): void {
    const notifications = this.getNotifications();
    const notification = notifications.find(n => n.id === id);
    if (notification) {
      notification.read = true;
      this.setItem('notifications', notifications);
      window.dispatchEvent(new CustomEvent('notificationsUpdated', { detail: notifications }));
    }
  }

  // Delivery locations
  getDeliveryLocations(): DeliveryLocation[] {
    return this.getItem('delivery_locations', []);
  }

  updateDeliveryLocation(deliveryPersonId: string, latitude: number, longitude: number): void {
    const locations = this.getDeliveryLocations();
    const existingIndex = locations.findIndex(loc => loc.delivery_person_id === deliveryPersonId);
    
    const location: DeliveryLocation = {
      id: existingIndex >= 0 ? locations[existingIndex].id : Date.now().toString(),
      delivery_person_id: deliveryPersonId,
      latitude,
      longitude,
      updated_at: new Date().toISOString(),
    };

    if (existingIndex >= 0) {
      locations[existingIndex] = location;
    } else {
      locations.push(location);
    }

    this.setItem('delivery_locations', locations);
    window.dispatchEvent(new CustomEvent('locationsUpdated', { detail: locations }));
  }

  // Balance
  getBalance(userId: string): number {
    return this.getItem(`balance_${userId}`, 0);
  }

  updateBalance(userId: string, amount: number): void {
    this.setItem(`balance_${userId}`, amount);
    window.dispatchEvent(new CustomEvent('balanceUpdated', { detail: { userId, amount } }));
  }

  addToBalance(userId: string, amount: number): number {
    const currentBalance = this.getBalance(userId);
    const newBalance = currentBalance + amount;
    this.updateBalance(userId, newBalance);
    return newBalance;
  }

  resetBalance(userId: string): void {
    this.updateBalance(userId, 0);
  }
}

export const storage = new LocalStorage();