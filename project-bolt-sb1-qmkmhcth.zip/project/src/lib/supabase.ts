// Removed Supabase - using local storage instead
export const supabase = null;