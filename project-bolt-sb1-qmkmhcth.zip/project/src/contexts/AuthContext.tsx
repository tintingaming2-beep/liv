import React, { createContext, useContext, useState, useEffect } from 'react';
import { storage } from '../lib/storage';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const FIXED_ACCOUNTS = {
  'livreur:1234': { id: 'livreur', username: 'livreur', type: 'livreur' as const },
  'kiosk:1234': { id: 'kiosk', username: 'kiosk', type: 'kiosk' as const }
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('current_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    const credentials = `${username}:${password}`;
    const account = FIXED_ACCOUNTS[credentials as keyof typeof FIXED_ACCOUNTS];
    
    if (account) {
      const userWithBalance = {
        ...account,
        balance: account.type === 'livreur' ? storage.getBalance(account.id) : undefined
      };
      setUser(userWithBalance);
      localStorage.setItem('current_user', JSON.stringify(account));
      return true;
    }
    
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('current_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}