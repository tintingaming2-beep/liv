export interface User {
  id: string;
  username: string;
  type: 'livreur' | 'kiosk';
  balance?: number;
}

export interface Order {
  id: string;
  address: string;
  pickup_time: string;
  amount: number;
  client_phone: string;
  status: 'pending' | 'ready' | 'accepted' | 'delivered';
  created_at: string;
  updated_at: string;
  delivery_person_id?: string;
}

export interface DeliveryLocation {
  id: string;
  delivery_person_id: string;
  latitude: number;
  longitude: number;
  updated_at: string;
}

export interface Notification {
  id: string;
  type: 'new_order' | 'order_ready' | 'order_delivered' | 'balance_reset_request';
  message: string;
  recipient_type: 'livreur' | 'kiosk';
  created_at: string;
  read: boolean;
  order_id?: string;
}

export const PREDEFINED_ADDRESSES = [
  'Le Quesnoy Centre, 59530',
  'Rue du Général de Gaulle, Le Quesnoy 59530',
  'Avenue Léo Lagrange, Le Quesnoy 59530',
  'Rue de la Gare, Le Quesnoy 59530',
  'Bavay Centre, 59570',
  'Rue de Valenciennes, Bavay 59570',
  'Jolimetz, 59570',
  'Preux-au-Bois, 59288',
  'Rue du Moulin, Preux-au-Bois 59288',
  'Ruesnes Centre, 59270',
  'Rue de la Mairie, Ruesnes 59270',
  'Bettrechies, 59570',
  'Rue Principale, Bettrechies 59570',
  'Wargnies-le-Grand, 59144',
  'Place de la Mairie, Wargnies-le-Grand 59144',
  'Gommegnies Centre, 59144',
  'Rue de Maubeuge, Gommegnies 59144',
  'Bermeries, 59570',
  'Rue de l\'Église, Bermeries 59570',
  'Eth, 59144',
  'Rue du Village, Eth 59144'
];