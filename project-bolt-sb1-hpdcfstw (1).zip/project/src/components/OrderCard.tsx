import React from 'react';
import { Clock, MapPin, Euro, Phone, Check, Edit2, Trash2 } from 'lucide-react';
import { Order } from '../types';

interface OrderCardProps {
  order: Order;
  userRole: 'pizzeria' | 'driver';
  onEdit?: (order: Order) => void;
  onDelete?: (id: string) => void;
  onMarkReady?: (id: string) => void;
  onAccept?: (id: string) => void;
  onMarkDelivered?: (id: string) => void;
}

export const OrderCard: React.FC<OrderCardProps> = ({
  order,
  userRole,
  onEdit,
  onDelete,
  onMarkReady,
  onAccept,
  onMarkDelivered
}) => {
  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'ready':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'accepted':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'delivered':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 'En attente';
      case 'ready':
        return 'Prête';
      case 'accepted':
        return 'Acceptée';
      case 'delivered':
        return 'Livrée';
      case 'cancelled':
        return 'Annulée';
      default:
        return status;
    }
  };

  const canEdit = userRole === 'pizzeria' && order.status !== 'delivered' && order.status !== 'cancelled';
  const canDelete = userRole === 'pizzeria' && order.status === 'pending';
  const canMarkReady = userRole === 'pizzeria' && order.status === 'pending';
  const canAccept = userRole === 'driver' && order.status === 'ready' && !order.driverId;
  const canMarkDelivered = userRole === 'driver' && order.status === 'accepted' && order.driverId;

  return (
    <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6 space-y-4">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(order.status)}`}>
              {getStatusText(order.status)}
            </span>
            <span className="text-xs text-gray-500">
              #{order.id.slice(-6)}
            </span>
          </div>
        </div>
        <div className="text-right">
          <div className="flex items-center text-green-600 font-bold text-lg">
            <Euro className="w-5 h-5 mr-1" />
            {order.amount.toFixed(2)}
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-start space-x-3">
          <MapPin className="w-5 h-5 text-gray-400 mt-0.5" />
          <div>
            <p className="text-gray-900 font-medium">{order.clientAddress}</p>
            <p className="text-gray-600 text-sm">{order.city}</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <Clock className="w-5 h-5 text-gray-400" />
          <p className="text-gray-600">Récupération: {order.pickupTime}</p>
        </div>

        {order.clientPhone && (
          <div className="flex items-center space-x-3">
            <Phone className="w-5 h-5 text-gray-400" />
            <a 
              href={`tel:${order.clientPhone}`}
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              {order.clientPhone}
            </a>
          </div>
        )}
      </div>

      <div className="flex flex-wrap gap-2 pt-4 border-t">
        {canEdit && onEdit && (
          <button
            onClick={() => onEdit(order)}
            className="flex items-center space-x-1 px-3 py-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors text-sm"
          >
            <Edit2 className="w-4 h-4" />
            <span>Modifier</span>
          </button>
        )}

        {canDelete && onDelete && (
          <button
            onClick={() => onDelete(order.id)}
            className="flex items-center space-x-1 px-3 py-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors text-sm"
          >
            <Trash2 className="w-4 h-4" />
            <span>Supprimer</span>
          </button>
        )}

        {canMarkReady && onMarkReady && (
          <button
            onClick={() => onMarkReady(order.id)}
            className="flex items-center space-x-1 px-3 py-2 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors text-sm"
          >
            <Check className="w-4 h-4" />
            <span>Marquer prête</span>
          </button>
        )}

        {canAccept && onAccept && (
          <button
            onClick={() => onAccept(order.id)}
            className="flex items-center space-x-1 px-3 py-2 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors text-sm"
          >
            <Check className="w-4 h-4" />
            <span>Accepter</span>
          </button>
        )}

        {canMarkDelivered && onMarkDelivered && (
          <button
            onClick={() => onMarkDelivered(order.id)}
            className="flex items-center space-x-1 px-3 py-2 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors text-sm"
          >
            <Check className="w-4 h-4" />
            <span>Marquer livrée</span>
          </button>
        )}
      </div>
    </div>
  );
};