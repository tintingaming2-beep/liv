import React, { useEffect, useState } from 'react';
import { MapPin, Navigation } from 'lucide-react';

interface GPSProps {
  onLocationUpdate?: (lat: number, lng: number) => void;
  showMap?: boolean;
  driverPosition?: { lat: number; lng: number } | null;
}

export const GPS: React.FC<GPSProps> = ({ 
  onLocationUpdate, 
  showMap = false, 
  driverPosition 
}) => {
  const [position, setPosition] = useState<{ lat: number; lng: number } | null>(null);
  const [error, setError] = useState<string>('');
  const [watching, setWatching] = useState(false);

  useEffect(() => {
    if (!onLocationUpdate) return;

    if (!navigator.geolocation) {
      setError('Géolocalisation non supportée');
      return;
    }

    const startWatching = () => {
      const watchId = navigator.geolocation.watchPosition(
        (pos) => {
          const newPosition = {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude
          };
          setPosition(newPosition);
          onLocationUpdate(newPosition.lat, newPosition.lng);
          setWatching(true);
          setError('');
        },
        (err) => {
          setError('Erreur de géolocalisation');
          console.error(err);
        },
        {
          enableHighAccuracy: true,
          maximumAge: 10000,
          timeout: 5000
        }
      );

      return () => {
        navigator.geolocation.clearWatch(watchId);
        setWatching(false);
      };
    };

    const cleanup = startWatching();
    return cleanup;
  }, [onLocationUpdate]);

  const displayPosition = driverPosition || position;

  if (!showMap && !onLocationUpdate) return null;

  return (
    <div className="bg-white rounded-lg border shadow-sm p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Navigation className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-gray-900">Position GPS</h3>
        </div>
        {watching && (
          <div className="flex items-center space-x-1 text-green-600">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-xs font-medium">Actif</span>
          </div>
        )}
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      )}

      {displayPosition && (
        <div className="space-y-3">
          <div className="flex items-center space-x-3 text-sm text-gray-600">
            <MapPin className="w-4 h-4" />
            <div>
              <p>Lat: {displayPosition.lat.toFixed(6)}</p>
              <p>Lng: {displayPosition.lng.toFixed(6)}</p>
            </div>
          </div>

          {showMap && (
            <div className="bg-gray-100 rounded-lg p-8 text-center">
              <MapPin className="w-12 h-12 text-blue-600 mx-auto mb-2" />
              <p className="text-gray-600 text-sm">
                Carte intégrée - Position du {driverPosition ? 'livreur' : 'appareil'}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {displayPosition.lat.toFixed(4)}, {displayPosition.lng.toFixed(4)}
              </p>
            </div>
          )}
        </div>
      )}

      {!displayPosition && !error && (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
          <p className="text-gray-600 text-sm">Recherche de position...</p>
        </div>
      )}
    </div>
  );
};