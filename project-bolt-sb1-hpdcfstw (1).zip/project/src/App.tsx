import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { OrderProvider } from './context/OrderContext';
import { LoginForm } from './components/LoginForm';
import { PizzeriaPage } from './pages/PizzeriaPage';
import { DriverPage } from './pages/DriverPage';

const AppContent: React.FC = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginForm />;
  }

  return (
    <OrderProvider>
      <Routes>
        <Route 
          path="/" 
          element={
            user.role === 'pizzeria' ? (
              <Navigate to="/pizzeria" replace />
            ) : (
              <Navigate to="/driver" replace />
            )
          } 
        />
        <Route 
          path="/pizzeria" 
          element={
            user.role === 'pizzeria' ? (
              <PizzeriaPage />
            ) : (
              <Navigate to="/driver" replace />
            )
          } 
        />
        <Route 
          path="/driver" 
          element={
            user.role === 'driver' ? (
              <DriverPage />
            ) : (
              <Navigate to="/pizzeria" replace />
            )
          } 
        />
      </Routes>
    </OrderProvider>
  );
};

function App() {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}

export default App;