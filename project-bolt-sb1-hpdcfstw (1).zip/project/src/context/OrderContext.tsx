import React, { createContext, useContext, useState, useEffect } from 'react';
import { collection, onSnapshot, addDoc, updateDoc, deleteDoc, doc, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase/config';
import { Order } from '../types';

interface OrderContextType {
  orders: Order[];
  addOrder: (order: Omit<Order, 'id' | 'createdAt' | 'status'>) => Promise<void>;
  updateOrder: (id: string, updates: Partial<Order>) => Promise<void>;
  deleteOrder: (id: string) => Promise<void>;
  markAsReady: (id: string) => Promise<void>;
  markAsDelivered: (id: string, driverId: string) => Promise<void>;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export const useOrders = () => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within OrderProvider');
  }
  return context;
};

export const OrderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const ordersData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        deliveredAt: doc.data().deliveredAt?.toDate()
      })) as Order[];
      setOrders(ordersData);
    });

    return unsubscribe;
  }, []);

  const addOrder = async (orderData: Omit<Order, 'id' | 'createdAt' | 'status'>) => {
    await addDoc(collection(db, 'orders'), {
      ...orderData,
      status: 'pending',
      createdAt: new Date()
    });
  };

  const updateOrder = async (id: string, updates: Partial<Order>) => {
    await updateDoc(doc(db, 'orders', id), updates);
  };

  const deleteOrder = async (id: string) => {
    await deleteDoc(doc(db, 'orders', id));
  };

  const markAsReady = async (id: string) => {
    await updateDoc(doc(db, 'orders', id), { status: 'ready' });
  };

  const markAsDelivered = async (id: string, driverId: string) => {
    await updateDoc(doc(db, 'orders', id), { 
      status: 'delivered',
      deliveredAt: new Date(),
      driverId
    });
    
    // Update driver balance
    const driverDoc = doc(db, 'drivers', driverId);
    const { increment } = await import('firebase/firestore');
    await updateDoc(driverDoc, {
      balance: increment(5)
    });
  };

  return (
    <OrderContext.Provider value={{
      orders,
      addOrder,
      updateOrder,
      deleteOrder,
      markAsReady,
      markAsDelivered
    }}>
      {children}
    </OrderContext.Provider>
  );
};