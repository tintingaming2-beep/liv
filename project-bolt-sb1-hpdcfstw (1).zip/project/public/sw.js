const CACHE_NAME = 'delivery-platform-v1';
const urlsToCache = [
  '/',
  '/static/js/bundle.js',
  '/static/css/main.css',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        if (response) {
          return response;
        }
        return fetch(event.request);
      }
    )
  );
});

// Push notifications for new orders
self.addEventListener('push', (event) => {
  const options = {
    body: event.data ? event.data.text() : 'Nouvelle notification',
    icon: '/pizza-icon-192.png',
    badge: '/pizza-icon-192.png',
    vibrate: [200, 100, 200],
    tag: 'delivery-notification',
    actions: [
      {
        action: 'view',
        title: 'Voir',
        icon: '/pizza-icon-192.png'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('Plateforme de Livraison', options)
  );
});