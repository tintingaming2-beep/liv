import React, { useState, useEffect } from 'react';
import { Bell, BellOff, Smartphone, Settings } from 'lucide-react';
import { NotificationService } from '../services/NotificationService';
import { useAuth } from '../context/AuthContext';

export const NotificationSettings: React.FC = () => {
  const { user } = useAuth();
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isSupported, setIsSupported] = useState(false);
  const notificationService = NotificationService.getInstance();

  useEffect(() => {
    setIsSupported(notificationService.isSupported());
    setPermission(notificationService.getPermissionStatus());
  }, []);

  const requestPermission = async () => {
    const granted = await notificationService.requestPermission();
    setPermission(notificationService.getPermissionStatus());
    
    if (granted) {
      // Test notification
      await notificationService.sendNotification('🎉 Notifications activées !', {
        body: 'Vous recevrez maintenant les notifications pour les nouvelles commandes.',
        tag: 'test-notification'
      });
    }
  };

  const testNotification = async () => {
    await notificationService.notifyNewOrder({
      id: 'test-123',
      clientAddress: '123 Rue de Test',
      city: 'Ville Test',
      amount: 25.50,
      pickupTime: '19:30'
    }, user?.role);
  };

  const getStatusColor = () => {
    switch (permission) {
      case 'granted':
        return 'text-green-600';
      case 'denied':
        return 'text-red-600';
      default:
        return 'text-yellow-600';
    }
  };

  const getStatusText = () => {
    switch (permission) {
      case 'granted':
        return 'Activées';
      case 'denied':
        return 'Refusées';
      default:
        return 'Non configurées';
    }
  };

  if (!isSupported) {
    return (
      <div className="bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4 transition-colors">
        <div className="flex items-center space-x-2 text-gray-500 dark:text-gray-400">
          <BellOff className="w-5 h-5" />
          <span className="text-sm">Notifications non supportées par ce navigateur</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm p-4 transition-colors">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Smartphone className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-gray-900 dark:text-white">Notifications Push</h3>
        </div>
        <div className="flex items-center space-x-2">
          <Bell className={`w-4 h-4 ${getStatusColor()}`} />
          <span className={`text-sm font-medium ${getStatusColor()}`}>
            {getStatusText()}
          </span>
        </div>
      </div>

      <div className="space-y-3">
        <p className="text-sm text-gray-600 dark:text-gray-300">
          Recevez des notifications push sur votre téléphone pour les nouvelles commandes, 
          même quand l'application est fermée.
        </p>

        <div className="flex flex-wrap gap-2">
          {permission !== 'granted' && (
            <button
              onClick={requestPermission}
              className="flex items-center space-x-1 px-3 py-2 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors text-sm"
            >
              <Bell className="w-4 h-4" />
              <span>Activer les notifications</span>
            </button>
          )}

          {permission === 'granted' && (
            <button
              onClick={testNotification}
              className="flex items-center space-x-1 px-3 py-2 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/30 transition-colors text-sm"
            >
              <Settings className="w-4 h-4" />
              <span>Tester</span>
            </button>
          )}
        </div>

        {permission === 'denied' && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3">
            <p className="text-red-600 dark:text-red-400 text-sm">
              <strong>Notifications bloquées.</strong> Pour les activer :
            </p>
            <ul className="text-red-600 dark:text-red-400 text-xs mt-1 ml-4 list-disc">
              <li>Cliquez sur l'icône 🔒 dans la barre d'adresse</li>
              <li>Autorisez les notifications</li>
              <li>Rechargez la page</li>
            </ul>
          </div>
        )}

        {permission === 'granted' && (
          <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3">
            <p className="text-green-600 dark:text-green-400 text-sm">
              ✅ Notifications activées ! Vous recevrez des alertes pour :
            </p>
            <ul className="text-green-600 dark:text-green-400 text-xs mt-1 ml-4 list-disc">
              <li>Nouvelles commandes</li>
              <li>Commandes acceptées par le livreur</li>
              <li>Livraisons terminées</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};