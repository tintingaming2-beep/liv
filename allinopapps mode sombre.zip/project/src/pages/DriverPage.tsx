import React, { useState, useEffect } from 'react';
import { Bell, Euro, History } from 'lucide-react';
import { Layout } from '../components/Layout';
import { OrderCard } from '../components/OrderCard';
import { GPS } from '../components/GPS';
import { Notification } from '../components/Notification';
import { BalanceResetModal } from '../components/BalanceResetModal';
import { useOrders } from '../context/OrderContext';
import { useAuth } from '../context/AuthContext';
import { Order } from '../types';
import { TelegramPollingService } from '../services/telegramPolling';
import { doc, onSnapshot, updateDoc, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase/config';

export const DriverPage: React.FC = () => {
  const { user } = useAuth();
  const { orders, markAsDelivered, updateOrder } = useOrders();
  const availableOrders = orders.filter(order =>
    order.status === 'ready' && !order.driverId
  );

  const [notification, setNotification] = useState<{ message: string; type: 'info' | 'success' | 'warning' } | null>(null);
  const [driverBalance, setDriverBalance] = useState(0);
  const [deliveredOrders, setDeliveredOrders] = useState<Order[]>([]);
  const [showBalanceResetModal, setShowBalanceResetModal] = useState(false);
  const [balanceResetAmount, setBalanceResetAmount] = useState(0);
  
  // Gérer le service Telegram polling uniquement pour les livreurs
  useEffect(() => {
    const telegramService = TelegramPollingService.getInstance();
    
    // Démarrer le service quand le composant se monte
    telegramService.start();
    console.log('Telegram polling service started for driver');
    
    // Arrêter le service quand le composant se démonte
    return () => {
      telegramService.stop();
      console.log('Telegram polling service stopped');
    };
  }, []);

  // Listen for driver data updates
  useEffect(() => {
    if (!user) return;

    const unsubscribe = onSnapshot(doc(db, 'drivers', user.uid), (doc) => {
      if (doc.exists()) {
        const data = doc.data();
        setDriverBalance(data.balance || 0);
      }
    });

    return () => unsubscribe();
  }, [user]);

  // Listen for balance reset requests
  useEffect(() => {
    if (!user) return;

    const unsubscribe = onSnapshot(doc(db, 'balance-requests', 'current'), (doc) => {
      if (doc.exists()) {
        const data = doc.data();
        if (data.status === 'pending' && data.driverId === user.uid) {
          setBalanceResetAmount(data.amount);
          setShowBalanceResetModal(true);
        }
      }
    });

    return () => unsubscribe();
  }, [user]);

  // Update GPS position
  const handleLocationUpdate = async (lat: number, lng: number) => {
    if (!user) return;
    
    try {
      console.log('Updating driver position in Firestore:', { lat, lng });
      await setDoc(doc(db, 'drivers', 'driver-position'), {
        position: { lat, lng },
        timestamp: new Date(),
        driverId: user.uid
      });
      console.log('Driver position updated successfully');
    } catch (error) {
      console.error('Error updating position:', error);
      setNotification({
        message: 'Erreur mise à jour position GPS',
        type: 'warning'
      });
    }
  };

  const handleAcceptBalanceReset = async () => {
    if (!user) return;
    
    try {
      // Reset driver balance
      await updateDoc(doc(db, 'drivers', user.uid), {
        balance: 0
      });
      
      // Update request status
      await updateDoc(doc(db, 'balance-requests', 'current'), {
        status: 'accepted'
      });
      
      // Delete the request after a short delay
      setTimeout(async () => {
        await deleteDoc(doc(db, 'balance-requests', 'current'));
      }, 1000);
      
      setShowBalanceResetModal(false);
      setNotification({
        message: 'Solde remis à zéro avec succès',
        type: 'success'
      });
    } catch (error) {
      setNotification({
        message: 'Erreur lors de la remise à zéro',
        type: 'warning'
      });
    }
  };

  const handleRejectBalanceReset = async () => {
    try {
      // Update request status
      await updateDoc(doc(db, 'balance-requests', 'current'), {
        status: 'rejected'
      });
      
      // Delete the request after a short delay
      setTimeout(async () => {
        await deleteDoc(doc(db, 'balance-requests', 'current'));
      }, 1000);
      
      setShowBalanceResetModal(false);
      setNotification({
        message: 'Demande de remise à zéro refusée',
        type: 'info'
      });
    } catch (error) {
      setNotification({
        message: 'Erreur lors du refus',
        type: 'warning'
      });
    }
  };

  // Get accepted orders by this driver
  const acceptedOrders = orders.filter(order => 
    order.status === 'accepted' && order.driverId === user?.uid
  );

  // Get delivered orders by this driver
  useEffect(() => {
    const delivered = orders.filter(order => 
      order.status === 'delivered' && order.driverId === user?.uid
    );
    setDeliveredOrders(delivered);
  }, [orders, user]);

  const handleAcceptOrder = async (orderId: string) => {
    if (!user) return;
    
    try {
      await updateOrder(orderId, { 
        status: 'accepted',
        driverId: user.uid
      });
      setNotification({
        message: 'Commande acceptée avec succès',
        type: 'success'
      });
    } catch (error) {
      setNotification({
        message: 'Erreur lors de l\'acceptation',
        type: 'warning'
      });
    }
  };

  const handleMarkDelivered = async (orderId: string) => {
    if (!user) return;
    
    try {
      await markAsDelivered(orderId, user.uid);
      setNotification({
        message: 'Commande livrée - +5€ ajoutés à votre solde',
        type: 'success'
      });
    } catch (error) {
      setNotification({
        message: 'Erreur lors de la livraison',
        type: 'warning'
      });
    }
  };

  return (
    <Layout title="Interface Livreur">
      <div className="space-y-6">
        {/* Balance Card */}
        <div className="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 p-6 rounded-lg border border-gray-200 dark:border-gray-700 transition-colors">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">Solde actuel</h3>
              <div className="flex items-center space-x-1">
                <Euro className="w-6 h-6 text-green-600" />
                <span className="text-3xl font-bold text-green-600">
                  {driverBalance.toFixed(2)}
                </span>
              </div>
            </div>
            <div className="text-right text-sm text-gray-600 dark:text-gray-300">
              <p>{deliveredOrders.length} livraisons</p>
              <p>Commission: 5€/livraison</p>
            </div>
          </div>
        </div>

        {/* GPS Tracking */}
        <GPS onLocationUpdate={handleLocationUpdate} driverPosition={null} showGPSToggle={true} />

        {/* Available Orders */}
        <div>
          <div className="flex items-center space-x-2 mb-4">
            <Bell className="w-5 h-5 text-orange-600" />
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Commandes disponibles ({availableOrders.length})
            </h2>
          </div>
          
          <div className="space-y-4">
            {availableOrders.length > 0 ? (
              availableOrders.map((order) => (
                <OrderCard
                  key={order.id}
                  order={order}
                  userRole="driver"
                  onAccept={handleAcceptOrder}
                />
              ))
            ) : (
              <div className="text-center py-8 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 transition-colors">
                <Bell className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                <p className="text-gray-500 dark:text-gray-400">Aucune commande disponible</p>
              </div>
            )}
          </div>
        </div>

        {/* Accepted Orders */}
        {acceptedOrders.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
              Mes livraisons en cours ({acceptedOrders.length})
            </h2>
            
            <div className="space-y-4">
              {acceptedOrders.map((order) => (
                <OrderCard
                  key={order.id}
                  order={order}
                  userRole="driver"
                  onMarkDelivered={handleMarkDelivered}
                />
              ))}
            </div>
          </div>
        )}

        {/* Delivery History */}
        {deliveredOrders.length > 0 && (
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <History className="w-5 h-5 text-green-600" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                Historique des livraisons ({deliveredOrders.length})
              </h2>
            </div>
            
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {deliveredOrders.map((order) => (
                <OrderCard
                  key={order.id}
                  order={order}
                  userRole="driver"
                />
              ))}
            </div>
          </div>
        )}

        {/* Balance Reset Modal */}
        <BalanceResetModal
          isOpen={showBalanceResetModal}
          onClose={handleRejectBalanceReset}
          onConfirm={handleAcceptBalanceReset}
          currentBalance={balanceResetAmount}
        />

        {/* Notifications */}
        {notification && (
          <Notification
            message={notification.message}
            type={notification.type}
            onClose={() => setNotification(null)}
          />
        )}
      </div>
    </Layout>
  );
};