import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default markers in React Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface InteractiveMapProps {
  position: { lat: number; lng: number };
  pizzeriaPosition?: { lat: number; lng: number };
  driverPosition?: { lat: number; lng: number } | null;
  showDriver?: boolean;
  locationInfo?: {
    city?: string;
    address?: string;
  };
  height?: string;
}

// Custom icons for different markers
const createCustomIcon = (color: string) => {
  return L.divIcon({
    className: 'custom-div-icon',
    html: `<div style="background-color: ${color}; width: 20px; height: 20px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>`,
    iconSize: [20, 20],
    iconAnchor: [10, 10]
  });
};

const pizzeriaIcon = createCustomIcon('#dc2626'); // Red
const driverIcon = createCustomIcon('#2563eb'); // Blue

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  position,
  pizzeriaPosition,
  driverPosition,
  showDriver = false,
  locationInfo,
  height = '300px'
}) => {
  return (
    <div style={{ height, width: '100%' }} className="rounded-lg overflow-hidden border">
      <MapContainer
        center={[position.lat, position.lng]}
        zoom={13}
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {/* Pizzeria position marker (always visible in red) */}
        {pizzeriaPosition && (
          <Marker 
            position={[pizzeriaPosition.lat, pizzeriaPosition.lng]} 
            icon={pizzeriaIcon}
          >
            <Popup>
              <div className="p-2 text-sm max-w-xs">
                <div className="font-semibold mb-1 text-red-600">
                  🍕 Pizzeria
                </div>
                <div>
                  <strong>Coordonnées:</strong><br />
                  Lat: {pizzeriaPosition.lat.toFixed(6)}<br />
                  Lng: {pizzeriaPosition.lng.toFixed(6)}
                </div>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Current position marker (driver or other) */}
        <Marker 
          position={[position.lat, position.lng]} 
          icon={driverIcon}
        >
          <Popup>
            <div className="p-2 text-sm max-w-xs">
              <div className="font-semibold mb-1">
                🚚 Position actuelle
              </div>
              {locationInfo?.city && (
                <div><strong>Ville:</strong> {locationInfo.city}</div>
              )}
              {locationInfo?.address && (
                <div><strong>Adresse:</strong> {locationInfo.address}</div>
              )}
              <div>
                <strong>Coordonnées:</strong><br />
                Lat: {position.lat.toFixed(6)}<br />
                Lng: {position.lng.toFixed(6)}
              </div>
            </div>
          </Popup>
        </Marker>

        {/* Driver position marker (when different from current position) */}
        {showDriver && driverPosition && 
         (driverPosition.lat !== position.lat || driverPosition.lng !== position.lng) && (
          <Marker 
            position={[driverPosition.lat, driverPosition.lng]} 
            icon={driverIcon}
          >
            <Popup>
              <div className="p-2 text-sm">
                <div className="font-semibold mb-1">🚚 Position du livreur</div>
                <div>
                  Lat: {driverPosition.lat.toFixed(6)}<br />
                  Lng: {driverPosition.lng.toFixed(6)}
                </div>
              </div>
            </Popup>
          </Marker>
        )}
      </MapContainer>
    </div>
  );
};