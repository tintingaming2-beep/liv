import React, { useState, useEffect } from 'react';
import { Plus, History, MapPin, LogOut, Package, TrendingUp } from 'lucide-react';
import { Order } from '../../types';
import { storage } from '../../utils/storage';
import { notificationService } from '../../utils/notifications';
import { AppNotification } from '../../types';
import OrderCard from '../Shared/OrderCard';
import AddOrderForm from './AddOrderForm';
import Map from '../Shared/Map';
import NotificationBell from '../Shared/NotificationBell';
import NotificationPopup from '../Shared/NotificationPopup';

interface PizzeriaDashboardProps {
  onLogout: () => void;
}

const PizzeriaDashboard: React.FC<PizzeriaDashboardProps> = ({ onLogout }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [activeTab, setActiveTab] = useState<'active' | 'history'>('active');
  const [livreurLocation, setLivreurLocation] = useState<{ lat: number; lng: number } | undefined>();
  const [currentNotification, setCurrentNotification] = useState<AppNotification | null>(null);

  useEffect(() => {
    loadOrders();
    
    // Simulate livreur location updates
    const interval = setInterval(() => {
      const deliveryPerson = storage.getDeliveryPerson();
      if (deliveryPerson.isOnline && deliveryPerson.currentLatitude && deliveryPerson.currentLongitude) {
        setLivreurLocation({
          lat: deliveryPerson.currentLatitude,
          lng: deliveryPerson.currentLongitude
        });
      }
    }, 5000);

    // Listen for notifications
    const handleNotification = (notification: AppNotification) => {
      if (notification.type === 'order_delivered') {
        setCurrentNotification(notification);
      }
    };

    notificationService.addNotificationListener(handleNotification);

    return () => {
      clearInterval(interval);
      notificationService.removeNotificationListener(handleNotification);
    };
  }, []);

  const loadOrders = () => {
    const allOrders = storage.getOrders();
    setOrders(allOrders.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()));
  };

  const handleAddOrder = async (orderData: {
    customerPhone: string;
    deliveryAddress: string;
    deliveryTime: string;
    amount: number;
  }) => {
    const newOrder: Order = {
      id: Date.now().toString(),
      pizzeriaId: 'kiok',
      customerPhone: orderData.customerPhone,
      deliveryAddress: orderData.deliveryAddress,
      deliveryTime: orderData.deliveryTime,
      amount: orderData.amount,
      status: 'pending',
      createdAt: new Date(),
      updatedAt: new Date()
    };

    // Add geocoding
    const coordinates = await import('../../utils/geocoding').then(m => 
      m.geocodingService.geocodeAddress(orderData.deliveryAddress)
    );
    
    if (coordinates) {
      newOrder.latitude = coordinates.lat;
      newOrder.longitude = coordinates.lng;
    }

    storage.addOrder(newOrder);
    loadOrders();

    // Send notification to livreur
    notificationService.addNotification(
      'new_order',
      `Nouvelle commande: ${orderData.deliveryAddress} - ${orderData.deliveryTime}`
    );
  };

  const handleUpdateOrderStatus = (orderId: string, status: Order['status']) => {
    storage.updateOrder(orderId, { status });
    loadOrders();

    if (status === 'ready') {
      notificationService.addNotification(
        'order_ready',
        `Commande #${orderId.slice(-6)} prête à être récupérée`
      );
    }
  };

  const handleCall = (phoneNumber: string) => {
    window.open(`tel:${phoneNumber}`);
  };

  const activeOrders = orders.filter(order => order.status !== 'delivered');
  const completedOrders = orders.filter(order => order.status === 'delivered');

  const todayStats = {
    total: completedOrders.filter(order => {
      const today = new Date();
      return order.updatedAt.toDateString() === today.toDateString();
    }).length,
    revenue: completedOrders.reduce((sum, order) => sum + order.amount, 0)
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-800">Pizzeria Dashboard</h1>
              <p className="text-sm text-gray-600">Gérez vos commandes en temps réel</p>
            </div>
            <div className="flex items-center space-x-3">
              <NotificationBell userType="pizzeria" />
              <button
                onClick={onLogout}
                className="p-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors duration-200"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="px-4 py-6">
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center space-x-3">
              <div className="bg-green-100 p-2 rounded-lg">
                <TrendingUp className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Commandes aujourd'hui</p>
                <p className="text-xl font-bold text-gray-800">{todayStats.total}</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Package className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Commandes actives</p>
                <p className="text-xl font-bold text-gray-800">{activeOrders.length}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Map Section */}
        <div className="bg-white rounded-xl p-4 shadow-sm mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <MapPin className="h-5 w-5" />
            <span>Suivi en temps réel</span>
          </h3>
          <Map
            livreurLocation={livreurLocation}
            deliveryLocation={
              activeOrders.length > 0 && activeOrders[0].latitude && activeOrders[0].longitude
                ? {
                    lat: activeOrders[0].latitude,
                    lng: activeOrders[0].longitude,
                    address: activeOrders[0].deliveryAddress
                  }
                : undefined
            }
            className="h-48"
          />
        </div>

        {/* Tabs */}
        <div className="flex space-x-4 mb-6">
          <button
            onClick={() => setActiveTab('active')}
            className={`flex-1 py-3 px-4 rounded-xl font-medium transition-colors duration-200 ${
              activeTab === 'active'
                ? 'bg-orange-500 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
          >
            Commandes actives ({activeOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-3 px-4 rounded-xl font-medium transition-colors duration-200 ${
              activeTab === 'history'
                ? 'bg-orange-500 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
          >
            Historique ({completedOrders.length})
          </button>
        </div>

        {/* Orders List */}
        <div className="space-y-4 pb-20">
          {activeTab === 'active' ? (
            activeOrders.length > 0 ? (
              activeOrders.map(order => (
                <OrderCard
                  key={order.id}
                  order={order}
                  userType="pizzeria"
                  onUpdateStatus={handleUpdateOrderStatus}
                  onCall={handleCall}
                />
              ))
            ) : (
              <div className="bg-white rounded-xl p-8 text-center">
                <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Aucune commande active</p>
                <p className="text-sm text-gray-400 mt-1">
                  Ajoutez une nouvelle commande pour commencer
                </p>
              </div>
            )
          ) : (
            completedOrders.length > 0 ? (
              completedOrders.map(order => (
                <OrderCard
                  key={order.id}
                  order={order}
                  userType="pizzeria"
                  onCall={handleCall}
                />
              ))
            ) : (
              <div className="bg-white rounded-xl p-8 text-center">
                <History className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Aucune commande terminée</p>
              </div>
            )
          )}
        </div>
      </div>

      {/* Floating Add Button */}
      <button
        onClick={() => setShowAddForm(true)}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-orange-500 to-red-500 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105"
      >
        <Plus className="h-6 w-6" />
      </button>

      {/* Add Order Form Modal */}
      {showAddForm && (
        <AddOrderForm
          onClose={() => setShowAddForm(false)}
          onAddOrder={handleAddOrder}
        />
      )}

      {/* Notification Popup */}
      {currentNotification && (
        <NotificationPopup
          message={currentNotification.message}
          type={currentNotification.type}
          onClose={() => setCurrentNotification(null)}
        />
      )}
    </div>
  );
};

export default PizzeriaDashboard;