import React, { useState, useEffect } from 'react';
import Login from './components/Auth/Login';
import PizzeriaDashboard from './components/Pizzeria/PizzeriaDashboard';
import LivreurDashboard from './components/Livreur/LivreurDashboard';
import { User } from './types';
import { storage } from './utils/storage';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is already logged in
    const user = storage.getCurrentUser();
    setCurrentUser(user);
    setIsLoading(false);
  }, []);

  const handleLogin = (username: string, password: string): boolean => {
    // Simple authentication
    const validCredentials = [
      { username: 'livreur', password: '1234', type: 'livreur' as const },
      { username: 'kiok', password: '1234', type: 'pizzeria' as const }
    ];

    const credential = validCredentials.find(
      cred => cred.username === username && cred.password === password
    );

    if (credential) {
      const user: User = {
        id: credential.username,
        username: credential.username,
        type: credential.type
      };

      storage.setCurrentUser(user);
      setCurrentUser(user);
      return true;
    }

    return false;
  };

  const handleLogout = () => {
    storage.clearCurrentUser();
    setCurrentUser(null);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  if (!currentUser) {
    return <Login onLogin={handleLogin} />;
  }

  if (currentUser.type === 'pizzeria') {
    return <PizzeriaDashboard onLogout={handleLogout} />;
  }

  return <LivreurDashboard onLogout={handleLogout} />;
}

export default App;