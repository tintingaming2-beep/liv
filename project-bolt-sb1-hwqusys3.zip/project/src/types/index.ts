export interface User {
  id: string;
  username: string;
  type: 'pizzeria' | 'livreur';
}

export interface Order {
  id: string;
  pizzeriaId: string;
  customerPhone: string;
  deliveryAddress: string;
  deliveryTime: string;
  amount: number;
  status: 'pending' | 'ready' | 'picked_up' | 'delivered';
  createdAt: Date;
  updatedAt: Date;
  latitude?: number;
  longitude?: number;
}

export interface DeliveryPerson {
  id: string;
  name: string;
  balance: number;
  currentLatitude?: number;
  currentLongitude?: number;
  isOnline: boolean;
}

export interface Notification {
  id: string;
  type: 'new_order' | 'order_ready' | 'order_delivered';
  message: string;
  timestamp: Date;
  read: boolean;
}