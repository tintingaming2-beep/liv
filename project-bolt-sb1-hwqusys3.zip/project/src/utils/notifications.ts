import { storage } from './storage';
import { Notification as AppNotification } from '../types';

// Global notification listeners
const notificationListeners: ((notification: AppNotification) => void)[] = [];

class NotificationService {
  private audio: HTMLAudioElement | null = null;

  constructor() {
    // Create audio element for notification sound
    this.audio = new Audio();
    this.audio.src = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhFzKX3PDEeyYELIPI7NyJOggWaLvt5Z5NEAxTqN/trl8cBjiX2/LNeSsFJHfL7tyROAoUZbzq69dVEglG';
  }

  addNotificationListener(callback: (notification: AppNotification) => void) {
    notificationListeners.push(callback);
  }

  removeNotificationListener(callback: (notification: AppNotification) => void) {
    const index = notificationListeners.indexOf(callback);
    if (index > -1) {
      notificationListeners.splice(index, 1);
    }
  }

  playNotificationSound() {
    if (this.audio) {
      this.audio.currentTime = 0;
      this.audio.play().catch(e => console.log('Could not play notification sound:', e));
    }
  }

  addNotification(type: AppNotification['type'], message: string) {
    const notification: AppNotification = {
      id: Date.now().toString(),
      type,
      message,
      timestamp: new Date(),
      read: false
    };

    storage.addNotification(notification);
    this.playNotificationSound();

    // Notify all listeners
    notificationListeners.forEach(listener => listener(notification));

    // Show browser notification if permission granted
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('Nouvelle commande', {
        body: message,
        icon: '/pizza-icon.png'
      });
    }
  }

  requestPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }
}

export const notificationService = new NotificationService();