const CACHE_NAME = 'delivery-platform-v1';
const urlsToCache = [
  '/',
  '/static/js/bundle.js',
  '/static/css/main.css',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        if (response) {
          return response;
        }
        return fetch(event.request);
      }
    )
  );
});

// Gestion des notifications push
self.addEventListener('push', (event) => {
  let data = {};
  
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data = { body: event.data.text() };
    }
  }

  const options = {
    body: data.body || 'Nouvelle notification',
    icon: data.icon || '/pizza-icon-192.png',
    badge: data.badge || '/pizza-icon-192.png',
    vibrate: data.vibrate || [200, 100, 200],
    tag: data.tag || 'delivery-notification',
    data: data.data || {},
    requireInteraction: true,
    actions: data.actions || [
      {
        action: 'view',
        title: 'Voir',
        icon: '/pizza-icon-192.png'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(data.title || 'Plateforme de Livraison', options)
  );
});

// Gestion des clics sur les notifications
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const action = event.action;
  const data = event.notification.data;
  const orderId = data?.orderId;
  const userRole = data?.userRole;

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        // Gestion des actions spécifiques
        if (action === 'accept' && userRole === 'driver') {
          // Accepter la commande directement
          fetch('/api/accept-order', {
            method: 'POST',
            body: JSON.stringify({ orderId }),
            headers: { 'Content-Type': 'application/json' }
          }).catch(console.error);
          
          // Arrêter le son et la vibration répétitifs
          self.postMessage({ type: 'STOP_REPEATING_SOUND' });
        } else if (action === 'refuse' && userRole === 'driver') {
          // Refuser la commande directement
          fetch('/api/refuse-order', {
            method: 'POST',
            body: JSON.stringify({ orderId }),
            headers: { 'Content-Type': 'application/json' }
          }).catch(console.error);
          
          // Arrêter le son et la vibration répétitifs
          self.postMessage({ type: 'STOP_REPEATING_SOUND' });
        }
        
        // Si l'app est déjà ouverte, la focus
        for (const client of clientList) {
          if (client.url.includes(self.location.origin)) {
            client.focus();
            // Envoyer un message à l'app avec l'action
            client.postMessage({
              type: 'notification-click',
              action: action,
              data: data,
              orderId: orderId
            });
            return;
          }
        }
        
        // Sinon, ouvrir l'app
        return clients.openWindow('/');
      })
  );
});

// Écouter les messages de l'app principale
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SHOW_NOTIFICATION') {
    const { title, options } = event.data;
    
    event.waitUntil(
      self.registration.showNotification(title, options)
    );
  }
});