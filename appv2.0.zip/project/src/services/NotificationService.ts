export class NotificationService {
  private static instance: NotificationService;
  private registration: ServiceWorkerRegistration | null = null;
  private repeatingSoundInterval: number | null = null;
  private repeatingVibrationInterval: number | null = null;
  private stopTimeout: number | null = null;

  private constructor() {}

  static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService();
    }
    return NotificationService.instance;
  }

  isSupported(): boolean {
    return 'Notification' in window && 'serviceWorker' in navigator;
  }

  getPermissionStatus(): NotificationPermission {
    return Notification.permission;
  }

  async requestPermission(): Promise<boolean> {
    if (!this.isSupported()) return false;
    
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }

  async initializeServiceWorker(): Promise<void> {
    if (!('serviceWorker' in navigator)) return;
    
    // Skip Service Worker registration in StackBlitz/WebContainer environments
    const hostname = window.location.hostname;
    if (hostname.includes('stackblitz.io') || 
        hostname.includes('webcontainer.io') || 
        hostname.includes('webcontainer-api.io')) {
      console.log('Service Worker skipped in virtualized environment');
      return;
    }
    
    try {
      this.registration = await navigator.serviceWorker.register('/sw.js');
      console.log('Service Worker registered successfully');
    } catch (error) {
      console.error('Service Worker registration failed:', error);
    }
  }

  async sendNotification(title: string, options: NotificationOptions = {}): Promise<void> {
    if (!this.isSupported() || Notification.permission !== 'granted') {
      console.log('⚠️ Notifications non supportées ou permission refusée');
      return;
    }

    const defaultOptions: NotificationOptions = {
      icon: '/pizza-icon-192.png',
      badge: '/pizza-icon-192.png',
      tag: 'delivery-notification',
      requireInteraction: true,
      silent: true
    };

    const finalOptions = { ...defaultOptions, ...options };
    console.log('📱 Envoi notification:', title, finalOptions);

    if (this.registration) {
      await this.registration.showNotification(title, finalOptions);
      console.log('✅ Notification envoyée via Service Worker');
    } else {
      // Supprimer les actions pour le constructeur Notification direct
      const { actions, ...optionsWithoutActions } = finalOptions;
      if (actions && actions.length > 0) {
        console.log('⚠️ Actions supprimées pour notification directe:', actions);
      }
      new Notification(title, optionsWithoutActions);
      console.log('✅ Notification envoyée directement');
    }
  }

  async playSound(): Promise<void> {
    return this.playCarillonSound();
  }

  private async playCarillonSound(): Promise<void> {
    try {
      console.log('🔊 Tentative de lecture du son...');
      
      // Essayer plusieurs sources audio
      const audioSources = [
        '/Just eat courier - order offer sound effect.mp3',
        'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT'
      ];
      
      for (const src of audioSources) {
        try {
          const audio = new Audio(src);
          audio.volume = 0.8;
          await audio.play();
          console.log('✅ Son joué avec succès:', src);
          return;
        } catch (audioError) {
          console.log('⚠️ Échec source audio:', src, audioError);
        }
      }
      
      // Fallback: son système
      console.log('🔊 Fallback: synthèse vocale...');
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance('Nouvelle commande');
        utterance.rate = 2;
        utterance.volume = 0.8;
        speechSynthesis.speak(utterance);
        console.log('✅ Synthèse vocale activée');
      }
      
    } catch (error) {
      console.error('❌ Erreur lecture son:', error);
    }
  }

  private async playCarillonSoundOld(): Promise<void> {
    try {
      console.log('🔊 Tentative de lecture du son...');
      const audio = new Audio('/Just eat courier - order offer sound effect.mp3');
      audio.volume = 0.8;
      await audio.play().then(() => {
        console.log('✅ Son joué avec succès');
      }).catch((error) => {
        console.error('❌ Erreur lecture son:', error);
        // Fallback: son système du navigateur
        if ('speechSynthesis' in window) {
          const utterance = new SpeechSynthesisUtterance('Nouvelle commande');
          utterance.rate = 2;
          utterance.volume = 0.8;
          speechSynthesis.speak(utterance);
        }
      });
    } catch (error) {
      console.error('Erreur lecture son:', error);
    }
  }

  private vibratePhone(): void {
    if ('vibrate' in navigator) {
      navigator.vibrate([200, 100, 200, 100, 200]);
    }
  }

  private startRepeatingAlerts(): void {
    // Arrêter les alertes précédentes
    this.stopAllRepeating();

    // Son répétitif toutes les 3 secondes
    this.repeatingSoundInterval = window.setInterval(() => {
      this.playCarillonSound();
    }, 3000);

    // Vibration répétitive toutes les 5 secondes
    this.repeatingVibrationInterval = window.setInterval(() => {
      this.vibratePhone();
    }, 5000);

    // Arrêt automatique après 2 minutes
    this.stopTimeout = window.setTimeout(() => {
      this.stopAllRepeating();
    }, 120000);
  }

  stopAllRepeating(): void {
    if (this.repeatingSoundInterval) {
      clearInterval(this.repeatingSoundInterval);
      this.repeatingSoundInterval = null;
      console.log('🔇 Son répétitif arrêté');
    }
    
    if (this.repeatingVibrationInterval) {
      clearInterval(this.repeatingVibrationInterval);
      this.repeatingVibrationInterval = null;
      console.log('📳 Vibration répétitive arrêtée');
    }
    
    if (this.stopTimeout) {
      clearTimeout(this.stopTimeout);
      this.stopTimeout = null;
      console.log('⏰ Timeout d\'arrêt annulé');
    }
  }

  async notifyOrderAccepted(order: any, userRole: string): Promise<void> {
    // Arrêter le son répétitif quand commande acceptée
    this.stopAllRepeating();
    
    const title = '✅ Commande acceptée';
    const body = `Commande ${order.clientAddress} acceptée par le livreur`;

    await this.sendNotification(title, {
      body,
      tag: `accepted-${order.id}`
    });
  }

  async notifyOrderReadyForDriver(order: any): Promise<void> {
    console.log('🔔 === NOTIFY ORDER READY (LIVREUR) ===');
    console.log('📋 Order:', order);
    
    const title = '🚚 Commande prête à livrer !';
    const body = `📍 ${order.clientAddress}, ${order.city}\n💰 ${order.amount}€ - ⏰ ${order.pickupTime}`;

    const options: NotificationOptions = {
      body,
      tag: `ready-${order.id}`,
      data: {
        orderId: order.id,
        type: 'order-ready'
      },
      actions: [
        { action: 'accept', title: '✅ Accepter' },
        { action: 'refuse', title: '❌ Refuser' }
      ]
    };

    // Notification silencieuse - le son sera déclenché par le livreur via Telegram/PWA
    await this.sendNotification(title, options);
    
    // PAS de son ici - sera déclenché côté livreur uniquement
    console.log('🔕 Notification envoyée sans son (son géré côté livreur)');
  }

  async notifyOrderReadyWithSound(order: any): Promise<void> {
    console.log('🔔 === NOTIFY ORDER READY AVEC SON (LIVREUR UNIQUEMENT) ===');
    
    const title = '🚚 Commande prête à livrer !';
    const body = `📍 ${order.clientAddress}, ${order.city}\n💰 ${order.amount}€ - ⏰ ${order.pickupTime}`;

    const options: NotificationOptions = {
      body,
      tag: `ready-${order.id}`,
      data: {
        orderId: order.id,
        type: 'order-ready'
      }
    };

    await this.sendNotification(title, options);
    
    // Son répétitif UNIQUEMENT pour le livreur
    console.log('🔔 Démarrage son répétitif pour commande prête (LIVREUR)');
    await this.playCarillonSound();
    this.vibratePhone();
    this.startRepeatingAlerts();
    
    console.log('✅ Notification livreur avec son répétitif envoyée');
  }

  async notifyOrderDelivered(order: any, userRole: string): Promise<void> {
    const title = '🎉 Livraison terminée !';
    const body = `Commande ${order.clientAddress} livrée avec succès`;

    await this.sendNotification(title, {
      body,
      tag: `delivered-${order.id}`
    });
  }
}