import React, { useState, useEffect } from 'react';
import { X, Plus, MapPin } from 'lucide-react';
import { Order } from '../types';
import { CITIES } from '../constants/cities';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (order: Omit<Order, 'id' | 'createdAt' | 'status'>) => void;
  editOrder?: Order | null;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  editOrder
}) => {
  const [customCities, setCustomCities] = useState<string[]>([]);
  const [showCustomCityInput, setShowCustomCityInput] = useState(false);
  const [customCityName, setCustomCityName] = useState('');
  const [formData, setFormData] = useState({
    clientAddress: '',
    city: CITIES[0],
    pickupTime: '',
    amount: 0,
    clientPhone: ''
  });

  // Fonction pour formater le numéro de téléphone en temps réel
  const formatPhoneInput = (value: string): string => {
    // Supprimer tous les caractères non numériques sauf le +
    const cleaned = value.replace(/[^\d+]/g, '');
    
    // Si ça commence par +33, on garde tel quel pour l'instant
    if (cleaned.startsWith('+33')) {
      return cleaned;
    }
    
    // Si ça commence par 0 et fait plus de 2 caractères, on formate
    if (cleaned.startsWith('0') && cleaned.length > 2) {
      const numbers = cleaned.substring(0, 10); // Limiter à 10 chiffres
      return numbers.replace(/(\d{2})(?=\d)/g, '$1 ').trim();
    }
    
    return cleaned;
  };

  // Fonction pour nettoyer le numéro avant sauvegarde
  const cleanPhoneForSave = (phone: string): string => {
    return phone.replace(/\s/g, ''); // Supprimer les espaces
  };

  // Charger les villes personnalisées depuis localStorage au démarrage
  useEffect(() => {
    const savedCities = localStorage.getItem('customCities');
    if (savedCities) {
      try {
        const cities = JSON.parse(savedCities);
        setCustomCities(cities);
      } catch (error) {
        console.error('Erreur lors du chargement des villes personnalisées:', error);
      }
    }
  }, []);

  // Sauvegarder les villes personnalisées dans localStorage
  const saveCustomCities = (cities: string[]) => {
    localStorage.setItem('customCities', JSON.stringify(cities));
    setCustomCities(cities);
  };

  // Ajouter une nouvelle ville personnalisée
  const addCustomCity = () => {
    if (customCityName.trim() && !allCities.includes(customCityName.trim())) {
      const newCities = [...customCities, customCityName.trim()];
      saveCustomCities(newCities);
      setFormData(prev => ({ ...prev, city: customCityName.trim() }));
      setCustomCityName('');
      setShowCustomCityInput(false);
    }
  };

  // Combiner les villes par défaut et personnalisées
  const allCities = [...CITIES, ...customCities];
  useEffect(() => {
    if (editOrder) {
      setFormData({
        clientAddress: editOrder.clientAddress,
        city: editOrder.city,
        pickupTime: editOrder.pickupTime,
        amount: editOrder.amount,
        clientPhone: editOrder.clientPhone || ''
      });
    } else {
      setFormData({
        clientAddress: '',
        city: allCities[0],
        pickupTime: '',
        amount: 0,
        clientPhone: ''
      });
      setShowCustomCityInput(false);
      setCustomCityName('');
    }
  }, [editOrder, isOpen, customCities]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      clientPhone: formData.clientPhone ? cleanPhoneForSave(formData.clientPhone) : undefined
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-xl font-bold text-gray-900">
            {editOrder ? 'Modifier la commande' : 'Nouvelle commande'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Adresse client *
            </label>
            <textarea
              value={formData.clientAddress}
              onChange={(e) => setFormData(prev => ({ ...prev, clientAddress: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              rows={3}
              placeholder="Adresse complète de livraison..."
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Ville *
            </label>
            <div className="space-y-2">
              <select
                value={formData.city}
                onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                {allCities.map((city) => (
                  <option key={city} value={city}>
                    {city}
                    {customCities.includes(city) ? ' (personnalisée)' : ''}
                  </option>
                ))}
              </select>
              
              {!showCustomCityInput ? (
                <button
                  type="button"
                  onClick={() => setShowCustomCityInput(true)}
                  className="flex items-center space-x-1 text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  <MapPin className="w-4 h-4" />
                  <span>Ajouter une nouvelle ville</span>
                </button>
              ) : (
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={customCityName}
                    onChange={(e) => setCustomCityName(e.target.value)}
                    placeholder="Nom de la nouvelle ville"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    onKeyPress={(e) => e.key === 'Enter' && addCustomCity()}
                  />
                  <button
                    type="button"
                    onClick={addCustomCity}
                    className="px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm font-medium"
                  >
                    Ajouter
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowCustomCityInput(false);
                      setCustomCityName('');
                    }}
                    className="px-3 py-2 bg-gray-300 hover:bg-gray-400 text-gray-700 rounded-lg text-sm font-medium"
                  >
                    Annuler
                  </button>
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Heure de récupération *
            </label>
            <input
              type="time"
              value={formData.pickupTime}
              onChange={(e) => setFormData(prev => ({ ...prev, pickupTime: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Montant à encaisser (€) *
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              value={formData.amount}
              onChange={(e) => setFormData(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="0.00"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Numéro de téléphone client
            </label>
            <input
              type="tel"
              value={formData.clientPhone}
              onChange={(e) => {
                const formatted = formatPhoneInput(e.target.value);
                setFormData(prev => ({ ...prev, clientPhone: formatted }));
              }}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="06 12 34 56 78"
              maxLength={14}
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors flex items-center justify-center space-x-1"
            >
              <Plus className="w-4 h-4" />
              <span>{editOrder ? 'Modifier' : 'Créer'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};