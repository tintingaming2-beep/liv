import React from 'react';
import { X, AlertTriangle, Euro } from 'lucide-react';

interface BalanceResetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  currentBalance: number;
}

export const BalanceResetModal: React.FC<BalanceResetModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  currentBalance
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full">
        <div className="flex justify-between items-center p-6 border-b">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-6 h-6 text-amber-600" />
            <h2 className="text-xl font-bold text-gray-900">
              Demande de remise à zéro
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <p className="text-amber-800 text-sm">
              La pizzeria demande une remise à zéro de votre solde.
            </p>
          </div>

          <div className="text-center">
            <p className="text-gray-600 mb-2">Solde actuel :</p>
            <div className="flex items-center justify-center space-x-1">
              <Euro className="w-6 h-6 text-green-600" />
              <span className="text-3xl font-bold text-green-600">
                {currentBalance.toFixed(2)}
              </span>
            </div>
          </div>

          <p className="text-gray-600 text-center text-sm">
            Acceptez-vous cette remise à zéro ? Cette action est irréversible.
          </p>
        </div>

        <div className="flex space-x-3 p-6 border-t">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors"
          >
            Refuser
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
          >
            Accepter la remise à zéro
          </button>
        </div>
      </div>
    </div>
  );
};